//#region src/model.d.ts
declare const GOALS_PACKAGE: "@aetheria/goals";
/** The store format, versioned before the first write: one append-only journal of full snapshots per root, plus a derived snapshot file. */
declare const GOALS_FORMAT: Readonly<{
  readonly format: "aetheria-goals";
  readonly version: 1;
}>;
declare const GOAL_PHASES: readonly ["active", "paused", "blocked", "complete"];
type GoalPhase = (typeof GOAL_PHASES)[number];
/** The canonical refusals of C1/C2. M03's `AUTH_*` and M06's `ORIGIN_*` verdicts pass through under their own names; `unavailable` is a separate status, never a code. */
declare const GOAL_CODES: readonly ["GOAL_NOT_ROOT", "GOAL_NOT_FOUND", "GOAL_ALREADY_EXISTS", "GOAL_STALE_REVISION", "GOAL_INVALID_OBJECTIVE", "GOAL_INVALID_MAX_ROUNDS", "GOAL_INVALID_TRANSITION", "GOAL_ORIGIN_REQUIRED", "GOAL_ORIGIN_CONSUMED", "GOAL_NOT_AUTHORIZED"];
type GoalCode = (typeof GOAL_CODES)[number];
type OriginCode = "ORIGIN_NOT_FOUND" | "ORIGIN_STALE" | "ORIGIN_MISMATCH";
type RefusalCode = GoalCode | OriginCode | `AUTH_${string}`;
interface Blocker {
  readonly code: string;
  readonly message: string;
}
interface ForkedFrom {
  readonly rootSessionId: string;
  readonly goalId: string;
}
/** One root's goal. `revision` rises by one with every committed mutation; arming and round counting never change it (D6). */
interface GoalRecord {
  readonly goalId: string;
  readonly revision: number;
  readonly objective: string;
  readonly maxRounds: number;
  readonly phase: GoalPhase;
  readonly blocker?: Blocker;
  readonly roundsStarted: number;
  readonly roundsAtRevision: number;
  readonly forkedFrom: ForkedFrom | null;
  readonly createdAt: string;
  readonly updatedAt: string;
}
type MutationOp = "create" | "fork-copy" | "edit" | "pause" | "resume" | "block" | "complete";
type ProposalOp = "create" | "edit" | "resume";
/** A stored proposal: the service's own text digest and base, never an origin id. */
interface Proposal {
  readonly proposalId: string;
  readonly op: ProposalOp;
  readonly rootSessionId: string;
  readonly sessionId: string;
  readonly goalId: string | null;
  readonly baseRevision: number | null;
  readonly objective: string | null;
  readonly maxRounds: number | null;
  readonly digest: string;
  readonly interactionId: string;
  readonly createdAt: string;
}
/** A round reserved before admission (D7, D8). The key is `goalId:revision:round`. */
interface Reservation {
  readonly goalId: string;
  readonly revision: number;
  readonly round: number;
  readonly key: string;
}
/** A round that entered and has not settled: the evidence T3's recovery guard reads (D9, N1) and the authority for complete/block (D4). */
interface RunningRound {
  readonly goalId: string;
  readonly revision: number;
  readonly round: number;
  readonly messageId: string;
}
type AuditEvent = "armed" | "disarmed" | "interrupted";
/** What a journal line says. Every line also carries `v`, a continuous `seq` and a time `at`. Audit lines never grant anything. */
type JournalBody = {
  readonly kind: "header";
  readonly rootSessionId: string;
} | {
  readonly kind: "mutation";
  readonly op: MutationOp;
  readonly goal: GoalRecord;
  readonly consumed?: string;
  readonly proposalId?: string;
} | {
  readonly kind: "tombstone";
  readonly goalId: string;
  readonly revision: number;
  readonly consumed?: string;
} | {
  readonly kind: "proposal";
  readonly proposal: Proposal;
} | {
  readonly kind: "proposal-closed";
  readonly proposalId: string;
  readonly outcome: string;
} | {
  readonly kind: "reserve";
  readonly reservation: Reservation;
} | {
  readonly kind: "reserve-drop";
  readonly key: string;
  readonly reason: string;
} | {
  readonly kind: "entered";
  readonly key: string;
  readonly goalId: string;
  readonly revision: number;
  readonly round: number;
  readonly messageId: string;
} | {
  readonly kind: "running-clear";
  readonly key: string;
} | {
  readonly kind: "audit";
  readonly event: AuditEvent;
  readonly goalId: string;
  readonly revision: number;
  readonly detail?: string;
};
type JournalLine = JournalBody & {
  readonly v: 1;
  readonly seq: number;
  readonly at: string;
};
type ParameterStatus = "carried, not accepted" | "proposed for gate";
interface Parameter {
  readonly value: number;
  readonly unit: string;
  readonly status: ParameterStatus;
  readonly source: string;
}
/** Test values, each labelled unaccepted. The module refuses to start without a value for every name (`validateGoalParameters`). */
declare const GOAL_PARAMETERS: Readonly<{
  defaultMaxRounds: Parameter;
  blockedAfterConsecutiveRounds: Parameter;
}>;
type GoalParameterName = keyof typeof GOAL_PARAMETERS;
declare const GOAL_PARAMETER_NAMES: GoalParameterName[];
type GoalParameterValues = Readonly<Record<GoalParameterName, number>>;
declare const GOAL_PARAMETER_ACCEPTANCE: "unaccepted test values until the user's M12 gate";
/** Problems with the values the Backend was configured with: every name present, nothing else, each a positive safe integer. Empty means startable. */
declare function validateGoalParameters(values: unknown): string[];
/** The outcomes every operation returns (design "Application contract"): none of them is a thrown error, and `unavailable` never reads as "no goal". */
type GoalResult<T> = {
  readonly status: "ok";
  readonly value: T;
} | {
  readonly status: "refused";
  readonly code: RefusalCode;
  readonly detail?: string;
  readonly field?: string;
} | {
  readonly status: "awaiting-human";
  readonly proposalId: string;
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
/** How a session maps to its root, from the same Backend identity read M05 uses (M03). Only a validated main session has a root a goal may key by. */
type RootResolution = {
  readonly kind: "main";
  readonly rootSessionId: string;
} | {
  readonly kind: "child";
  readonly rootSessionId: string;
} | {
  readonly kind: "unavailable";
  readonly reason: string;
};
interface RootResolver {
  resolve(sessionId: string): RootResolution;
}
interface Subject {
  readonly type: string;
  readonly id: string;
  readonly revision: string;
}
interface InteractionView {
  readonly interactionId: string;
  readonly state: string;
  /** Present once a person decided; the id never leaves the Backend. */
  readonly originId?: string;
}
/** M06's direct Backend calls, narrowed to what M07 uses. `unavailable` is first-class. */
interface InteractionPort {
  createAuthorization(input: {
    readonly sessionId: string;
    readonly text: string;
    readonly subject: Subject;
  }): Promise<{
    readonly ok: true;
    readonly value: InteractionView;
  } | {
    readonly ok: false;
    readonly code: string;
  }>;
  awaitInteraction(interactionId: string): Promise<{
    readonly ok: true;
    readonly value: InteractionView;
  } | {
    readonly ok: false;
    readonly code: string;
  }>;
  verifyHumanOrigin(originId: string, expect: {
    readonly kind: "authorization";
    readonly subject: Subject;
    readonly sessionId: string;
  }): Promise<{
    readonly verified: true;
    readonly origin: {
      readonly decision: string;
      readonly rootSessionId: string;
      readonly sessionId: string;
    };
  } | {
    readonly verified: false;
    readonly code: OriginCode;
    readonly field?: string;
  } | {
    readonly unavailable: true;
    readonly reason: string;
  }>;
}
interface TrustedAuthority {
  readonly kind: "backend-module";
  readonly module: string;
}
type AdmitAnswer = {
  readonly status: "admitted";
  readonly messageId: string;
} | {
  readonly status: "refused";
  readonly reason: "busy" | "unauthorized" | "closed";
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
type AdmissionState = {
  readonly status: "absent";
} | {
  readonly status: "admitting";
  readonly messageId: string;
} | {
  readonly status: "admitted";
  readonly messageId: string;
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
interface SettledEvent {
  readonly sessionId: string;
  readonly settleSeq: number;
  readonly outcome: "completed" | "failed" | "interrupted" | "max-tokens";
  readonly cause: string | null;
}
/** M05's direct turn calls plus the one read-only addition (D8 revision). The service never calls `admitTurn` for a goal that is not armed. */
interface AdmissionPort {
  admitTurn(request: {
    readonly authority: TrustedAuthority;
    readonly sessionId: string;
    readonly origin: {
      readonly kind: "goal-round";
      readonly goalId: string;
      readonly revision: number;
      readonly round: number;
    };
    readonly content: string;
    readonly key: string;
  }): Promise<AdmitAnswer>;
  admissionState(request: {
    readonly authority: TrustedAuthority;
    readonly sessionId: string;
    readonly key: string;
  }): Promise<AdmissionState>;
  /** A pause stops the running round through M05 after the goal is disarmed (D10). Optional so a port that cannot interrupt only loses the interruption, never the pause. */
  interruptTurn?(request: {
    readonly authority: TrustedAuthority;
    readonly sessionId: string;
  }): Promise<{
    readonly status: "accepted";
  } | {
    readonly status: "refused" | "unavailable";
    readonly detail?: string;
  }>;
  subscribeSettled(request: {
    readonly authority: TrustedAuthority;
    readonly scope: {
      readonly sessionId: string;
    } | {
      readonly rootSessionId: string;
    };
    readonly handler: (event: SettledEvent) => void;
  }): {
    readonly status: "subscribed";
    unsubscribe(): void;
  } | {
    readonly status: "refused" | "unavailable";
  };
}
/** T3's own receipt: does the thread hold a message with this id? `unavailable` is never read as absent. */
interface ThreadReceiptPort {
  hasMessage(sessionId: string, messageId: string): Promise<"present" | "absent" | "unavailable">;
}
/**
 * M05's goal-notice outbox as the Backend lends it (DV1): a fenced adapter that exposes only enqueue, deliver and state for the `goal-notice` kind under trusted Backend authority.
 * One entry per key; a repeat is `created:false`; after the Backend stops every call is `unavailable`. The goals service never writes a notice anywhere else.
 */
type NoticeState = "pending" | "attempting" | "inserted" | "recorded" | "abandoned" | "unknown";
interface NoticePort {
  enqueue(request: {
    readonly authority: TrustedAuthority;
    readonly sessionId: string;
    readonly key: string;
    readonly text: string;
  }): {
    readonly status: "queued";
    readonly created: boolean;
  } | {
    readonly status: "unavailable";
    readonly detail: string;
  } | Promise<{
    readonly status: "queued";
    readonly created: boolean;
  } | {
    readonly status: "unavailable";
    readonly detail: string;
  }>;
  deliver(request: {
    readonly authority: TrustedAuthority;
    readonly sessionId: string;
    readonly key: string;
  }): Promise<{
    readonly status: "delivered" | "held" | "uncertain" | "nothing";
  } | {
    readonly status: "unavailable";
    readonly detail: string;
  }>;
  /** `unknown` covers a key the outbox does not hold; it is never read as delivered. */
  state(request: {
    readonly authority: TrustedAuthority;
    readonly key: string;
  }): NoticeState | Promise<NoticeState>;
}
interface Clock {
  now(): string;
}
//#endregion
//#region src/decision.d.ts
/** `from` is the phase before (`null` = no goal yet); `to` the phase after. The store's strict fold and the service's planning both read this table. */
declare const TRANSITIONS: Readonly<Record<MutationOp, {
  readonly from: readonly (GoalPhase | null)[];
  readonly to: GoalPhase;
}>>;
/** The phase an op produces from `from`, or null when the op is illegal there. An edit keeps the phase. */
declare function transitionTarget(op: MutationOp, from: GoalPhase | null): GoalPhase | null;
declare const isObjective: (value: unknown) => value is string;
declare const isMaxRounds: (value: unknown) => value is number;
type NextAction = {
  readonly kind: "none";
} | {
  readonly kind: "reserve";
  readonly round: number;
} | {
  readonly kind: "block";
  readonly code: "round-limit";
} | {
  readonly kind: "pause";
} | {
  readonly kind: "disarm";
  readonly reason: string;
};
interface NextActionInput {
  readonly goal: GoalRecord | null;
  readonly armed: boolean;
  readonly settled: Pick<SettledEvent, "outcome" | "cause">;
  /** A goal round entered and had not settled before this event. */
  readonly roundWasRunning: boolean;
  readonly humanPending: boolean;
  readonly reservationOpen: boolean;
}
/** Decide, at one settle, what the goal does next. Pure: the same inputs always give the same action, and nothing here reads a clock, a store or a port. */
declare function nextAction(input: NextActionInput): NextAction;
/** The admission key of a round (D8): the same key can only ever name the same round of the same revision of the same goal. */
declare const roundKey: (goalId: string, revision: number, round: number) => string;
/** The retained DSH round prompt (dsh-goal-round-driver renderGoalRoundPrompt), objective JSON-quoted. The origin is record data, never parsed back from this text. */
declare function renderRoundPrompt(goal: Pick<GoalRecord, "objective" | "maxRounds">, round: number): string;
/** The one notice key of a terminal transition (D12): the revision is the one the terminal mutation wrote, so a second terminal call can never reuse it. */
declare const terminalNoticeKey: (goalId: string, revision: number) => string;
/** The one notice of a round a restart cut (D9): keyed by its round, so a repeated boot cannot send a second. */
declare const interruptedNoticeKey: (goalId: string, revision: number, round: number) => string;
declare function terminalNoticeText(goal: Pick<GoalRecord, "goalId" | "phase" | "roundsStarted" | "maxRounds" | "blocker">): string;
declare const interruptedNoticeText: (goalId: string, round: number) => string;
/** SHA-256 of UTF-8 text as lowercase hex: the digest M06 stores as the subject's revision. */
declare function sha256Hex(text: string): Promise<string>;
interface ProposalFields {
  readonly op: ProposalOp;
  readonly rootSessionId: string;
  readonly goalId: string | null;
  readonly baseRevision: number | null;
  readonly objective: string;
  readonly maxRounds: number;
}
/** The exact text the person sees. The service writes it, so the card names the change itself: operation, objective, cap, base revision and root. */
declare function proposalText(f: ProposalFields): string;
/** XC-23's re-arm (D24): the subject id names the goal and the exact revision, and the revision field is the digest of the text a person is shown. */
declare function rearmSubjectId(goalId: string, revision: number): string;
declare function rearmText(f: {
  readonly rootSessionId: string;
  readonly goalId: string;
  readonly revision: number;
  readonly objective: string;
  readonly maxRounds: number;
  readonly roundsStarted: number;
}): string;
//#endregion
//#region src/strict.d.ts
type Decoded<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly reason: string;
};
type Guard = (input: unknown, path: string) => string | null;
//#endregion
//#region src/client.d.ts
/** Reads (a version push only prompts a re-read) and human actions. `goal.rearm` takes the grant's origin id; every other action takes none. */
declare const XC23_READS: readonly ["goal.snapshot", "workflow.runs"];
declare const XC23_ACTIONS: readonly ["goal.propose", "goal.pause", "goal.clear", "goal.rearm", "workflow.cancel"];
type Xc23Action = (typeof XC23_ACTIONS)[number];
interface GoalView {
  readonly goalId: string;
  readonly revision: number;
  readonly objective: string;
  readonly phase: GoalPhase;
  readonly roundsStarted: number;
  readonly maxRounds: number;
  readonly blocker?: {
    readonly code: string;
    readonly message: string;
  };
  readonly armed: boolean;
  readonly needsRearm: boolean;
  readonly awaitingHuman?: {
    readonly proposalId: string;
    readonly interactionId: string;
  };
  /** Reported once after a restart cut a running round: the round is counted, and the goal waits for a person. */
  readonly interrupted?: "backend-restarted";
  /** Present when a re-arm is offered; M10 passes `subject` to M06's `authorization.grant` and the returned origin id to `goal.rearm`. */
  readonly rearm?: {
    readonly subject: {
      readonly type: "goal-mutation";
      readonly id: string;
      readonly revision: string;
    };
    readonly text: string;
  };
}
declare const goalViewGuard: Guard;
declare const decodeGoalView: (input: unknown) => Decoded<GoalView>;
/** `goal.snapshot(root)` answers a view or no goal; `unavailable` is a third answer and is never "no goal". */
type GoalSnapshotAnswer = {
  readonly status: "ok";
  readonly goal: GoalView | null;
  readonly version: number;
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
interface ProposeRequest {
  readonly rootSessionId: string;
  readonly op: ProposalOp;
  readonly objective?: string;
  readonly maxRounds?: number;
  readonly baseRef?: {
    readonly goalId: string;
    readonly revision: number;
  };
}
interface PauseRequest {
  readonly rootSessionId: string;
  readonly goalId: string;
  readonly revision: number;
}
interface RearmRequest {
  readonly rootSessionId: string;
  readonly goalId: string;
  readonly revision: number;
  readonly originId: string;
}
interface WorkflowCancelRequest {
  readonly rootSessionId: string;
  readonly runId: string;
}
declare const decodeProposeRequest: (input: unknown) => Decoded<ProposeRequest>;
declare const decodePauseRequest: (input: unknown) => Decoded<PauseRequest>;
declare const decodeClearRequest: (input: unknown) => Decoded<PauseRequest>;
declare const decodeRearmRequest: (input: unknown) => Decoded<RearmRequest>;
declare const decodeWorkflowCancelRequest: (input: unknown) => Decoded<WorkflowCancelRequest>;
/** Decode one action request by its name; an unknown action name is a refusal (no action grants arming but `goal.propose`'s card and the client-only `goal.rearm`). */
declare function decodeXc23Request(action: string, input: unknown): Decoded<unknown>;
/** The actions that arm or re-arm a goal: exactly the two that carry a human decision (D5). The model's tool schemas must name neither the re-arm nor an origin id. */
declare const ARMING_ACTIONS: readonly Xc23Action[];
//#endregion
//#region src/backend/store.d.ts
/** The file operations the store needs, so a test can cut at each publication boundary. `read` returns null when the file is absent and throws when it cannot be read. */
interface StoreFs {
  mkdir(dir: string): void;
  read(path: string): string | null;
  append(path: string, text: string): void;
  /** Writes a same-directory temporary file and returns its path. */
  writeTemp(path: string, text: string): string;
  rename(from: string, to: string): void;
  list(dir: string): string[];
}
declare const nodeStoreFs: StoreFs;
/** What the journal folds to for one root. Plain data: nothing here is permission. */
interface RootState {
  readonly rootSessionId: string;
  readonly goal: GoalRecord | null;
  /** Every goal id that was ever cleared; ids are never reused. */
  readonly tombstones: readonly string[];
  readonly proposals: readonly Proposal[];
  readonly closedProposals: Readonly<Record<string, string>>;
  /** SHA-256 of each origin id already consumed (the id itself is not kept). */
  readonly consumed: readonly string[];
  readonly reservation: Reservation | null;
  readonly running: RunningRound | null;
  readonly audit: {
    readonly armed: number;
    readonly disarmed: number;
    readonly interrupted: number;
  };
  /** The round key (`goalId:revision:round`) the last `interrupted` audit line named: a boot reports a cut round once and stays silent about the same round afterwards. Never permission. */
  readonly lastInterrupted: string | null;
  readonly seq: number;
}
type StoreRead = {
  readonly status: "ok";
  readonly state: RootState;
  readonly tornTail: boolean;
} | {
  readonly status: "corrupt";
  readonly reason: string;
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
/** The condition a write holds at write time: no goal yet, this exact goal revision, or none (a line that carries no goal fact, such as a proposal or an audit). */
type Expect = {
  readonly kind: "none";
} | {
  readonly kind: "ref";
  readonly goalId: string;
  readonly revision: number;
} | {
  readonly kind: "any";
};
type AppendResult = {
  readonly status: "ok";
  readonly state: RootState;
  readonly seq: number;
  readonly snapshot: "written" | "stale";
} | {
  readonly status: "refused";
  readonly code: GoalCode;
  readonly detail: string;
} | {
  readonly status: "corrupt";
  readonly reason: string;
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
interface StoreDeps {
  readonly stateRoot: string;
  readonly fs?: StoreFs;
  readonly clock: Clock;
  /** Throws unless this process holds the Backend owner lock. A throw fails the write closed (`unavailable`). */
  readonly owner: {
    assertHeld(): void;
  };
}
declare const originKey: (originId: string) => string;
/** The strict fold step: the next state, or why the line is not legal here. Pure; the store, the tests and any reader share it. */
declare function applyLine(state: RootState, line: JournalLine): RootState | string;
interface GoalStore {
  read(rootSessionId: string): StoreRead;
  /** The roots that have a journal, from each file's own header; `unreadable` names files whose header could not be read (reported, never skipped silently). */
  listRoots(): {
    readonly status: "ok";
    readonly roots: readonly string[];
    readonly unreadable: readonly string[];
  } | {
    readonly status: "unavailable";
    readonly detail: string;
  };
  /** Hold `expect` at write time, check the line is legal, make it durable, then publish the derived snapshot. One writer per root; calls for one root run in order. */
  append(rootSessionId: string, expect: Expect, body: JournalBody): Promise<AppendResult>;
}
declare function openGoalStore(deps: StoreDeps): GoalStore;
//#endregion
//#region src/backend/service.d.ts
interface GoalServiceDeps {
  readonly store: GoalStore;
  readonly resolver: RootResolver;
  readonly interaction: InteractionPort;
  readonly admission: AdmissionPort;
  readonly receipts: ThreadReceiptPort;
  readonly clock: Clock;
  readonly newId: () => string;
  /** Configured values; the caller validates them with `validateGoalParameters` at startup and refuses to start without them. */
  readonly parameters: GoalParameterValues;
  /** The Backend module name M05 sees as the trusted authority. */
  readonly module?: string;
  /** Whether a person's message is queued for the session (D7); absent means "no". */
  readonly humanPending?: (sessionId: string) => boolean;
  /** M05's goal-notice outbox through the fenced adapter (DV1). Absent: terminal and interrupted notices are not written, and nothing else changes. */
  readonly notices?: NoticePort;
}
interface GoalProposal {
  readonly op: ProposalOp;
  readonly objective?: string;
  readonly maxRounds?: number;
  readonly baseRef?: {
    readonly goalId: string;
    readonly revision: number;
  };
}
interface BootReport {
  readonly status: "ok" | "unavailable";
  readonly detail?: string;
  /** Rounds that were running at the restart and are now counted once; the goal waits for a person. */
  readonly interrupted: readonly {
    readonly rootSessionId: string;
    readonly goalId: string;
    readonly round: number;
  }[];
  /** Roots whose open reservation could not be reconciled: re-arm is refused for them until a read succeeds. */
  readonly pending: readonly string[];
  readonly corrupt: readonly {
    readonly rootSessionId: string;
    readonly reason: string;
  }[];
}
interface GoalService {
  snapshot(sessionId: string): Promise<GoalResult<{
    readonly goal: GoalView | null;
  }>>;
  propose(sessionId: string, request: GoalProposal): Promise<GoalResult<never>>;
  pause(sessionId: string, ref: {
    readonly goalId: string;
    readonly revision: number;
  }): Promise<GoalResult<GoalView>>;
  clear(sessionId: string, ref: {
    readonly goalId: string;
    readonly revision: number;
  }): Promise<GoalResult<null>>;
  /** The model's `complete`: accepted only for the exact live running round of this ref (D4, D12). It never takes an origin. */
  complete(sessionId: string, ref: {
    readonly goalId: string;
    readonly revision: number;
  }): Promise<GoalResult<GoalView>>;
  /** The model's `block`: the running round's ref, a reason, and at least N rounds since the last objective or cap change (D11). */
  block(sessionId: string, ref: {
    readonly goalId: string;
    readonly revision: number;
  }, reason: string): Promise<GoalResult<GoalView>>;
  /** XC-23's client-only `goal.rearm`: the grant's origin id, verified against the exact re-arm subject, then one conditional commit that arms (D5, D24). */
  rearm(sessionId: string, request: {
    readonly goalId: string;
    readonly revision: number;
    readonly originId: string;
  }): Promise<GoalResult<GoalView>>;
  /** The observer's hook (D10): a new main root forked from `parentSessionId` gets one paused copy of the parent's goal; the parent is untouched. */
  onSessionForked(fork: {
    readonly parentSessionId: string;
    readonly childSessionId: string;
  }): Promise<GoalResult<{
    readonly copy: "created" | "none" | "already";
  }>>;
  /** DV2's predicate for T3's recovery pass and shutdown preparation: a round in flight for this session, or `unknown` (read as in flight). Read-only and synchronous. */
  roundInFlight(sessionId: string): "in-flight" | "none" | "unknown";
  /** Reconcile every journal and subscribe to settles. Reads only: it never calls `admitTurn` and arms nothing. */
  start(): Promise<BootReport>;
  onSettled(event: SettledEvent): Promise<void>;
  /** The outcome a proposal ended with (`approved` or a code/reason), once it ended. */
  proposalOutcome(proposalId: string): string | undefined;
  isArmed(rootSessionId: string): boolean;
  /** Resolves when every proposal wait and round task now running has finished. */
  idle(): Promise<void>;
  stop(): void;
}
declare function createGoalService(deps: GoalServiceDeps): GoalService;
//#endregion
export { ARMING_ACTIONS, AdmissionPort, AdmissionState, AdmitAnswer, AppendResult, AuditEvent, Blocker, BootReport, Clock, Expect, ForkedFrom, GOALS_FORMAT, GOALS_PACKAGE, GOAL_CODES, GOAL_PARAMETERS, GOAL_PARAMETER_ACCEPTANCE, GOAL_PARAMETER_NAMES, GOAL_PHASES, GoalCode, GoalParameterName, GoalParameterValues, GoalPhase, GoalProposal, GoalRecord, GoalResult, GoalService, GoalServiceDeps, GoalSnapshotAnswer, GoalStore, GoalView, InteractionPort, InteractionView, JournalBody, JournalLine, MutationOp, NextAction, NextActionInput, NoticePort, NoticeState, OriginCode, Parameter, ParameterStatus, PauseRequest, Proposal, ProposalFields, ProposalOp, ProposeRequest, RearmRequest, RefusalCode, Reservation, RootResolution, RootResolver, RootState, RunningRound, SettledEvent, StoreDeps, StoreFs, StoreRead, Subject, TRANSITIONS, ThreadReceiptPort, TrustedAuthority, WorkflowCancelRequest, XC23_ACTIONS, XC23_READS, Xc23Action, applyLine, createGoalService, decodeClearRequest, decodeGoalView, decodePauseRequest, decodeProposeRequest, decodeRearmRequest, decodeWorkflowCancelRequest, decodeXc23Request, goalViewGuard, interruptedNoticeKey, interruptedNoticeText, isMaxRounds, isObjective, nextAction, nodeStoreFs, openGoalStore, originKey, proposalText, rearmSubjectId, rearmText, renderRoundPrompt, roundKey, sha256Hex, terminalNoticeKey, terminalNoticeText, transitionTarget, validateGoalParameters };