import fsp from "node:fs/promises";
//#region src/vocabulary.d.ts
/** `authorization` can be created only by Backend services (D8); an Agent may create the first two. */
declare const INTERACTION_KINDS: readonly ["question", "plan-review", "authorization"];
type InteractionKind = (typeof INTERACTION_KINDS)[number];
/** `closed` is an event, never a state: closing a card changes nothing (D3). */
declare const INTERACTION_STATES: readonly ["pending", "continued", "answered", "cancelled", "superseded"];
type InteractionState = (typeof INTERACTION_STATES)[number];
/** Why a wait ended (D5). `interaction.release` accepts only `abort`; the others are written by the Backend itself. */
declare const WAIT_LOST_CAUSES: readonly ["abort", "process-exit", "backend-restart", "host-stop"];
type WaitLostCause = (typeof WAIT_LOST_CAUSES)[number];
/** What a `continued` record may name as the reason its wait ended: a wait-lost cause, or the Backend deadline (`timed_out`, D4). */
declare const CONTINUED_CAUSES: readonly ["abort", "process-exit", "backend-restart", "host-stop", "timed_out"];
type ContinuedCause = (typeof CONTINUED_CAUSES)[number];
/** HumanOrigin kinds (XC-17). There is no `direct-message` kind (D8). */
declare const ORIGIN_KINDS: readonly ["answer", "plan-decision", "authorization", "mode-change"];
type OriginKind = (typeof ORIGIN_KINDS)[number];
declare const ORIGIN_DECISIONS: readonly ["answered", "approved", "changes_requested", "cancelled", "declined", "set-active", "set-inactive"];
type OriginDecision = (typeof ORIGIN_DECISIONS)[number];
declare const INTERACTION_CODE_CLASSES: Readonly<{
  readonly INTERACTION_ORIGIN_NOT_HUMAN: "refusal";
  readonly INTERACTION_REVIEW_NOT_PERMITTED: "refusal";
  readonly INTERACTION_NOT_IN_PLAN_MODE: "refusal";
  readonly INTERACTION_ANSWER_INVALID: "refusal";
  readonly INTERACTION_GRANT_INVALID: "refusal";
  readonly INTERACTION_ALREADY_SETTLED: "conflict";
  readonly INTERACTION_STALE_REVISION: "conflict";
  readonly ORIGIN_STALE: "conflict";
  readonly INTERACTION_NOT_FOUND: "absence";
  readonly ORIGIN_NOT_FOUND: "absence";
  readonly ORIGIN_MISMATCH: "absence";
  readonly INTERACTION_UNAVAILABLE: "failure";
  readonly INTERACTION_DELIVERY_FAILED: "failure";
  readonly INTERACTION_FORMAT_UNSUPPORTED: "failure";
}>;
type InteractionCode = keyof typeof INTERACTION_CODE_CLASSES;
//#endregion
//#region src/model.d.ts
/** `detail` and `context` are raw Markdown: stored and shown, never interpreted as an answer. */
interface QuestionOption {
  readonly label: string;
  readonly description?: string;
  readonly context?: string;
}
interface Question {
  readonly id: string;
  readonly question: string;
  readonly header?: string;
  readonly detail?: string;
  readonly options?: readonly QuestionOption[];
  readonly multiSelect?: boolean;
}
interface QuestionBatch {
  readonly questions: readonly Question[];
}
interface Answer {
  readonly id: string;
  readonly selected: readonly string[];
  readonly custom?: string;
  readonly skipped: boolean;
}
/** What the human saw, named by type, id and the SHA-256 of the exact content (XC-17 `subject`). */
interface Subject {
  readonly type: string;
  readonly id: string;
  readonly revision: string;
}
type InteractionContent = QuestionBatch | {
  readonly plan: string;
  readonly reviewNumber: number;
} | {
  readonly text: string;
  readonly subject: Subject;
};
type Resolution = {
  readonly type: "answers";
  readonly answers: readonly Answer[];
  readonly originId: string;
} | {
  readonly type: "decision";
  readonly decision: "approved" | "changes_requested";
  readonly originId: string;
  readonly feedback?: string;
} | {
  readonly type: "cancelled";
  readonly originId?: string;
  readonly feedback?: string;
  readonly cause?: "mode-off";
} | {
  readonly type: "superseded";
  readonly by: string;
};
/** A late answer's delivery to the asker's thread (D5): the receipt, not message text, proves acceptance. */
type Delivery = {
  readonly status: "pending";
} | {
  readonly status: "delivered";
  readonly commandId: string;
} | {
  readonly status: "failed";
  readonly code: string;
};
interface InteractionRecord {
  readonly interactionId: string;
  readonly kind: InteractionKind;
  readonly state: InteractionState;
  /** SHA-256 of the exact content the human sees; a decision names it (D6, D9). */
  readonly revision: string;
  readonly rootSessionId: string;
  readonly sessionId: string;
  /** The asker's tool call id; absent for a Backend-created authorization. (session, call id) is the idempotency key. */
  readonly askCallId?: string;
  readonly createdAt: string;
  readonly held: boolean;
  readonly waitMs?: number;
  readonly deadlineAt?: string;
  readonly continuedCause?: ContinuedCause;
  readonly content: InteractionContent;
  readonly resolution?: Resolution;
  readonly delivery?: Delivery;
}
interface EventBase {
  readonly at: string;
  readonly rootSessionId: string;
  readonly sessionId: string;
}
interface InteractionEventBase extends EventBase {
  readonly interactionId: string;
}
type InteractionEvent = (InteractionEventBase & {
  readonly type: "created";
  readonly kind: InteractionKind;
  readonly revision: string;
}) | (InteractionEventBase & {
  readonly type: "closed";
}) | (InteractionEventBase & {
  readonly type: "held";
}) | (InteractionEventBase & {
  readonly type: "timed_out";
}) | (InteractionEventBase & {
  readonly type: "wait_lost";
  readonly cause: WaitLostCause;
}) | (InteractionEventBase & {
  readonly type: "answered";
  readonly originId: string;
}) | (InteractionEventBase & {
  readonly type: "cancelled";
  readonly originId?: string;
  readonly cause?: "mode-off";
}) | (InteractionEventBase & {
  readonly type: "superseded";
  readonly by: string;
}) | (InteractionEventBase & {
  readonly type: "delivered";
  readonly commandId: string;
}) | (InteractionEventBase & {
  readonly type: "delivery_failed";
  readonly code: string;
}) | (EventBase & {
  readonly type: "mode_set";
  readonly active: boolean;
  readonly modeRevision: number;
  readonly originId: string;
}) | (EventBase & {
  readonly type: "granted";
  readonly originId: string;
  readonly subject: Subject;
});
/** The connection's authenticated client session, taken from the transport and never from a payload (D6). */
interface Actor {
  readonly clientSessionId: string;
  readonly grantedScopes: readonly string[];
  readonly authenticatedAt: string;
}
/** One immutable record that an authenticated client session decided something about a named revision. `interactionId` is null only for a mode change or a grant. */
interface HumanOrigin {
  readonly originId: string;
  readonly kind: OriginKind;
  readonly interactionId: string | null;
  readonly subject: Subject;
  readonly decision: OriginDecision;
  readonly payloadDigest: string | null;
  readonly actor: Actor;
  readonly sessionId: string;
  readonly rootSessionId: string;
  readonly at: string;
}
interface OriginExpectation {
  readonly kind?: OriginKind;
  readonly subject?: {
    readonly type?: string;
    readonly id?: string;
    readonly revision?: string;
  };
  readonly sessionId?: string;
}
/** The field an `ORIGIN_MISMATCH` names; a different revision is `ORIGIN_STALE`, not a mismatch. */
type OriginMismatchField = "kind" | "subject.type" | "subject.id" | "sessionId";
type OriginVerdict = {
  readonly verified: true;
  readonly origin: HumanOrigin;
} | {
  readonly verified: false;
  readonly code: "ORIGIN_NOT_FOUND" | "ORIGIN_STALE";
} | {
  readonly verified: false;
  readonly code: "ORIGIN_MISMATCH";
  readonly field: OriginMismatchField;
};
interface PlanMode {
  readonly sessionId: string;
  readonly active: boolean;
  readonly modeRevision: number;
}
type TaskStatus = "pending" | "in_progress" | "completed";
interface Todo {
  readonly content: string;
  readonly status: TaskStatus;
}
/** The Backend's rebuildable copy of a session's task list; the authority is the Pi session entry. */
interface TaskView {
  readonly sessionId: string;
  readonly entryId: string;
  readonly seq: number;
  readonly todos: readonly Todo[];
  readonly publishedAt: string;
}
interface QuestionEvidenceArgs {
  readonly rootSessionId: string;
  readonly askCallId: string;
  readonly askerSessionId?: string;
}
/** `answered` is true only for state `answered` with a verified human origin (and then `answers` and `originId` are present). */
interface QuestionEvidence {
  readonly state: InteractionState;
  readonly answered: boolean;
  readonly startedAt: string;
  readonly answeredAt?: string;
  readonly answers?: readonly Answer[];
  readonly originId?: string;
  readonly interactionId: string;
  readonly ambiguous?: boolean;
}
/** A direct call's success carries the affected record or view; every failure carries one of the canonical codes. */
type Outcome<T, C extends InteractionCode = InteractionCode> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly code: C;
  readonly detail?: string;
};
/** A settled or undelivered record comes back with the code, so a caller sees the truth without a second read. */
type RecordOutcome = {
  readonly ok: true;
  readonly value: InteractionRecord;
} | {
  readonly ok: false;
  readonly code: "INTERACTION_ALREADY_SETTLED" | "INTERACTION_DELIVERY_FAILED";
  readonly record: InteractionRecord;
} | {
  readonly ok: false;
  readonly code: Exclude<InteractionCode, "INTERACTION_ALREADY_SETTLED" | "INTERACTION_DELIVERY_FAILED">;
  readonly detail?: string;
};
/** Unavailable is first-class: a read, parse, lock or version failure is never "no interaction", an empty store or a missing origin. */
interface Unavailable {
  readonly unavailable: true;
  readonly reason: string;
}
//#endregion
//#region src/ports.d.ts
type PortRead<T> = {
  readonly kind: "found";
  readonly value: T;
} | {
  readonly kind: "absent";
} | {
  readonly kind: "unavailable";
  readonly reason: string;
};
/** The `interactions/FORMAT` declaration; the code supports exactly version 1. */
interface StoreFormat {
  readonly store: string;
  readonly formatVersion: number;
  readonly writtenBy: string;
}
/**
 * One atomic publication: the journal events are appended and flushed first, then the record, origin and mode files are published, so a partial
 * publication cannot expose a decision without its origin or an approval without its mode transition. `expect` is compared AT the write.
 */
interface Commit {
  readonly rootSessionId: string;
  /** The record this commit changes and the state and content revision it saw; a mismatch at the write is a `conflict`, not a stale read. */
  readonly expect?: {
    readonly interactionId: string;
    readonly state: InteractionRecord["state"];
    readonly revision: string;
  };
  readonly expectModeRevision?: {
    readonly sessionId: string;
    readonly modeRevision: number;
  };
  readonly events: readonly InteractionEvent[];
  readonly record?: InteractionRecord;
  readonly origin?: HumanOrigin;
  readonly mode?: PlanMode;
}
type CommitOutcome = {
  readonly kind: "committed";
} | {
  readonly kind: "conflict";
  readonly current: InteractionRecord | PlanMode;
} | {
  readonly kind: "unavailable";
  readonly reason: string;
} |
/** The write may or may not have landed (a lost reply). The caller retries idempotently; it must not claim non-execution. */
{
  readonly kind: "unknown";
  readonly reason: string;
};
interface InteractionStorePort {
  /** An absent whole `interactions/` is a new store; a nonempty store without a supported declaration is `unavailable` (INTERACTION_FORMAT_UNSUPPORTED). */
  readFormat(): Promise<PortRead<StoreFormat>>;
  /** Writes `FORMAT` once, only into an absent store, inside the protected lifecycle after the owner lock. */
  initialize(format: StoreFormat): Promise<{
    readonly kind: "created";
  } | {
    readonly kind: "unavailable";
    readonly reason: string;
  }>;
  readRecord(interactionId: string): Promise<PortRead<InteractionRecord>>;
  /** Every authoritative record, for the start-up index rebuild; one unreadable record makes the listing `unavailable` for that record, never silently shorter. */
  listRecords(): Promise<PortRead<readonly PortRead<InteractionRecord>[]>>;
  readOrigin(originId: string): Promise<PortRead<HumanOrigin>>;
  readMode(sessionId: string): Promise<PortRead<PlanMode>>;
  readJournal(rootSessionId: string): Promise<PortRead<readonly InteractionEvent[]>>;
  commit(commit: Commit): Promise<CommitOutcome>;
  /**
   * Completes any commit whose journal line was flushed but whose files were not all published (a crash between the two), before the start-up index
   * rebuild; a journal that cannot be read makes only its own root unavailable. Optional: a store with a single atomic write needs none.
   */
  recover?(): Promise<{
    readonly kind: "recovered";
    readonly replayed: number;
  } | {
    readonly kind: "unavailable";
    readonly reason: string;
  }>;
  /** The derived task view (rebuildable, not authoritative). */
  readTasks(sessionId: string): Promise<PortRead<TaskView>>;
  writeTasks(view: TaskView): Promise<{
    readonly kind: "written";
  } | {
    readonly kind: "unavailable";
    readonly reason: string;
  }>;
}
interface ClockPort {
  /** ISO-8601 UTC, the Backend's clock. */
  now(): string;
  nowMs(): number;
}
/** Deterministic seam for interaction, origin and journal identifiers (opaque, backend-assigned, unique). */
interface IdPort {
  next(prefix: "int" | "org"): string;
}
interface DispatchRequest {
  /** Derived from the interaction id, so T3's receipt refuses a repeat. */
  readonly commandId: string;
  /** The asker's session, which selects the thread. */
  readonly sessionId: string;
  readonly rootSessionId: string;
  /** "Answer to question <id>: …" */
  readonly text: string;
}
type DispatchOutcome = {
  readonly kind: "accepted";
} | {
  readonly kind: "rejected";
  readonly error: string;
} | {
  readonly kind: "unknown";
  readonly reason: string;
};
type ReceiptLookup = {
  readonly kind: "accepted";
} | {
  readonly kind: "rejected";
  readonly error: string;
} | {
  readonly kind: "absent";
} | {
  readonly kind: "unavailable";
  readonly reason: string;
};
/** The adapter dispatches in-process through T3's message intake with the decided provenance (user/server/auto); the receipt, not text, proves acceptance. */
interface TurnDispatchPort {
  dispatch(request: DispatchRequest): Promise<DispatchOutcome>;
  receipt(commandId: string): Promise<ReceiptLookup>;
}
/** The caller's XC-1 `project` facts. The Agent cannot influence them. */
interface ProjectFacts {
  readonly root: string;
  readonly place: string;
  readonly settingsPaths: {
    readonly cycles?: string;
  };
  readonly problems: readonly string[];
}
interface ProjectResolverPort {
  /** Read-only: resolves the session's recorded project, never a path the caller names. */
  resolveProject(sessionId: string): Promise<{
    readonly kind: "resolved";
    readonly project: ProjectFacts;
  } | {
    readonly kind: "absent";
  } | {
    readonly kind: "unavailable";
    readonly reason: string;
  }>;
}
type FileRead = {
  readonly kind: "text";
  readonly text: string;
} | {
  readonly kind: "absent";
} | {
  readonly kind: "unavailable";
  readonly reason: string;
};
/** Reads one file under a project root; a path that leaves the root is `unavailable`. */
interface FileReadPort {
  readText(root: string, relativePath: string): Promise<FileRead>;
}
type GitRead = {
  readonly kind: "ok";
  readonly stdout: string;
} | {
  readonly kind: "failed";
  readonly code: string;
} | {
  readonly kind: "aborted";
} | {
  readonly kind: "unavailable";
  readonly reason: string;
};
/** Runs one fixed read-only Git command with no shell, cancellable, output capped; the adapter refuses any command outside its fixed set (step 22). */
interface GitReadPort {
  run(root: string, argv: readonly string[], signal?: AbortSignal): Promise<GitRead>;
}
/** Every effect the interaction core may use. The Backend registration supplies one object of this shape. */
interface InteractionPorts {
  readonly store: InteractionStorePort;
  readonly clock: ClockPort;
  readonly ids: IdPort;
  readonly dispatch: TurnDispatchPort;
  readonly projects: ProjectResolverPort;
  readonly files: FileReadPort;
  readonly git: GitReadPort;
}
//#endregion
//#region src/api.d.ts
interface CreateAuthorizationInput {
  /** The session the authorization is for; C1 derives the root itself. */
  readonly sessionId: string;
  /** Text the Backend service (M07) authored; the human sees exactly this, with the options Approve and Decline. */
  readonly text: string;
  /** What is being authorized; `subject.revision` is the digest of the content M07 holds, which a later verification compares. */
  readonly subject: Subject;
}
interface AwaitOptions {
  readonly signal?: AbortSignal;
}
interface InteractionDirectApi {
  /** XC-8 for M04's `resolve`: `answered` is true only for state `answered` with a verified human origin. Durable; `unavailable` is first-class. */
  questionEvidence(args: QuestionEvidenceArgs): Promise<Outcome<QuestionEvidence, "INTERACTION_NOT_FOUND" | "INTERACTION_UNAVAILABLE">>;
  /** XC-17 for M07: a caller treats `unavailable` and any `verified: false` as "not a human decision". Writes nothing. */
  verifyHumanOrigin(originId: string, expect?: OriginExpectation): Promise<OriginVerdict | Unavailable>;
  /** Only a Backend service may create an `authorization` interaction (D8); an Agent operation cannot reach this call. */
  createAuthorization(input: CreateAuthorizationInput): Promise<Outcome<InteractionRecord, "INTERACTION_UNAVAILABLE" | "INTERACTION_GRANT_INVALID">>;
  /** One bounded segment: settles within the segment bound with the interaction's current state. */
  awaitInteraction(interactionId: string, options?: AwaitOptions): Promise<Outcome<InteractionRecord, "INTERACTION_NOT_FOUND" | "INTERACTION_UNAVAILABLE">>;
  /** M05 calls this inside spawn and fork and rolls back on failure: a fork copies the parent's mode, a spawn starts inactive (D10). */
  inheritPlanMode(parentSessionId: string, childSessionId: string, relation: "fork" | "spawn"): Promise<Outcome<PlanMode, "INTERACTION_UNAVAILABLE">>;
  /** Moves each `pending` interaction without a live segment to `continued` (D5); at Backend start with no argument, and when a session resumes with its id. Never re-asks. */
  reconcileWaits(sessionId?: string): Promise<Outcome<{
    readonly continued: readonly string[];
  }, "INTERACTION_UNAVAILABLE">>;
}
//#endregion
//#region src/backend/file-store.d.ts
/** The subset of `node:fs/promises` the store uses: tests wrap the real module to inject errno failures. */
type FileSystemOps = Pick<typeof fsp, "readFile" | "writeFile" | "mkdir" | "rename" | "readdir" | "stat" | "open">;
type CrashPoint = "before-journal" | "after-journal-flush" | "after-origin" | "after-record" | "after-mode" | "before-ack";
/** A test seam: throwing from `point` simulates a crash at that moment of a commit. */
interface CrashHooks {
  point(name: CrashPoint): void | Promise<void>;
}
interface FileStoreOptions {
  readonly fs?: FileSystemOps;
  readonly hooks?: CrashHooks;
}
declare function createFileInteractionStore(stateRoot: string, options?: FileStoreOptions): InteractionStorePort;
//#endregion
//#region src/core.d.ts
/** Stable, derived from the interaction id alone, so T3's receipt refuses a repeat. */
declare const deliveryCommandId: (interactionId: string) => string;
/** "Answer to question <id>: …" — a readable rendering of the stored answers. The receipt, not this text, proves delivery; the origin proves the human act. */
declare function answerDeliveryText(record: InteractionRecord): string;
//#endregion
//#region src/backend/service.d.ts
/** Transport-derived identity of an Agent call (never a payload field). */
interface AgentIdentity {
  readonly sessionId: string;
  readonly rootSessionId: string;
}
/** Connection-derived identity of a client action (never a payload field). */
interface ClientIdentity {
  readonly actor: Actor;
}
interface Scheduler {
  after(ms: number, fn: () => void): () => void;
}
interface InteractionServiceDeps {
  readonly store: InteractionStorePort;
  readonly clock: ClockPort;
  readonly ids: IdPort;
  /** Dispatch + receipt lookup into T3. Absent: a late answer's delivery stays pending (visible), nothing is dispatched. */
  readonly dispatch?: TurnDispatchPort;
  /** Timers for segments and the lapse sweep; defaults to unref'd `setTimeout`. Tests inject a manual one. */
  readonly scheduler?: Scheduler;
  /** The host's independent check that the actor may operate the thread of the interaction (D6); absent: only the scope is checked. */
  readonly canOperate?: (actor: Actor, target: {
    readonly sessionId: string;
    readonly rootSessionId: string;
  }) => boolean | Promise<boolean>;
  readonly writtenBy?: string;
}
type CreateArgs = {
  readonly kind: "question";
  readonly callId: string;
  readonly questions: readonly Question[];
  readonly waitMs?: number;
} | {
  readonly kind: "plan-review";
  readonly callId: string;
  readonly plan: string;
};
interface AnswerPayload {
  readonly interactionId: string;
  readonly revision: string;
  readonly answers: readonly Answer[];
}
interface Snapshot {
  readonly rootSessionId: string;
  readonly version: number;
  readonly interactions: readonly InteractionRecord[];
}
interface ChangeEvent {
  readonly rootSessionId: string;
  readonly version: number;
}
/** The XC-7 drain report: waiter identifiers. */
interface DrainReport {
  readonly released: string[];
  readonly stopped: string[];
  readonly transferred: string[];
  readonly stillLive: string[];
}
interface RedeliverReport {
  readonly delivered: string[];
  readonly failed: string[];
  readonly pending: string[];
}
type CreateCode = "INTERACTION_ANSWER_INVALID" | "INTERACTION_REVIEW_NOT_PERMITTED" | "INTERACTION_UNAVAILABLE";
type ReadCode = "INTERACTION_NOT_FOUND" | "INTERACTION_UNAVAILABLE";
interface InteractionService extends InteractionDirectApi {
  /** Once, after the owner lock: validates or creates FORMAT, redoes a flushed-but-unpublished commit, rebuilds the indexes and reconciles every pending wait. */
  start(): Promise<Outcome<{
    readonly continued: readonly string[];
  }, "INTERACTION_FORMAT_UNSUPPORTED" | "INTERACTION_UNAVAILABLE">>;
  create(who: AgentIdentity, args: CreateArgs): Promise<Outcome<InteractionRecord, CreateCode>>;
  awaitSegment(who: AgentIdentity, args: {
    readonly interactionId: string;
  }, options?: {
    readonly signal?: AbortSignal;
  }): Promise<Outcome<InteractionRecord, ReadCode>>;
  release(who: AgentIdentity, args: {
    readonly interactionId: string;
    readonly cause: "abort";
  }): Promise<Outcome<InteractionRecord, ReadCode>>;
  snapshot(rootSessionId: string): Promise<Outcome<Snapshot, ReadCode>>;
  answer(who: ClientIdentity, payload: AnswerPayload): Promise<RecordOutcome>;
  redeliver(sessionId?: string): Promise<Outcome<RedeliverReport, "INTERACTION_UNAVAILABLE">>;
  sweep(): Promise<Outcome<{
    readonly continued: readonly string[];
  }, "INTERACTION_UNAVAILABLE">>;
  onChange(listener: (event: ChangeEvent) => void): () => void;
  drain(): Promise<DrainReport>;
}
declare function createInteractionService(deps: InteractionServiceDeps): InteractionService;
//#endregion
export { type AgentIdentity, type AnswerPayload, type AwaitOptions, type ChangeEvent, type ClientIdentity, type ClockPort, type Commit, type CommitOutcome, type CrashHooks, type CrashPoint, type CreateArgs, type CreateAuthorizationInput, type DispatchOutcome, type DispatchRequest, type DrainReport, type FileRead, type FileReadPort, type FileStoreOptions, type FileSystemOps, type GitRead, type GitReadPort, type IdPort, type InteractionDirectApi, type InteractionPorts, type InteractionService, type InteractionServiceDeps, type InteractionStorePort, type PortRead, type ProjectFacts, type ProjectResolverPort, type ReceiptLookup, type RedeliverReport, type Scheduler, type Snapshot, type StoreFormat, type TurnDispatchPort, answerDeliveryText, createFileInteractionStore, createInteractionService, deliveryCommandId };