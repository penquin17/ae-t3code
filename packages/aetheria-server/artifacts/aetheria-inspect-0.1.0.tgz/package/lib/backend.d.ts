//#region src/types.d.ts
declare const INSPECT_PACKAGE: "@aetheria/inspect";
declare const INSPECT_LIST_OPERATION: "inspect.list";
declare const INSPECT_QUERY_OPERATION: "inspect.query";
/** Exactly two operations exist. Any other `inspect.*` name is a verb the contract does not have. */
declare const INSPECT_OPERATIONS: readonly ["inspect.list", "inspect.query"];
type InspectOperation = (typeof INSPECT_OPERATIONS)[number];
declare const INSPECT_HOSTS: readonly ["agent", "backend", "client"];
type InspectHost = (typeof INSPECT_HOSTS)[number];
declare const INSPECT_STATES: readonly ["active", "inactive", "unsupported", "failed", "absent"];
type InspectState = (typeof INSPECT_STATES)[number];
declare const INSPECT_OUTCOMES: readonly ["ok", "no-client", "ambiguous", "disconnected", "timeout", "forbidden", "unavailable", "region-not-found", "schema-unsupported", "truncated"];
type InspectOutcome = (typeof INSPECT_OUTCOMES)[number];
/** An outcome that carries the answer: `truncated` says the answer is partial. Every other outcome carries no data. */
declare const INSPECT_DATA_OUTCOMES: readonly ["ok", "truncated"];
type InspectDataOutcome = (typeof INSPECT_DATA_OUTCOMES)[number];
type InspectEmptyOutcome = Exclude<InspectOutcome, InspectDataOutcome>;
/** Why a field's value was left out. Exactly these three, each for its own case. */
declare const OMISSION_REASONS: readonly ["secret", "not-allowed", "credential-store"];
type OmissionReason = (typeof OMISSION_REASONS)[number];
/** Codes of the inspector's own refusals and its `unavailable` answers, with M12's class per code. M03's `AUTH_*` codes travel in a `refused` reply unchanged. */
declare const INSPECT_CODE_CLASSES: {
  /** An operation, selector or provider answer that could write, call or invoke. */
  readonly INSPECT_READONLY: "refusal";
  /** A request that is not the closed shape: an unknown key, a bad type or bound, or a claim of authority. */
  readonly INSPECT_INVALID: "refusal";
  readonly INSPECT_FORBIDDEN: "refusal";
  readonly INSPECT_UNAVAILABLE: "unavailable";
  readonly INSPECT_UNKNOWN_PROVIDER: "unavailable";
  readonly INSPECT_PROVIDER_FAILED: "unavailable";
};
type InspectCode = keyof typeof INSPECT_CODE_CLASSES;
/** Argument keys no request may carry, whatever the operation: the caller, its session, root, thread, actor and composition are the bearer's and the Backend's, never the model's. */
declare const INSPECT_FORBIDDEN_ARGUMENT_KEYS: readonly string[];
interface ListRequest {
  providerId?: string;
  host?: InspectHost;
  kind?: string;
  offset?: number;
  limit?: number;
}
interface QueryRequest {
  providerId: string;
  targetId: string;
  selector?: string;
  clientId?: string;
}
interface ListEntry {
  providerId: string;
  targetId: string;
  kind: string;
  host: InspectHost;
  state: InspectState;
  summary: string;
}
interface Omission {
  path: string;
  reason: OmissionReason;
}
/** What was left out of a `truncated` answer, so the reader knows the answer is partial. Whole entries only: no entry is sliced. */
interface Truncation {
  capBytes: number;
  missing: {
    entries: number;
    bytes: number;
  };
}
interface ClientRef {
  clientId: string;
  lastSeen: string;
}
type ListResult = {
  outcome: InspectDataOutcome;
  capturedAt: string;
  entries: ListEntry[];
  offset: number;
  limit: number;
  total: number;
  nextOffset: number | null;
  truncation?: Truncation;
} | {
  outcome: InspectEmptyOutcome;
  capturedAt: string;
};
type QueryResult = {
  outcome: InspectDataOutcome;
  capturedAt: string;
  providerId: string;
  targetId: string;
  state: InspectState;
  selector?: string;
  clientId?: string;
  shape: unknown;
  values: Record<string, unknown>;
  omitted: Omission[];
  truncation?: Truncation;
} | {
  outcome: Exclude<InspectEmptyOutcome, 'ambiguous'>;
  capturedAt: string;
  providerId: string;
  targetId: string;
} | {
  outcome: 'ambiguous';
  capturedAt: string;
  providerId: string;
  targetId: string;
  clients: ClientRef[];
};
type Decoded<T> = {
  ok: true;
  value: T;
} | {
  ok: false;
  code: InspectCode;
  reason: string;
};
//#endregion
//#region src/patterns.d.ts
/** A provider id: lower-case words joined by hyphens, the same spelling as the `inspect.<providerId>` service name that declares it (XC-4). */
declare const PROVIDER_ID_PATTERN: RegExp;
/** A target id: a module id, a tool name, a driver id, an RPC method or a region id. No control character, space or quote. */
declare const TARGET_ID_PATTERN: RegExp;
declare const KIND_PATTERN: RegExp;
/** The page's client id, as the region registry spells it. */
declare const CLIENT_ID_PATTERN: RegExp;
/** A capture or last-seen time in UTC. The core reads no clock: the Backend supplies every time it puts in a result. */
declare const TIME_PATTERN: RegExp;
/** A refusal or unavailable code: the inspector's own, or M03's `AUTH_*`. */
declare const CODE_PATTERN: RegExp;
/** An omitted field's path: a field name or a dotted/indexed path to it. */
declare const OMISSION_PATH_PATTERN: RegExp;
/** A module id, as XC-4 spells it. */
declare const MODULE_ID_PATTERN: RegExp;
/** One `module.field` pair of the `showValues` allow-list. */
declare const SHOW_PAIR_PATTERN: RegExp;
/** A selector is a dotted field path with optional `[n]` indexes: it can name a part of an exact shape and nothing else. */
declare const SELECTOR_PATH_PATTERN: RegExp;
/** Characters that make a selector a call, an assignment or a command rather than a path. */
declare const SELECTOR_WRITE_CHARACTERS: RegExp;
/** A leading verb followed by a space or a tab reads as a command. A bare word is still a legitimate field name. */
declare const SELECTOR_WRITE_VERB: RegExp;
//#endregion
//#region src/errors.d.ts
type InspectErrorCode = 'INSPECT_INVALID' | 'INSPECT_PROVIDER_INVALID' | 'INSPECT_DUPLICATE_PROVIDER' | 'INSPECT_REGISTRY_DISPOSED';
declare class InspectError extends Error {
  code: InspectErrorCode;
  constructor(code: InspectErrorCode, message: string);
}
//#endregion
//#region src/plain.d.ts
declare const PLAIN_MAX_DEPTH = 64;
declare const PLAIN_MAX_NODES = 100000;
type PlainReason = 'function' | 'accessor' | 'symbol' | 'class-instance' | 'cycle' | 'non-finite' | 'undefined' | 'bigint' | 'sparse-array' | 'array-property' | 'too-deep' | 'too-large';
interface PlainProblem {
  ok: false;
  reason: PlainReason;
  /** Where: `$` for the value itself, then field names and `[n]` indexes. Field names only, never a value. */
  path: string;
}
type PlainCheck = {
  ok: true;
} | PlainProblem;
declare function checkPlain(value: unknown): PlainCheck;
/** The UTF-8 length of a string: the unit every cap in the contract counts in. */
declare function utf8Bytes(text: string): number;
/** The UTF-8 length of a value's JSON text. A plain value has one; `undefined` has none and counts 0. */
declare function jsonBytes(value: unknown): number;
/** Own key and value without running a getter; undefined when the key is absent or an accessor. */
declare function ownValue(object: object, key: string): {
  found: true;
  value: unknown;
} | {
  found: false;
};
/** Set an own, enumerable data property even for a key such as `__proto__`, which plain assignment would turn into a prototype change. */
declare function defineOwn(target: Record<string, unknown>, key: string, value: unknown): void;
//#endregion
//#region src/params.d.ts
declare const INSPECT_PARAMETERS: Readonly<{
  provisional: true;
  /** D: the Backend holds one inspect call up to this long, then answers `done` with an outcome. */
  backendDeadlineMs: 10000;
  /** T: the Agent's watchdog on that one call, always longer than D. */
  agentTimeoutMs: 12000;
  /** P: the default and the hard limit of a list page. */
  pageLimit: 100;
  /** Q: the most UTF-8 bytes one result may carry; larger answers are cut whole-entry. */
  resultCapBytes: 1048576;
  /** An allow-list longer than this ignores the rest. */
  showValuesMaxEntries: 256;
  selectorMaxLength: 256;
  summaryMaxLength: 200;
  maxClients: 64;
  maxOffset: 10000000;
}>;
/** The window a list request asks for: its offset and its limit, defaulted and never wider than the page bound. */
declare function listWindow(request: {
  offset?: number;
  limit?: number;
} | undefined): {
  offset: number;
  limit: number;
};
//#endregion
//#region src/codec.d.ts
type Fail = {
  ok: false;
  code: InspectCode;
  reason: string;
};
/** A selector names a part of an exact shape. Anything shaped like a call, an assignment or a command is read-only's business; anything else malformed is just invalid. */
declare function classifySelector(selector: unknown): {
  ok: true;
} | Fail;
/** Which of the two operations a name is: another `inspect.*` name is a verb the contract does not have, and any other name is not the inspector's. */
declare function classifyOperation(name: string): {
  kind: 'inspect';
} | {
  kind: 'readonly-violation';
  code: 'INSPECT_READONLY';
} | {
  kind: 'not-inspect';
};
/** Walk a selector through plain data by own members only: never a prototype member, never `length`, never a missing part. */
declare function applySelector(shape: unknown, selector: string): {
  ok: true;
  value: unknown;
} | {
  ok: false;
};
declare function decodeListRequest(raw: unknown): Decoded<ListRequest>;
declare function decodeQueryRequest(raw: unknown): Decoded<QueryRequest>;
declare function decodeListResult(raw: unknown): Decoded<ListResult>;
declare function decodeQueryResult(raw: unknown): Decoded<QueryResult>;
/**
 * The XC-6 reply to an inspect call. The Backend holds the call until its outcome or its one deadline, so the reply is `done` (carrying a result), `refused` (M03's
 * `AUTH_*` code or the inspector's) or `unavailable`: never `pending`, a carrier `error` or a poll token, none of which an inspect exchange has.
 */
declare function decodeCarrierReply(op: InspectOperation | string, raw: unknown): Decoded<unknown>;
//#endregion
//#region src/projector-types.d.ts
type ConfigFieldType = 'string' | 'number' | 'integer' | 'boolean' | 'string-list';
interface ConfigFieldShape {
  type: ConfigFieldType;
  required: boolean;
  secret: boolean;
}
//#endregion
//#region src/projector.d.ts
interface ProjectedConfig {
  shape: {
    name: string;
    type: string;
    required: boolean;
    secret: boolean;
  }[];
  values: Record<string, unknown>;
  omitted: Omission[];
}
/** The allow-list as a set of `module.field` pairs. Anything that is not a list of well-formed pairs adds nothing, so a malformed setting shows nothing. */
declare function parseShowValues(raw: unknown): ReadonlySet<string>;
/**
 * `(module, values, showValues) → {shape, values, omitted[]}`. `module` is `{id, fields}` with the XC-4 fields exactly (`type`, `required`, `secret`: no default, no JSON
 * Schema); the id is needed because `showValues` lists `module.field` pairs. `values` holds only what a provider explicitly supplied; `options.origins` names where a
 * value came from, and a credential-store origin is never a candidate.
 *
 * Each supplied value is omitted for the first reason that applies: its origin is a credential store (`credential-store`); its field is declared secret, listed or not
 * (`secret`); its field is undeclared or not listed (`not-allowed`). A listed non-secret field is shown only if its value is plain data of the declared type, otherwise it is
 * omitted as `not-allowed`. A value that is missing is simply absent. An invalid declaration throws before any value is read.
 */
declare function projectConfig(module: {
  id: string;
  fields: Readonly<Record<string, ConfigFieldShape>>;
}, values: Readonly<Record<string, unknown>>, showValues: unknown, options?: {
  origins?: Readonly<Record<string, string>>;
}): ProjectedConfig;
/**
 * Fit a query answer to `capBytes` of UTF-8 JSON by omitting whole trailing entries — of the shape first, then of the values — in stable order, never by cutting serialized
 * bytes. The answer stays valid JSON, keeps its state and omissions, and says `truncated` with the cap and the missing portion. A scalar shape that does not fit becomes
 * `null`. If even the envelope does not fit, the answer is `unavailable`. An answer that already fits, or carries no data, is returned as it is.
 */
declare function fitQueryResult(result: QueryResult, capBytes: number): QueryResult;
/**
 * Fit a list page to `capBytes` by omitting whole trailing entries. `nextOffset` then points at the first entry dropped, so the next page resumes there. If not even one
 * entry fits, the page is `unavailable`: a page that could never advance is not offered. A page that fits, or carries no data, is returned as it is.
 */
declare function fitListResult(result: ListResult, capBytes: number): ListResult;
//#endregion
//#region src/registry.d.ts
interface ListPage {
  offset: number;
  limit: number;
  kind?: string;
}
interface QueryTarget {
  targetId: string;
  selector?: string;
  clientId?: string;
}
/** What a host module registers: its id, its host, and the two read methods. Both return plain data, now or later. */
interface InspectProvider {
  providerId: string;
  host: InspectHost;
  list(page: ListPage): unknown;
  query(request: QueryTarget): unknown;
}
type ProviderAnswer = {
  status: 'answer';
  data: unknown;
} | {
  status: 'refused';
  code: 'INSPECT_READONLY';
} | {
  status: 'unavailable';
  code: InspectCode;
};
/** `until` ends a call: when it settles, the call is settled unavailable and removed from the waiting work, and whatever the provider answers later is dropped. The registry reads no clock, so the host supplies the deadline as this promise. */
interface CallOptions {
  until?: Promise<unknown>;
}
interface ProviderHandle {
  providerId: string;
  /** False once the provider was disposed (or the registry was); a handle is never revived by a later registration of the same id. */
  alive(): boolean;
  list(page: ListPage, options?: CallOptions): Promise<ProviderAnswer>;
  query(request: QueryTarget, options?: CallOptions): Promise<ProviderAnswer>;
}
interface ProviderRegistry {
  register(provider: InspectProvider): () => void;
  providers(): string[];
  get(providerId: string): ProviderHandle | undefined;
  /** Calls waiting on a provider right now. */
  inFlight(): number;
  /** Dispose every provider; `stopped` is the number of waiting calls it settled unavailable, for the disposal report (XC-7). */
  dispose(): {
    stopped: number;
  };
}
declare function createProviderRegistry(options: {
  host: InspectHost;
}): ProviderRegistry;
//#endregion
//#region src/provider-answers.d.ts
interface ProviderListEntry {
  targetId: string;
  kind: string;
  state: InspectState;
  summary: string;
}
interface ProviderList {
  /** Every target the provider has for this filter, not only this page. */
  total: number;
  entries: ProviderListEntry[];
}
interface ProviderConfigCandidate {
  module: {
    id: string;
    fields: Record<string, unknown>;
  };
  values: Record<string, unknown>;
  /** Where a value came from, by field; `credential-store` is never shown. */
  origins?: Record<string, string>;
}
type ProviderQuery = {
  outcome: 'ok';
  state: InspectState;
  shape: unknown;
} | {
  outcome: 'ok';
  state: InspectState;
  config: ProviderConfigCandidate;
} | {
  outcome: 'unavailable' | 'schema-unsupported';
};
declare function decodeProviderList(raw: unknown, page: {
  limit: number;
}): Decoded<ProviderList>;
declare function decodeProviderQuery(raw: unknown): Decoded<ProviderQuery>;
//#endregion
//#region src/status.d.ts
interface Translated {
  state: InspectState;
  reason: string | null;
}
/** The raw lifecycle states stay unchanged; this is the inspection's own projection of them. A state it does not know is `unsupported`, never guessed. */
declare function translateLifecycle(lifecycle: unknown): Translated;
interface DeclaredModule {
  id: string;
  host: InspectHost;
  required: boolean;
}
interface HostDigest {
  version: number;
  algorithm: string;
  value: string;
}
type HostObservation = {
  status: 'observed';
  modules: {
    id: string;
    state: string;
  }[];
  digest?: HostDigest;
} | {
  status: 'unreadable';
};
interface ModuleJoin {
  id: string;
  host: InspectHost;
  required: boolean;
  state: InspectState;
  reason: string | null;
  /** Where each fact came from: the module's row is declared metadata; its state and the digest come from its host's status. The digest is the HOST's, never the module's. */
  provenance: {
    declared: 'manifest';
    observed: 'host-status' | null;
    hostDigest: ({
      host: InspectHost;
    } & HostDigest) | null;
  };
}
/** The order every inspection list uses: host (agent, backend, client), then id by code unit. It does not depend on the order the sources arrived in. */
declare function compareByHostThenId(a: {
  host: string;
  id: string;
}, b: {
  host: string;
  id: string;
}): number;
/**
 * Join declared modules to the observed status of their hosts. A module its host's readable status lists takes the translated lifecycle; one that status does not list is
 * `absent`; one whose host status is unreadable, or was not observed at all, is `unsupported` — unknown is never absent. Modules named in `options.disabled` read `inactive`
 * with the reason `disabled` whatever was observed: inspection being off changes only its own module's projection, never the raw lifecycle. The result is in
 * `compareByHostThenId` order. A duplicate declared id on one host is refused.
 */
declare function joinModules(declared: readonly DeclaredModule[], observations: Partial<Record<InspectHost, HostObservation>>, options?: {
  disabled?: readonly string[];
}): ModuleJoin[];
interface Page<T> {
  entries: T[];
  total: number;
  nextOffset: number | null;
}
/** One window over a list that is already in its stable order. `nextOffset` is where the next window starts, or null at the end; a window past the end is empty. */
declare function pageOf<T>(items: readonly T[], offset: number, limit: number): Page<T>;
//#endregion
//#region src/backend/index.d.ts
declare const INSPECT_BACKEND_ENTRY: "backend";
//#endregion
export { CLIENT_ID_PATTERN, CODE_PATTERN, CallOptions, ClientRef, ConfigFieldShape, ConfigFieldType, DeclaredModule, Decoded, HostDigest, HostObservation, INSPECT_BACKEND_ENTRY, INSPECT_CODE_CLASSES, INSPECT_DATA_OUTCOMES, INSPECT_FORBIDDEN_ARGUMENT_KEYS, INSPECT_HOSTS, INSPECT_LIST_OPERATION, INSPECT_OPERATIONS, INSPECT_OUTCOMES, INSPECT_PACKAGE, INSPECT_PARAMETERS, INSPECT_QUERY_OPERATION, INSPECT_STATES, InspectCode, InspectDataOutcome, InspectEmptyOutcome, InspectError, InspectErrorCode, InspectHost, InspectOperation, InspectOutcome, InspectProvider, InspectState, KIND_PATTERN, ListEntry, ListPage, ListRequest, ListResult, MODULE_ID_PATTERN, ModuleJoin, OMISSION_PATH_PATTERN, OMISSION_REASONS, Omission, OmissionReason, PLAIN_MAX_DEPTH, PLAIN_MAX_NODES, PROVIDER_ID_PATTERN, Page, PlainCheck, PlainProblem, PlainReason, ProjectedConfig, ProviderAnswer, ProviderConfigCandidate, ProviderHandle, ProviderList, ProviderListEntry, ProviderQuery, ProviderRegistry, QueryRequest, QueryResult, QueryTarget, SELECTOR_PATH_PATTERN, SELECTOR_WRITE_CHARACTERS, SELECTOR_WRITE_VERB, SHOW_PAIR_PATTERN, TARGET_ID_PATTERN, TIME_PATTERN, Translated, Truncation, applySelector, checkPlain, classifyOperation, classifySelector, compareByHostThenId, createProviderRegistry, decodeCarrierReply, decodeListRequest, decodeListResult, decodeProviderList, decodeProviderQuery, decodeQueryRequest, decodeQueryResult, defineOwn, fitListResult, fitQueryResult, joinModules, jsonBytes, listWindow, ownValue, pageOf, parseShowValues, projectConfig, translateLifecycle, utf8Bytes };