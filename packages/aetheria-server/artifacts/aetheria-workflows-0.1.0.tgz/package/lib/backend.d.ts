//#region src/strict.d.ts
type Decoded<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly reason: string;
};
type Guard = (input: unknown, path: string) => string | null;
//#endregion
//#region src/contracts.d.ts
declare const WORKFLOWS_PACKAGE: "@aetheria/workflows";
declare const WORKFLOW_HELPERS: readonly [{
  readonly name: "agent";
  readonly signature: "agent(prompt, {schema?, model?, role?})";
  readonly returns: "the child's validated structured value, its text when no schema is given, or null (D16)";
}, {
  readonly name: "parallel";
  readonly signature: "parallel(items, fn)";
  readonly returns: "one entry per item; a failed item is null, never a missing entry";
}, {
  readonly name: "pipeline";
  readonly signature: "pipeline(items, ...stages)";
  readonly returns: "each item through its stages without a barrier between stages";
}, {
  readonly name: "phase";
  readonly signature: "phase(name)";
  readonly returns: "nothing; sets the current phase shown in progress";
}, {
  readonly name: "log";
  readonly signature: "log(text)";
  readonly returns: "nothing; one progress line";
}];
/** The helper names in contract order. The tuple type is written out so the emitted declaration is the same on every build (an inferred union's member order is not stable across compiler runs, which once made the packed archive irreproducible). */
type HelperName = "agent" | "parallel" | "pipeline" | "phase" | "log";
declare const HELPER_NAMES: readonly HelperName[];
interface WorkflowMeta {
  readonly name: string;
  readonly description: string;
  readonly whenToUse?: string;
  readonly phases?: readonly string[];
}
declare const decodeWorkflowMeta: (input: unknown) => Decoded<WorkflowMeta>;
interface AgentOptions {
  readonly schema?: unknown;
  readonly model?: string;
  readonly role?: string;
}
declare const decodeAgentOptions: (input: unknown) => Decoded<AgentOptions>;
/** Script `args` and a run's return value: lossless JSON only. */
declare const decodeJsonValue: (input: unknown) => Decoded<unknown>;
type ParameterStatus = "carried, not accepted" | "proposed for gate";
interface Parameter {
  readonly value: number | "cpu-derived";
  readonly unit: string;
  readonly status: ParameterStatus;
  readonly source: string;
  readonly rule?: string;
}
/** DSH's rule for `maxConcurrentAgents: 0` (dsh-workflow-ptc): the ceiling follows available CPU parallelism, with headroom for the host's own calls. */
declare const CPU_RULE = "min(16, max(1, availableParallelism - 2))";
declare const resolveCpuDerived: (availableParallelism: number) => number;
/** `progressRetention = 100` entries is a proposed, test-only value: DSH has none (Plan choice at the gate). */
declare const WORKFLOW_PARAMETERS: Readonly<{
  maxConcurrentAgents: Parameter;
  maxTotalAgents: Parameter;
  maxItemsPerCall: Parameter;
  syncTimeoutMs: Parameter;
  progressRetention: Readonly<Parameter>;
  maxResultChars: Parameter;
}>;
type WorkflowParameterName = keyof typeof WORKFLOW_PARAMETERS;
declare const WORKFLOW_PARAMETER_NAMES: WorkflowParameterName[];
/** The four per-run caps a run may lower and never raise (D15). */
declare const CAP_NAMES: readonly ["maxConcurrentAgents", "maxTotalAgents", "maxItemsPerCall", "syncTimeoutMs"];
type CapName = (typeof CAP_NAMES)[number];
type Caps = Readonly<Record<CapName, number>>;
type WorkflowParameterValues = Readonly<Record<WorkflowParameterName, number>>;
/**
 * Resolve configured values into concrete numbers, or say why the module may not start. Every name must be present; `maxConcurrentAgents` may be the literal `"cpu-derived"`,
 * resolved by DSH's rule from the measured parallelism the caller supplies; every other value is a positive safe integer. Nothing is defaulted.
 */
declare function resolveWorkflowParameters(values: unknown, measured: {
  readonly availableParallelism: number;
}): {
  readonly ok: true;
  readonly values: WorkflowParameterValues;
  readonly resolvedConcurrency: {
    readonly value: number;
    readonly rule: string;
  } | null;
} | {
  readonly ok: false;
  readonly problems: string[];
};
/** A run's own caps: absent names keep the configured value, a lower value narrows it, a higher or invalid one is refused. A refusal changes nothing. */
declare function lowerCaps(configured: Caps, requested: unknown): {
  readonly ok: true;
  readonly caps: Caps;
} | {
  readonly ok: false;
  readonly reason: string;
};
declare const OUTCOME_CAUSES: readonly ["completed", "failed", "interrupted", "cancelled", "schema-invalid", "SPAWN_REFUSED", "CHILD_LIMIT", "route-unavailable", "WORKFLOW_INVALID", "WORKFLOW_CAP", "SCRIPT_ERROR", "INFRA", "parent-cancel", "lost"];
type OutcomeCause = (typeof OUTCOME_CAUSES)[number];
type AgentResult = "value" | "text" | "null" | "rejects" | "waits-then-retries" | "none";
type RunResult = "continues" | "fails" | "cancelled" | "continues-or-fails";
interface OutcomeRow {
  readonly event: string;
  readonly agent: AgentResult;
  readonly run: RunResult;
  readonly cause: OutcomeCause;
}
/** One row per event; a null is never ambiguous because each cause is recorded. No row retries a failed child or sends a repair message (D16). */
declare const OUTCOME_TABLE: readonly OutcomeRow[];
declare const outcomeFor: (event: string) => OutcomeRow | null;
/** The first line of a run's job command, so the job's list row names the run (the Backend finds the job to kill by it). The name is the model's text: control characters are removed so it cannot end the comment line. */
declare const workflowJobLabel: (runId: string, name: string) => string;
/** M05 labels a job with its command's first line, so the comment marker comes with it. */
declare const jobLabelMatches: (label: string, runId: string) => boolean;
/** The label written on a member's child BEFORE its spawn, so a child whose id was lost can be found and closed. */
declare const memberLabel: (runId: string, seq: number) => string;
declare const RUN_STATES: readonly ["running", "completed", "failed", "cancelled", "lost"];
declare const TERMINAL_RUN_STATES: readonly ["completed", "failed", "cancelled", "lost"];
declare const MEMBER_STATES: readonly ["pending", "started", "completed", "failed", "interrupted", "cancelled", "closed"];
type RunState = (typeof RUN_STATES)[number];
type MemberState = (typeof MEMBER_STATES)[number];
declare const capsGuard: Guard;
interface RunRecord {
  readonly runId: string;
  readonly rootSessionId: string;
  readonly ownerSessionId: string;
  readonly name: string;
  readonly state: RunState;
  readonly caps: Caps;
  readonly phase?: string;
  readonly agentsStarted: number;
  readonly startedAt: string;
  readonly endedAt?: string;
  readonly cause?: OutcomeCause;
  /** Set by the Backend when a person's Stop (or any cancel) was asked for: no new member is admitted afterwards, and the Agent's controller reads the refusal as a cancel. Never cleared. */
  readonly cancelRequestedAt?: string;
}
interface MemberRecord {
  readonly runId: string;
  readonly seq: number;
  readonly childId: string | null;
  readonly state: MemberState;
  readonly cause?: string;
}
interface AgentOutcome {
  readonly seq: number;
  readonly outcome: "completed" | "failed" | "interrupted" | "cancelled";
  readonly cause: string;
}
declare const decodeRunRecord: (input: unknown) => Decoded<RunRecord>;
declare const decodeMemberRecord: (input: unknown) => Decoded<MemberRecord>;
declare const agentOutcomeGuard: Guard;
//#endregion
//#region src/operations.d.ts
declare const WORKFLOW_OPERATIONS: readonly ["workflows.run-start", "workflows.member", "workflows.run-end"];
type WorkflowOperation = (typeof WORKFLOW_OPERATIONS)[number];
interface RunStartRequest {
  readonly runId: string;
  readonly rootSessionId: string;
  readonly ownerSessionId: string;
  readonly name: string;
  readonly caps: Readonly<Record<string, number>>;
  readonly startedAt: string;
}
interface MemberRequest {
  readonly runId: string;
  readonly seq: number;
  readonly childId: string | null;
  readonly state: (typeof MEMBER_STATES)[number];
  readonly cause?: string; /** The script's current phase when the member was written (D19: the run record carries it). */
  readonly phase?: string;
}
interface RunEndRequest {
  readonly runId: string;
  readonly state: (typeof TERMINAL_RUN_STATES)[number];
  readonly cause: (typeof OUTCOME_CAUSES)[number];
  readonly agentsStarted: number;
  readonly endedAt: string;
  readonly agentOutcomes: readonly {
    readonly seq: number;
    readonly outcome: string;
    readonly cause: string;
  }[];
  readonly result?: unknown;
  readonly phase?: string;
}
declare const decodeRunStart: (input: unknown) => Decoded<RunStartRequest>;
declare const decodeMember: (input: unknown) => Decoded<MemberRequest>;
declare const decodeRunEnd: (input: unknown) => Decoded<RunEndRequest>;
/** Decode a request by operation name; a name outside the three is a refusal, so no other operation can ride this path. */
declare function decodeWorkflowOperation(operation: string, input: unknown): Decoded<unknown>;
//#endregion
//#region src/backend/ledger.d.ts
declare const LEDGER_FORMAT = "aetheria-workflows-ledger/1";
interface LedgerContext {
  readonly sessionId: string;
  readonly rootSessionId: string;
}
type LedgerResult<V> = {
  readonly ok: true;
  readonly value: V;
} | {
  readonly ok: false;
  readonly code: string;
  readonly detail?: string;
};
interface RunFile {
  readonly format: 1;
  readonly run: RunRecord;
  readonly members: readonly MemberRecord[];
  readonly agentOutcomes: readonly AgentOutcome[];
  readonly result?: unknown;
  readonly hasResult?: true;
}
interface LedgerOptions {
  readonly stateRoot: string;
  /** The Backend's configured caps: a run may carry lower values, never higher ones. Absent: only the strict shape is checked. */
  readonly configuredCaps?: Caps;
  /** The owner capability: called before every write; a throw refuses the write. */
  readonly assertHeld?: () => void;
}
interface WorkflowLedger {
  start(): {
    readonly status: "ok";
  } | {
    readonly status: "failed";
    readonly detail: string;
  };
  runStart(ctx: LedgerContext, request: RunStartRequest): LedgerResult<{
    readonly runId: string;
    readonly duplicate: boolean;
  }>;
  member(ctx: LedgerContext, request: MemberRequest): LedgerResult<{
    readonly runId: string;
    readonly seq: number;
    readonly duplicate: boolean;
  }>;
  runEnd(ctx: LedgerContext, request: RunEndRequest): LedgerResult<{
    readonly runId: string;
    readonly duplicate: boolean;
  }>;
  /** A run's whole record for the Backend's own use (boot reconcile, diagnostics). Not an operation. */
  read(runId: string): LedgerResult<RunFile | null>;
  /** Every run still `running`, for the boot reconcile (Plan step 28). A record that cannot be read is listed as unreadable, never skipped. */
  running(): {
    readonly runs: readonly RunFile[];
    readonly unreadable: readonly string[];
  };
  /** Every run record, readable or not (the runs view and the boot reconcile). An unreadable record is named, never skipped and never read as absent. */
  all(): {
    readonly runs: readonly RunFile[];
    readonly unreadable: readonly string[];
  };
  /**
   * Backend-internal (never an XC-6 operation): a cancel was asked for. From now on no new member is admitted (`RUN_CANCELLING`), which is how an Agent controller that does not know yet learns of it.
   * Idempotent; a terminal run is returned unchanged.
   */
  requestCancel(runId: string, at: string): LedgerResult<{
    readonly file: RunFile;
    readonly duplicate: boolean;
  }>;
  /** Backend-internal: a run still `running` at boot becomes `lost`, once. A terminal run is returned unchanged (a late fact never reverses a terminal state). */
  markLost(runId: string, at: string): LedgerResult<{
    readonly file: RunFile;
    readonly duplicate: boolean;
  }>;
  /**
   * Backend-internal: the Backend closed (or failed to close) a member's child for cleanup. Only a member that is not final moves, and a `close-failed` one may move to `closed`; `childId` may fill
   * a pending member whose child was found by its label.
   */
  settleMember(runId: string, seq: number, to: "closed" | "failed", cause: string, childId?: string): LedgerResult<{
    readonly file: RunFile;
    readonly duplicate: boolean;
  }>;
}
declare function openWorkflowLedger(options: LedgerOptions): WorkflowLedger;
//#endregion
//#region src/backend/runs.d.ts
type PortResult<V> = {
  readonly ok: true;
  readonly value: V;
} | {
  readonly ok: false;
  readonly code: string;
  readonly detail?: string;
};
/**
 * What M05 says about one job's process group. `lost` is M05's own state for a job whose end was not observed; the two flags say whether the GROUP was still proven empty. Only both flags `false` is proof (M05's
 * `confirmed-empty`); `terminationUnconfirmed: true` is a signal sent or a group still non-empty, `livenessIndeterminate: true` is a group that could not be inspected. A flag the adapter did not carry (absent) proves nothing.
 */
interface JobGroupFacts {
  readonly state: string;
  readonly terminationUnconfirmed?: boolean;
  readonly livenessIndeterminate?: boolean;
}
/** M05's jobs and children as this service needs them. The root is a Pi session id; the adapter translates it. Every answer is a fact or a failure: an unreadable list is never an empty one. */
interface RunsPorts {
  listJobs(rootSessionId: string): Promise<PortResult<readonly ({
    readonly jobId: string;
    readonly label: string;
  } & JobGroupFacts)[]>>;
  killJob(rootSessionId: string, jobId: string): Promise<PortResult<JobGroupFacts>>;
  listChildren(rootSessionId: string): Promise<PortResult<readonly {
    readonly childId: string;
    readonly label?: string;
  }[]>>;
  closeChild(rootSessionId: string, childId: string): Promise<PortResult<unknown>>;
}
interface RunView {
  readonly runId: string;
  readonly name: string;
  readonly state: RunRecord["state"];
  readonly phase?: string;
  readonly agentsStarted: number;
  readonly members: Readonly<Record<MemberRecord["state"], number>>;
  readonly startedAt: string;
  readonly endedAt?: string;
  readonly cause?: string;
  readonly cancelRequested?: true;
}
type Unresolved = {
  readonly what: "job" | "child" | "record";
  readonly id: string;
  readonly code: string;
};
type CancelResult = {
  readonly ok: true;
  readonly run: RunView;
  readonly unresolved: readonly Unresolved[];
} | {
  readonly ok: false;
  readonly code: "RUN_UNKNOWN" | "LEDGER_UNAVAILABLE" | string;
  readonly detail?: string;
};
type ListResult = {
  readonly ok: true;
  readonly runs: readonly RunView[];
  readonly unreadable: number;
} | {
  readonly ok: false;
  readonly code: string;
  readonly detail?: string;
};
interface ReconcileReport {
  readonly lost: readonly string[];
  readonly closed: number;
  readonly unresolved: readonly (Unresolved & {
    readonly runId: string;
  })[];
  readonly unreadable: readonly string[];
}
interface WorkflowRunsOptions {
  /** The running ledger, or undefined while the module is not running. */
  readonly ledger: () => WorkflowLedger | undefined;
  readonly ports: RunsPorts;
  readonly now: () => string;
  /** The bound for the whole drain (cancels joined, runs ended), in ms. Default 5000. */
  readonly drainBoundMs?: number;
  /** How often a drain re-reads the ledger while it waits for a run's terminal record, in ms. Default 20. */
  readonly drainPollMs?: number;
  /** Event-loop wait for one drain poll. Supplied by the lifecycle owner, which clears its wait on settle. */
  readonly drainWait: (ms: number) => Promise<void>;
}
interface WorkflowRuns {
  list(rootSessionId: string): ListResult;
  cancel(rootSessionId: string, runId: string): Promise<CancelResult>;
  reconcile(): Promise<ReconcileReport>;
  /**
   * Design D23 — stops accepting calls, joins every cancel in flight, asks a cancel for every run still `running`, and joins each run's terminal record (written by the Agent's controller) until the
   * drain bound. Never writes a terminal fact itself.
   */
  drain(): Promise<DrainReport>;
}
/**
 * What a drain found. `ended`: runs that were `running` at the drain and whose cancel steps all completed (job killed or not running, every open child closed): they own nothing live, whether or not the
 * Agent's terminal record arrived (a missing one leaves the record `running`, and boot reconcile marks it `lost`). `stillLive`: runs with an unresolved cancel step, or a cancel still in flight at the bound.
 */
interface DrainReport {
  readonly joined: number;
  readonly ended: readonly string[];
  readonly stillLive: readonly string[];
}
declare function viewOf(file: RunFile): RunView;
declare function createWorkflowRuns(options: WorkflowRunsOptions): WorkflowRuns;
//#endregion
//#region src/backend/operations.d.ts
interface WorkflowOperationContext {
  readonly sessionId: string;
  readonly rootSessionId: string;
  /** XC-1's kind for the verified caller: only `main` may write a run record. */
  readonly kind: string;
  readonly args: Readonly<Record<string, unknown>>;
}
type WorkflowAuthorization = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason?: string;
};
type WorkflowAnswer = {
  readonly status: "done";
  readonly result: LedgerResult<unknown>;
} | {
  readonly status: "refused";
  readonly code: string;
} | {
  readonly status: "unavailable";
  readonly code: string;
};
interface WorkflowOperationDeps {
  /** The module's ledger, or undefined while the module is not running. */
  readonly ledger: () => WorkflowLedger | undefined;
  /** M03's verdict on starting a workflow (the Backend's `callable: ["workflow"]` port, DV3). Asked for run-start only: later calls are checked against the record's owner. */
  readonly authorize: (ctx: WorkflowOperationContext) => Promise<WorkflowAuthorization>;
}
declare function createWorkflowOperations(deps: WorkflowOperationDeps): Readonly<Record<WorkflowOperation, (ctx: WorkflowOperationContext) => Promise<WorkflowAnswer>>>;
//#endregion
export { AgentOptions, AgentOutcome, AgentResult, CAP_NAMES, CPU_RULE, type CancelResult, CapName, Caps, type DrainReport, HELPER_NAMES, HelperName, LEDGER_FORMAT, type LedgerContext, type LedgerOptions, type LedgerResult, type ListResult, MEMBER_STATES, MemberRecord, MemberRequest, MemberState, OUTCOME_CAUSES, OUTCOME_TABLE, OutcomeCause, OutcomeRow, Parameter, ParameterStatus, RUN_STATES, type ReconcileReport, RunEndRequest, type RunFile, RunRecord, RunResult, RunStartRequest, RunState, type RunView, type PortResult as RunsPortResult, type RunsPorts, TERMINAL_RUN_STATES, type Unresolved, WORKFLOWS_PACKAGE, WORKFLOW_HELPERS, WORKFLOW_OPERATIONS, WORKFLOW_PARAMETERS, WORKFLOW_PARAMETER_NAMES, type WorkflowAnswer, type WorkflowAuthorization, type WorkflowLedger, WorkflowMeta, WorkflowOperation, type WorkflowOperationContext, type WorkflowOperationDeps, WorkflowParameterName, WorkflowParameterValues, type WorkflowRuns, type WorkflowRunsOptions, agentOutcomeGuard, capsGuard, createWorkflowOperations, createWorkflowRuns, decodeAgentOptions, decodeJsonValue, decodeMember, decodeMemberRecord, decodeRunEnd, decodeRunRecord, decodeRunStart, decodeWorkflowMeta, decodeWorkflowOperation, jobLabelMatches, lowerCaps, memberLabel, openWorkflowLedger, outcomeFor, resolveCpuDerived, resolveWorkflowParameters, viewOf, workflowJobLabel };