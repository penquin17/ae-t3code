//#region src/strict.d.ts
type Decoded<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly reason: string;
};
type Guard = (input: unknown, path: string) => string | null;
//#endregion
//#region src/contracts.d.ts
declare const WORKFLOWS_PACKAGE: "@aetheria/workflows";
declare const WORKFLOW_HELPERS: readonly [{
  readonly name: "agent";
  readonly signature: "agent(prompt, {schema?, model?, role?})";
  readonly returns: "the child's validated structured value, its text when no schema is given, or null (D16)";
}, {
  readonly name: "parallel";
  readonly signature: "parallel(items, fn)";
  readonly returns: "one entry per item; a failed item is null, never a missing entry";
}, {
  readonly name: "pipeline";
  readonly signature: "pipeline(items, ...stages)";
  readonly returns: "each item through its stages without a barrier between stages";
}, {
  readonly name: "phase";
  readonly signature: "phase(name)";
  readonly returns: "nothing; sets the current phase shown in progress";
}, {
  readonly name: "log";
  readonly signature: "log(text)";
  readonly returns: "nothing; one progress line";
}];
declare const HELPER_NAMES: readonly ("agent" | "parallel" | "pipeline" | "phase" | "log")[];
interface WorkflowMeta {
  readonly name: string;
  readonly description: string;
  readonly whenToUse?: string;
  readonly phases?: readonly string[];
}
declare const decodeWorkflowMeta: (input: unknown) => Decoded<WorkflowMeta>;
interface AgentOptions {
  readonly schema?: unknown;
  readonly model?: string;
  readonly role?: string;
}
declare const decodeAgentOptions: (input: unknown) => Decoded<AgentOptions>;
/** Script `args` and a run's return value: lossless JSON only. */
declare const decodeJsonValue: (input: unknown) => Decoded<unknown>;
type ParameterStatus = "carried, not accepted" | "proposed for gate";
interface Parameter {
  readonly value: number | "cpu-derived";
  readonly unit: string;
  readonly status: ParameterStatus;
  readonly source: string;
  readonly rule?: string;
}
/** DSH's rule for `maxConcurrentAgents: 0` (dsh-workflow-ptc): the ceiling follows available CPU parallelism, with headroom for the host's own calls. */
declare const CPU_RULE = "min(16, max(1, availableParallelism - 2))";
declare const resolveCpuDerived: (availableParallelism: number) => number;
/** `progressRetention = 100` entries is a proposed, test-only value: DSH has none (Plan choice at the gate). */
declare const WORKFLOW_PARAMETERS: Readonly<{
  maxConcurrentAgents: Parameter;
  maxTotalAgents: Parameter;
  maxItemsPerCall: Parameter;
  syncTimeoutMs: Parameter;
  progressRetention: Readonly<Parameter>;
  maxResultChars: Parameter;
}>;
type WorkflowParameterName = keyof typeof WORKFLOW_PARAMETERS;
declare const WORKFLOW_PARAMETER_NAMES: WorkflowParameterName[];
/** The four per-run caps a run may lower and never raise (D15). */
declare const CAP_NAMES: readonly ["maxConcurrentAgents", "maxTotalAgents", "maxItemsPerCall", "syncTimeoutMs"];
type CapName = (typeof CAP_NAMES)[number];
type Caps = Readonly<Record<CapName, number>>;
type WorkflowParameterValues = Readonly<Record<WorkflowParameterName, number>>;
/**
 * Resolve configured values into concrete numbers, or say why the module may not start. Every name must be present; `maxConcurrentAgents` may be the literal `"cpu-derived"`,
 * resolved by DSH's rule from the measured parallelism the caller supplies; every other value is a positive safe integer. Nothing is defaulted.
 */
declare function resolveWorkflowParameters(values: unknown, measured: {
  readonly availableParallelism: number;
}): {
  readonly ok: true;
  readonly values: WorkflowParameterValues;
  readonly resolvedConcurrency: {
    readonly value: number;
    readonly rule: string;
  } | null;
} | {
  readonly ok: false;
  readonly problems: string[];
};
/** A run's own caps: absent names keep the configured value, a lower value narrows it, a higher or invalid one is refused. A refusal changes nothing. */
declare function lowerCaps(configured: Caps, requested: unknown): {
  readonly ok: true;
  readonly caps: Caps;
} | {
  readonly ok: false;
  readonly reason: string;
};
declare const OUTCOME_CAUSES: readonly ["completed", "failed", "interrupted", "cancelled", "schema-invalid", "SPAWN_REFUSED", "CHILD_LIMIT", "route-unavailable", "WORKFLOW_INVALID", "WORKFLOW_CAP", "SCRIPT_ERROR", "INFRA", "parent-cancel"];
type OutcomeCause = (typeof OUTCOME_CAUSES)[number];
type AgentResult = "value" | "text" | "null" | "rejects" | "waits-then-retries" | "none";
type RunResult = "continues" | "fails" | "cancelled" | "continues-or-fails";
interface OutcomeRow {
  readonly event: string;
  readonly agent: AgentResult;
  readonly run: RunResult;
  readonly cause: OutcomeCause;
}
/** One row per event; a null is never ambiguous because each cause is recorded. No row retries a failed child or sends a repair message (D16). */
declare const OUTCOME_TABLE: readonly OutcomeRow[];
declare const outcomeFor: (event: string) => OutcomeRow | null;
declare const RUN_STATES: readonly ["running", "completed", "failed", "cancelled", "lost"];
declare const TERMINAL_RUN_STATES: readonly ["completed", "failed", "cancelled", "lost"];
declare const MEMBER_STATES: readonly ["pending", "started", "completed", "failed", "interrupted", "cancelled", "closed"];
type RunState = (typeof RUN_STATES)[number];
type MemberState = (typeof MEMBER_STATES)[number];
declare const capsGuard: Guard;
interface RunRecord {
  readonly runId: string;
  readonly rootSessionId: string;
  readonly ownerSessionId: string;
  readonly name: string;
  readonly state: RunState;
  readonly caps: Caps;
  readonly phase?: string;
  readonly agentsStarted: number;
  readonly startedAt: string;
  readonly endedAt?: string;
  readonly cause?: OutcomeCause;
}
interface MemberRecord {
  readonly runId: string;
  readonly seq: number;
  readonly childId: string | null;
  readonly state: MemberState;
  readonly cause?: string;
}
interface AgentOutcome {
  readonly seq: number;
  readonly outcome: "completed" | "failed" | "interrupted" | "cancelled";
  readonly cause: string;
}
declare const decodeRunRecord: (input: unknown) => Decoded<RunRecord>;
declare const decodeMemberRecord: (input: unknown) => Decoded<MemberRecord>;
declare const agentOutcomeGuard: Guard;
//#endregion
//#region src/operations.d.ts
declare const WORKFLOW_OPERATIONS: readonly ["workflows.run-start", "workflows.member", "workflows.run-end"];
type WorkflowOperation = (typeof WORKFLOW_OPERATIONS)[number];
interface RunStartRequest {
  readonly runId: string;
  readonly rootSessionId: string;
  readonly ownerSessionId: string;
  readonly name: string;
  readonly caps: Readonly<Record<string, number>>;
  readonly startedAt: string;
}
interface MemberRequest {
  readonly runId: string;
  readonly seq: number;
  readonly childId: string | null;
  readonly state: (typeof MEMBER_STATES)[number];
  readonly cause?: string; /** The script's current phase when the member was written (D19: the run record carries it). */
  readonly phase?: string;
}
interface RunEndRequest {
  readonly runId: string;
  readonly state: (typeof TERMINAL_RUN_STATES)[number];
  readonly cause: (typeof OUTCOME_CAUSES)[number];
  readonly agentsStarted: number;
  readonly endedAt: string;
  readonly agentOutcomes: readonly {
    readonly seq: number;
    readonly outcome: string;
    readonly cause: string;
  }[];
  readonly result?: unknown;
  readonly phase?: string;
}
declare const decodeRunStart: (input: unknown) => Decoded<RunStartRequest>;
declare const decodeMember: (input: unknown) => Decoded<MemberRequest>;
declare const decodeRunEnd: (input: unknown) => Decoded<RunEndRequest>;
/** Decode a request by operation name; a name outside the three is a refusal, so no other operation can ride this path. */
declare function decodeWorkflowOperation(operation: string, input: unknown): Decoded<unknown>;
//#endregion
//#region src/backend/ledger.d.ts
declare const LEDGER_FORMAT = "aetheria-workflows-ledger/1";
interface LedgerContext {
  readonly sessionId: string;
  readonly rootSessionId: string;
}
type LedgerResult<V> = {
  readonly ok: true;
  readonly value: V;
} | {
  readonly ok: false;
  readonly code: string;
  readonly detail?: string;
};
interface RunFile {
  readonly format: 1;
  readonly run: RunRecord;
  readonly members: readonly MemberRecord[];
  readonly agentOutcomes: readonly AgentOutcome[];
  readonly result?: unknown;
  readonly hasResult?: true;
}
interface LedgerOptions {
  readonly stateRoot: string;
  /** The Backend's configured caps: a run may carry lower values, never higher ones. Absent: only the strict shape is checked. */
  readonly configuredCaps?: Caps;
  /** The owner capability: called before every write; a throw refuses the write. */
  readonly assertHeld?: () => void;
}
interface WorkflowLedger {
  start(): {
    readonly status: "ok";
  } | {
    readonly status: "failed";
    readonly detail: string;
  };
  runStart(ctx: LedgerContext, request: RunStartRequest): LedgerResult<{
    readonly runId: string;
    readonly duplicate: boolean;
  }>;
  member(ctx: LedgerContext, request: MemberRequest): LedgerResult<{
    readonly runId: string;
    readonly seq: number;
    readonly duplicate: boolean;
  }>;
  runEnd(ctx: LedgerContext, request: RunEndRequest): LedgerResult<{
    readonly runId: string;
    readonly duplicate: boolean;
  }>;
  /** A run's whole record for the Backend's own use (boot reconcile, diagnostics). Not an operation. */
  read(runId: string): LedgerResult<RunFile | null>;
  /** Every run still `running`, for the boot reconcile (Plan step 28). A record that cannot be read is listed as unreadable, never skipped. */
  running(): {
    readonly runs: readonly RunFile[];
    readonly unreadable: readonly string[];
  };
}
declare function openWorkflowLedger(options: LedgerOptions): WorkflowLedger;
//#endregion
//#region src/backend/operations.d.ts
interface WorkflowOperationContext {
  readonly sessionId: string;
  readonly rootSessionId: string;
  /** XC-1's kind for the verified caller: only `main` may write a run record. */
  readonly kind: string;
  readonly args: Readonly<Record<string, unknown>>;
}
type WorkflowAuthorization = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason?: string;
};
type WorkflowAnswer = {
  readonly status: "done";
  readonly result: LedgerResult<unknown>;
} | {
  readonly status: "refused";
  readonly code: string;
} | {
  readonly status: "unavailable";
  readonly code: string;
};
interface WorkflowOperationDeps {
  /** The module's ledger, or undefined while the module is not running. */
  readonly ledger: () => WorkflowLedger | undefined;
  /** M03's verdict on starting a workflow (the Backend's `callable: ["workflow"]` port, DV3). Asked for run-start only: later calls are checked against the record's owner. */
  readonly authorize: (ctx: WorkflowOperationContext) => Promise<WorkflowAuthorization>;
}
declare function createWorkflowOperations(deps: WorkflowOperationDeps): Readonly<Record<WorkflowOperation, (ctx: WorkflowOperationContext) => Promise<WorkflowAnswer>>>;
//#endregion
export { AgentOptions, AgentOutcome, AgentResult, CAP_NAMES, CPU_RULE, CapName, Caps, HELPER_NAMES, LEDGER_FORMAT, type LedgerContext, type LedgerOptions, type LedgerResult, MEMBER_STATES, MemberRecord, MemberRequest, MemberState, OUTCOME_CAUSES, OUTCOME_TABLE, OutcomeCause, OutcomeRow, Parameter, ParameterStatus, RUN_STATES, RunEndRequest, type RunFile, RunRecord, RunResult, RunStartRequest, RunState, TERMINAL_RUN_STATES, WORKFLOWS_PACKAGE, WORKFLOW_HELPERS, WORKFLOW_OPERATIONS, WORKFLOW_PARAMETERS, WORKFLOW_PARAMETER_NAMES, type WorkflowAnswer, type WorkflowAuthorization, type WorkflowLedger, WorkflowMeta, WorkflowOperation, type WorkflowOperationContext, type WorkflowOperationDeps, WorkflowParameterName, WorkflowParameterValues, agentOutcomeGuard, capsGuard, createWorkflowOperations, decodeAgentOptions, decodeJsonValue, decodeMember, decodeMemberRecord, decodeRunEnd, decodeRunRecord, decodeRunStart, decodeWorkflowMeta, decodeWorkflowOperation, lowerCaps, openWorkflowLedger, outcomeFor, resolveCpuDerived, resolveWorkflowParameters };