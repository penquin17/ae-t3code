//#region src/contracts/vocabulary.d.ts
declare const PURPOSES: readonly ["launch", "switch", "display"];
type Purpose = (typeof PURPOSES)[number];
declare const STATES: readonly ["available", "out", "unknown"];
type State = (typeof STATES)[number];
/** Reason classes by state. `extra-usage-refused` is R1's addition; `api-key-not-eligible` is the gate's subscription-only rule. */
declare const OUT_REASONS: readonly ["limit-remembered", "sign-in-remembered", "extra-usage-refused", "no-sign-in", "api-key-not-eligible", "usage-window-full"];
declare const AVAILABLE_REASONS: readonly ["signed-in-window-ok", "signed-in-no-quota-reader"];
declare const UNKNOWN_REASONS: readonly ["no-signal", "read-late", "read-failed", "service-unavailable", "restarted"];
type OutReason = (typeof OUT_REASONS)[number];
type AvailableReason = (typeof AVAILABLE_REASONS)[number];
type UnknownReason = (typeof UNKNOWN_REASONS)[number];
type ReasonClass = OutReason | AvailableReason | UnknownReason;
declare const REASON_CLASSES: readonly ReasonClass[];
declare const REASON_STATE: Readonly<Record<ReasonClass, State>>;
declare const BASIS_SIGNALS: readonly ["memory", "credential", "window"];
type BasisSignal = (typeof BASIS_SIGNALS)[number];
declare const FAILURE_CLASSES: readonly ["limit", "sign-in", "struggling", "other"];
type FailureClass = (typeof FAILURE_CLASSES)[number];
/** R1: set only on a `limit` the classifier recognised as Anthropic's extra-usage refusal; the class stays `limit`. */
declare const FAILURE_REASONS: readonly ["extra-usage-refused"];
type FailureReason = (typeof FAILURE_REASONS)[number];
declare const USAGE_FAILURES: readonly ["no-credential", "auth", "timeout", "network", "malformed", "redirect", "unsupported", "reader-threw", "late"];
type UsageFailure = (typeof USAGE_FAILURES)[number];
declare const ROUTE_STATES_OPERATION = "providers.route-states";
declare const REPORT_FAILURE_OPERATION = "providers.report-failure";
declare const ROUTE_CAPABILITIES_OPERATION = "providers.route-capabilities";
declare const USAGE_OPERATION = "providers.usage";
interface Route {
  readonly provider: string;
  readonly model: string;
}
/** A failure as received, possibly redacted by the caller; any field may be absent. */
interface FailureInput {
  readonly code?: string;
  readonly status?: number;
  readonly message?: string;
}
interface BasisEntry {
  readonly signal: BasisSignal;
  readonly result: string;
  readonly at: string;
  readonly windowId?: string;
}
/** FX-AV's mark (D15), set on every answer the fixture gives and never by the production service. */
interface Labelled {
  readonly label?: "fixture";
}
interface RouteState extends Labelled {
  readonly state: State;
  readonly reasonClass: ReasonClass;
  readonly observedAt: string;
  readonly basis: readonly BasisEntry[];
  readonly resetsAt?: string;
  readonly memoryEmptySince?: string;
}
type FailureReport = Labelled & ({
  readonly class: "limit";
  readonly remembered: true;
  readonly rememberedUntil: string;
  readonly resetsAt?: string;
  readonly waitHintMinutes?: number;
  readonly reason?: FailureReason;
} | {
  readonly class: "sign-in";
  readonly remembered: true;
  readonly rememberedUntil: string;
  readonly resetsAt?: string;
} | {
  readonly class: "struggling" | "other";
  readonly remembered: false;
});
interface RouteCapabilities extends Labelled {
  readonly route: Route;
  readonly observedAt: string;
  readonly images: "yes" | "no" | "unknown";
  readonly efforts: {
    readonly state: "known";
    readonly supported: readonly string[];
    readonly default: string | null;
  } | {
    readonly state: "unknown";
  };
  readonly source: "catalog" | "none";
}
interface UsageWindow {
  readonly id: string;
  /** A real percentage, or "unknown" when the provider gave none: never 0 for a missing value. */
  readonly usedPercent: number | "unknown";
  readonly resetsAt?: string;
}
type UsageReading = Labelled & ({
  readonly provider: string;
  readonly status: "ok";
  readonly observedAt: string;
  readonly fetchedAt: string;
  readonly stale: false;
  readonly lastGoodAt: string;
  readonly windows: readonly UsageWindow[];
} | {
  readonly provider: string;
  readonly status: "stale";
  readonly observedAt: string;
  readonly fetchedAt: string;
  readonly stale: true;
  readonly lastGoodAt: string;
  readonly ageSeconds: number;
  readonly failure: UsageFailure;
  readonly windows: readonly UsageWindow[];
} | {
  readonly provider: string;
  readonly status: "unavailable";
  readonly observedAt: string;
  readonly fetchedAt: string;
  readonly stale: false;
  readonly lastGoodAt: null;
  readonly failure: UsageFailure;
  readonly windows: readonly [];
});
interface RouteStatesArgs {
  readonly routes: readonly Route[];
  readonly purpose: Purpose;
}
interface RouteStatesResult {
  readonly states: readonly RouteState[];
}
interface ReportFailureArgs {
  readonly route: Route;
  readonly failure: FailureInput;
}
interface RouteCapabilitiesArgs {
  readonly route: Route;
}
interface UsageArgs {
  readonly provider?: string;
}
interface UsageResult {
  readonly readings: readonly UsageReading[];
}
//#endregion
//#region src/contracts/strict.d.ts
type Decoded<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly reason: string;
};
type Guard = (input: unknown, path: string) => string | null;
declare const str: (min?: number, max?: number) => Guard;
declare const int: (min?: number) => Guard;
/** A finite number at or above `min`: NaN, Infinity and negative values are refused, so a missing reading can never be passed off as 0. */
declare const finite: (min?: number) => Guard;
declare const lit: (...values: readonly (string | number | boolean | null)[]) => Guard;
declare const iso: Guard;
declare const arr: (item: Guard, maxLength?: number) => Guard;
declare const obj: (required: Readonly<Record<string, Guard>>, optional?: Readonly<Record<string, Guard>>) => Guard;
/** The first guard that fits wins; when none does, the first guard's problem is reported (the variants are told apart by a literal). */
declare const oneOf: (...guards: readonly Guard[]) => Guard;
declare function decoder<T>(guard: Guard): (input: unknown) => Decoded<T>;
//#endregion
//#region src/contracts/codec.d.ts
declare const decodeRouteStatesArgs: (input: unknown) => Decoded<RouteStatesArgs>;
declare const decodeRouteStatesResult: (input: unknown) => Decoded<RouteStatesResult>;
declare const decodeReportFailureArgs: (input: unknown) => Decoded<ReportFailureArgs>;
declare const decodeFailureReport: (input: unknown) => Decoded<FailureReport>;
declare const decodeRouteCapabilitiesArgs: (input: unknown) => Decoded<RouteCapabilitiesArgs>;
declare const decodeRouteCapabilities: (input: unknown) => Decoded<RouteCapabilities>;
declare const decodeUsageArgs: (input: unknown) => Decoded<UsageArgs>;
declare const decodeUsageResult: (input: unknown) => Decoded<UsageResult>;
//#endregion
//#region src/contracts/outcome.d.ts
declare const OUTCOME_KINDS: readonly ["ok", "refused", "failed", "aborted", "unavailable"];
type OutcomeKind = (typeof OUTCOME_KINDS)[number];
type Outcome<T> = {
  readonly kind: "ok";
  readonly value: T;
} | {
  readonly kind: "refused";
  readonly code: string;
} | {
  readonly kind: "failed";
  readonly class: string;
} | {
  readonly kind: "aborted";
} | {
  readonly kind: "unavailable";
  readonly reason: string;
};
declare const ok: <T>(value: T) => Outcome<T>;
declare const refused: (code: string) => Outcome<never>;
declare const failed: (failureClass: string) => Outcome<never>;
declare const aborted: () => Outcome<never>;
declare const unavailable: (reason: string) => Outcome<never>;
//#endregion
//#region src/contracts/ports.d.ts
interface Clock {
  now(): number;
}
type CredentialKind = "oauth" | "api-key" | "other";
/** What the store says about a provider's record, never its value. `kind` is absent when `configured` is false. */
interface CredentialMeta {
  readonly configured: boolean;
  readonly kind?: CredentialKind;
}
type AuthPurpose = "usage" | "search";
/** The token exists only for the duration of the callback and is never returned, logged or stored by the port. */
interface AuthGrant {
  readonly token: string;
  readonly accountId?: string;
}
interface CredentialMetaPort {
  credentialMeta(provider: string, signal?: AbortSignal): Promise<CredentialMeta>;
}
interface ProviderAuthPort extends CredentialMetaPort {
  withAuth<T>(provider: string, purpose: AuthPurpose, use: (grant: AuthGrant) => Promise<T>, signal?: AbortSignal): Promise<T>;
}
type UsageRead = {
  readonly kind: "ok";
  readonly windows: readonly UsageWindow[];
} | {
  readonly kind: "unavailable";
  readonly failure: UsageFailure;
};
/** A provider without a quota reader answers `hasReader` false; the service then reports `signed-in-no-quota-reader`. */
interface UsagePort {
  /** The providers `usage()` reports on when asked for all of them. */
  readonly providers: readonly string[];
  hasReader(provider: string): boolean;
  read(provider: string, signal: AbortSignal): Promise<UsageRead>;
}
interface CatalogEntry {
  readonly inputModalities?: readonly string[];
  readonly efforts?: {
    readonly supported: readonly string[];
    readonly default: string | null;
  };
}
interface CatalogPort {
  lookup(route: Route): CatalogEntry | undefined;
}
type EffectiveRouteSource = "explicit" | "role-route" | "aetheria-default" | "driver-default";
/** C3's answer (implemented in step 10): the route a request uses and where each choice came from. */
interface EffectiveRoute {
  readonly provider: string;
  readonly model: string;
  readonly effort: string | null;
  readonly source: EffectiveRouteSource;
}
//#endregion
//#region src/availability/redact.d.ts
/** Replace bearer tokens, JWTs, `sk-` keys and any run of 32 or more base64, base64url or hex characters with `[redacted]`. */
declare function redact(message: unknown): string;
/** The text of a failure as written to a log: redacted first, then flattened to one line, then cut to the parameter's length. */
declare function logExcerpt(message: unknown): string;
//#endregion
//#region src/availability/classify.d.ts
/** DSH's quota wording test (the `isQuotaExceededError` of @deepseek-ai/dsh-llm): terminal quota, balance, credit, budget or usage-limit text. */
declare function isQuotaWording(detail: string): boolean;
/** R1: Anthropic's refusal of a plan sign-in when no extra-usage credit is available. */
declare function isExtraUsageRefusal(message: string): boolean;
/** The "~N min" a ChatGPT limit message carries, as a whole number, else undefined. */
declare function minutesToReset(message: string): number | undefined;
/** Whether a usage window's limit applies to a request on `model` (DSH's `windowApplies`). */
declare function windowApplies(id: string, model: string): boolean;
interface ClassifyOptions {
  readonly now: number;
  /** The latest future reset of a full applicable window, when the caller read one: used when the message gives no time. */
  readonly meterResetMs?: number | undefined;
  readonly limitMemoryMs?: number;
  readonly signInMemoryMs?: number;
}
declare function classifyFailure(failure: unknown, options: ClassifyOptions): FailureReport;
//#endregion
//#region src/availability/rules.d.ts
interface MemoryView {
  readonly class: "limit" | "sign-in";
  readonly until: number;
  readonly reason?: FailureReason;
}
type CredentialView = {
  readonly state: "present";
  readonly kind: CredentialKind;
} | {
  readonly state: "absent";
} | {
  readonly state: "late";
} | {
  readonly state: "failed";
} | {
  readonly state: "unavailable";
};
type WindowView = {
  readonly state: "skipped";
} | {
  readonly state: "no-reader";
} | {
  readonly state: "read";
  readonly outcome: "ok" | "late" | "failed";
  readonly fresh: boolean;
  readonly windows: readonly UsageWindow[];
};
interface RuleInput {
  readonly now: number;
  readonly purpose: Purpose;
  readonly route: Route;
  readonly memory?: MemoryView | undefined;
  /** Set when no failure was ever remembered for this provider in this process. */
  readonly memoryEmptySince?: number | undefined;
  readonly credential: CredentialView;
  readonly window: WindowView;
}
declare function decideRoute(input: RuleInput): RouteState;
//#endregion
//#region src/availability/service.d.ts
type ServiceParameterName = "routeDeadlineMs" | "usageCacheOkMs" | "usageCacheDegradedMs" | "usageReadTimeoutMs" | "limitMemoryMs" | "signInMemoryMs";
interface RouteAvailabilityOptions {
  readonly clock: Clock;
  /** Absent means every credential answer is `service-unavailable`: nothing is assumed signed in. */
  readonly credentials?: CredentialMetaPort | undefined;
  /** Absent means no meter reading exists; a provider the port says has no reader is `signed-in-no-quota-reader`. */
  readonly usage?: UsagePort | undefined;
  /** Absent means capabilities claim nothing. */
  readonly catalog?: CatalogPort | undefined;
  /** Overrides of the carried parameters (tests, and the Backend once the user accepts values). Defaults come from the parameter record. */
  readonly parameters?: Partial<Record<ServiceParameterName, number>> | undefined;
}
interface RouteAvailability {
  routeStates(routes: readonly Route[], purpose: Purpose): Promise<RouteState[]>;
  reportFailure(route: Route, failure: FailureInput): Promise<FailureReport>;
  routeCapabilities(route: Route): RouteCapabilities;
  usage(provider?: string): Promise<UsageReading[]>;
  /** Abort reads in flight, start none afterwards, and wait for the pending loads to settle. */
  dispose(): Promise<void>;
}
declare function createRouteAvailability(options: RouteAvailabilityOptions): RouteAvailability;
//#endregion
//#region src/client/index.d.ts
/** The Agent side's XC-6 call. It resolves with the carrier's reply object as received; it rejects only for a transport that did not answer. */
interface Xc11Carrier {
  call(operation: string, args: Readonly<Record<string, unknown>>, signal?: AbortSignal): Promise<unknown>;
}
interface RouteAvailabilityClientOptions {
  readonly carrier: Xc11Carrier;
  readonly clock: Clock;
}
interface RouteAvailabilityClient {
  routeStates(routes: readonly Route[], purpose: Purpose, signal?: AbortSignal): Promise<Outcome<readonly RouteState[]>>;
  reportFailure(route: Route, failure: FailureInput, signal?: AbortSignal): Promise<Outcome<FailureReport>>;
  routeCapabilities(route: Route, signal?: AbortSignal): Promise<Outcome<RouteCapabilities>>;
  usage(provider?: string, signal?: AbortSignal): Promise<Outcome<readonly UsageReading[]>>;
}
declare const BAD_ARGUMENTS = "bad-arguments";
declare const OPERATION_ERROR = "operation-error";
declare const REPLY_CONTRACT = "reply-contract";
declare const CARRIER_FAILED = "carrier-failed";
declare function createRouteAvailabilityClient(options: RouteAvailabilityClientOptions): RouteAvailabilityClient;
//#endregion
//#region src/parameters.d.ts
type ParameterStatus = "carried, not accepted" | "proposed for gate";
interface Parameter<V extends number | string> {
  readonly value: V;
  readonly unit: string;
  readonly status: ParameterStatus;
  readonly source: string;
}
declare const PARAMETERS: Readonly<{
  routeDeadlineMs: Parameter<2000>;
  usageCacheOkMs: Parameter<300000>;
  usageCacheDegradedMs: Parameter<30000>;
  usageReadTimeoutMs: Parameter<10000>;
  limitMemoryMs: Parameter<3600000>;
  signInMemoryMs: Parameter<600000>;
  logExcerptChars: Parameter<300>;
  fetchUrlMaxChars: Parameter<2048>;
  fetchBodyMaxBytes: Parameter<5000000>;
  fetchRedirectsMax: Parameter<5>;
  searchModel: Parameter<"gpt-6-luna">;
  searchEffort: Parameter<"low">;
  searchContextSize: Parameter<"low">;
  searchMaxResults: Parameter<8>;
  searchDeadlineMs: Parameter<60000>;
  shellTimeoutMs: Parameter<60000>;
  shellTermGraceMs: Parameter<1000>;
  emptyGroupBoundMs: Parameter<5000>;
  inlineTailBytesPerStream: Parameter<51200>;
  fetchDisplayChars: Parameter<50000>;
  pollIntervalMs: Parameter<100>;
  toolWaitMs: Parameter<65000>;
  imageEncodedBytes: Parameter<number>;
  sourceImageMaxBytes: Parameter<number>;
  outputRetentionDays: Parameter<7>;
  searchRecordRetentionDays: Parameter<30>;
  snapshotRetention: Parameter<"until-owning-session-deletion">;
}>;
type ParameterName = keyof typeof PARAMETERS;
declare function parameter<N extends ParameterName>(name: N): (typeof PARAMETERS)[N]["value"];
//#endregion
//#region src/pin.d.ts
declare const PI_PIN: Readonly<{
  codingAgent: "1.5.0";
  piAi: "1.5.0";
  piAiPath: "node_modules/@earendil-works/pi-coding-agent/node_modules/@earendil-works/pi-ai";
}>;
//#endregion
//#region src/backend/operations.d.ts
declare const PROVIDERS_ARGUMENTS_REFUSED = "PROVIDERS_ARGUMENTS_REFUSED";
declare const PROVIDERS_RESULT_INVALID = "PROVIDERS_RESULT_INVALID";
type ProvidersOperationErrorCode = typeof PROVIDERS_ARGUMENTS_REFUSED | typeof PROVIDERS_RESULT_INVALID;
/**
 * The typed refusal or failure a handler throws. The message names the operation and the first problem's path and rule, never a value:
 * a refused argument may have been a secret.
 */
declare class ProvidersOperationError extends Error {
  readonly code: ProvidersOperationErrorCode;
  readonly operation: string;
  constructor(code: ProvidersOperationErrorCode, operation: string, detail: string);
}
type ProvidersOperationHandler = (args: unknown) => Promise<unknown>;
declare function createProvidersOperations(service: RouteAvailability): Readonly<Record<string, ProvidersOperationHandler>>;
//#endregion
//#region src/backend/production.d.ts
interface ProductionAvailabilityOptions {
  readonly clock: Clock;
}
declare function createProductionAvailability(options: ProductionAvailabilityOptions): RouteAvailability;
//#endregion
//#region src/backend/fxav.d.ts
declare const FX_AV_REFUSED_IN_PRODUCTION = "FX_AV_REFUSED_IN_PRODUCTION";
declare const FX_AV_SCRIPT_INVALID = "FX_AV_SCRIPT_INVALID";
declare class FixtureRefusedError extends Error {
  readonly code = "FX_AV_REFUSED_IN_PRODUCTION";
  constructor(detail: string);
}
declare class FixtureScriptError extends Error {
  readonly code = "FX_AV_SCRIPT_INVALID";
  constructor(operation: string, detail: string);
}
/** The composition the fixture is asked to live in. `production` must be exactly `false`. */
interface FixtureComposition {
  readonly id: string;
  readonly production: boolean;
}
/** What a script gives: the answer without its label. `observedAt` and `basis` default to the clock and an empty list. */
type ScriptedState = Omit<RouteState, "label" | "observedAt" | "basis"> & {
  readonly observedAt?: string;
  readonly basis?: RouteState["basis"];
};
type ScriptedCapabilities = Omit<RouteCapabilities, "label" | "route" | "observedAt" | "images" | "efforts" | "source"> & Partial<Pick<RouteCapabilities, "route" | "observedAt" | "images" | "efforts" | "source">>;
interface FxAvScript {
  readonly states?: (route: Route, purpose: Purpose) => ScriptedState | undefined;
  readonly failure?: (route: Route, failure: FailureInput) => Omit<FailureReport, "label"> | undefined;
  readonly capabilities?: (route: Route) => ScriptedCapabilities | undefined;
  readonly usage?: (provider: string | undefined) => readonly Omit<UsageReading, "label">[] | undefined;
}
interface FxAvOptions {
  readonly clock: Clock;
  readonly composition: FixtureComposition | undefined | null;
  readonly script?: FxAvScript | undefined;
}
interface FxAvCall {
  readonly operation: "routeStates" | "reportFailure" | "routeCapabilities" | "usage";
  readonly args: readonly unknown[];
}
interface FxAv extends RouteAvailability {
  readonly label: "fixture";
  /** Every question asked, in order, for a test to assert what its subject asked for. */
  readonly calls: readonly FxAvCall[];
}
declare function createFxAv(options: FxAvOptions): FxAv;
//#endregion
//#region src/backend/index.d.ts
/** Names this entry in the Backend's composition records and in tests that open the packed archive. */
declare const PROVIDERS_BACKEND_ENTRY: "@aetheria/providers/backend";
//#endregion
export { AVAILABLE_REASONS, AuthGrant, AuthPurpose, AvailableReason, BAD_ARGUMENTS, BASIS_SIGNALS, BasisEntry, BasisSignal, CARRIER_FAILED, CatalogEntry, CatalogPort, ClassifyOptions, Clock, CredentialKind, CredentialMeta, CredentialMetaPort, CredentialView, Decoded, EffectiveRoute, EffectiveRouteSource, FAILURE_CLASSES, FAILURE_REASONS, FX_AV_REFUSED_IN_PRODUCTION, FX_AV_SCRIPT_INVALID, FailureClass, FailureInput, FailureReason, FailureReport, FixtureComposition, FixtureRefusedError, FixtureScriptError, FxAv, FxAvCall, FxAvOptions, FxAvScript, Guard, Labelled, MemoryView, OPERATION_ERROR, OUTCOME_KINDS, OUT_REASONS, OutReason, Outcome, OutcomeKind, PARAMETERS, PI_PIN, PROVIDERS_ARGUMENTS_REFUSED, PROVIDERS_BACKEND_ENTRY, PROVIDERS_RESULT_INVALID, PURPOSES, Parameter, ParameterName, ParameterStatus, ProductionAvailabilityOptions, ProviderAuthPort, ProvidersOperationError, ProvidersOperationErrorCode, ProvidersOperationHandler, Purpose, REASON_CLASSES, REASON_STATE, REPLY_CONTRACT, REPORT_FAILURE_OPERATION, ROUTE_CAPABILITIES_OPERATION, ROUTE_STATES_OPERATION, ReasonClass, ReportFailureArgs, Route, RouteAvailability, RouteAvailabilityClient, RouteAvailabilityClientOptions, RouteAvailabilityOptions, RouteCapabilities, RouteCapabilitiesArgs, RouteState, RouteStatesArgs, RouteStatesResult, RuleInput, STATES, ScriptedCapabilities, ScriptedState, ServiceParameterName, State, UNKNOWN_REASONS, USAGE_FAILURES, USAGE_OPERATION, UnknownReason, UsageArgs, UsageFailure, UsagePort, UsageRead, UsageReading, UsageResult, UsageWindow, WindowView, Xc11Carrier, aborted, arr, classifyFailure, createFxAv, createProductionAvailability, createProvidersOperations, createRouteAvailability, createRouteAvailabilityClient, decideRoute, decodeFailureReport, decodeReportFailureArgs, decodeRouteCapabilities, decodeRouteCapabilitiesArgs, decodeRouteStatesArgs, decodeRouteStatesResult, decodeUsageArgs, decodeUsageResult, decoder, failed, finite, int, isExtraUsageRefusal, isQuotaWording, iso, lit, logExcerpt, minutesToReset, obj, ok, oneOf, parameter, redact, refused, str, unavailable, windowApplies };