import * as nodeFs from "node:fs";
//#region src/identity.d.ts
declare const MANAGED_WORK_PACKAGE: "@aetheria/orchestration";
//#endregion
//#region src/operations/names.d.ts
declare const CHILDREN_OPERATIONS: readonly ["children.spawn", "children.fork", "children.message", "children.list", "children.interrupt", "children.close", "children.await-report", "children.status", "children.cancel"];
declare const JOBS_OPERATIONS: readonly ["jobs.output", "jobs.list", "jobs.kill", "jobs.cancel"];
declare const JOB_LIFECYCLE_OPERATIONS: readonly ["jobs.reserve", "jobs.attach", "jobs.adopted", "jobs.exited"];
declare const ORCHESTRATION_OPERATIONS: readonly ["children.spawn", "children.fork", "children.message", "children.list", "children.interrupt", "children.close", "children.await-report", "children.status", "children.cancel", "jobs.output", "jobs.list", "jobs.kill", "jobs.cancel", "jobs.reserve", "jobs.attach", "jobs.adopted", "jobs.exited"];
type OrchestrationOperation = (typeof ORCHESTRATION_OPERATIONS)[number];
/**
 * Calls that exist only between trusted Backend modules (D17, D20). They are never XC-6 operations and no tool can reach them: the caller must be a Backend
 * module, so none has a wire name and none appears in ORCHESTRATION_OPERATIONS.
 */
declare const BACKEND_DIRECT_CALLS: readonly ["admitTurn", "interruptTurn", "subscribeSettled", "cancelTree"];
type BackendDirectCall = (typeof BACKEND_DIRECT_CALLS)[number];
//#endregion
//#region src/operations/codes.d.ts
/** Every design C1 code except `AUTH_*` (M03's), plus the four this contract adds: JOB_CONFLICT, JOB_IDENTITY_MISMATCH, ORCHESTRATION_UNAVAILABLE and ABORTED. */
declare const ORCHESTRATION_CODE_CLASSES: {
  readonly CHILD_LIMIT: "refusal";
  readonly CHILD_NOT_OWNED: "refusal";
  readonly CHILD_NOT_ADJACENT: "refusal";
  readonly CHILD_NOT_RESUMABLE: "refusal";
  readonly NOT_AUTHORIZED: "refusal";
  readonly JOB_IDENTITY_MISMATCH: "refusal";
  readonly JOB_CONFLICT: "conflict";
  readonly JOB_NOT_FOUND: "absence";
  readonly CHILD_START_FAILED: "failure";
  readonly FORK_FAILED: "failure";
  readonly FORK_PARTIAL: "failure";
  readonly CHILD_DELIVERY_UNAVAILABLE: "unavailable";
  readonly CHILD_PARENT_UNAVAILABLE: "unavailable";
  readonly ORCHESTRATION_UNAVAILABLE: "unavailable";
  readonly ABORTED: "aborted";
};
type OrchestrationCode = keyof typeof ORCHESTRATION_CODE_CLASSES;
type OrchestrationCodeClass = (typeof ORCHESTRATION_CODE_CLASSES)[OrchestrationCode];
declare const ORCHESTRATION_CODES: OrchestrationCode[];
/** What M03's `authorize` and the identity store can answer for a spawn or fork; these arrive as the XC-6 `refused` reply, never inside `done`. */
declare const M03_AUTHORIZE_CODES: readonly ["ROLE_PROJECT_LAYER", "ROLE_GENERIC_DELEGATION", "AUTH_TOOL_NOT_ALLOWED", "AUTH_DEPTH_EXCEEDED", "AUTH_IDENTITY_UNAVAILABLE", "AUTH_ROLE_REMOVED", "AUTH_IDENTITY_INVALID"];
type Outcome = "refused" | "failed" | "unavailable" | "aborted";
/** The distinct outcome a code renders as; an unknown code is a programming error, never a default. */
declare function outcomeOfCode(code: string): Outcome;
type Xc6ReplyKind = "done" | "refused" | "unavailable";
/** Which XC-6 reply carries a code (see the header). */
declare function xc6ReplyKindOf(code: string): Xc6ReplyKind;
//#endregion
//#region src/operations/types.d.ts
type ChildMode = "one-shot" | "continuable";
type ChildState = "running" | "idle" | "closed" | "unknown";
type JobState = "starting" | "running" | "exited" | "killed" | "failed" | "lost";
type FinalJobState = "exited" | "killed" | "failed" | "lost";
type SettleStatus = "completed" | "failed" | "interrupted";
/** Exactly one of an exit code or a terminating signal, as the runner observed it. */
interface JobExit {
  readonly code: number | null;
  readonly signal: string | null;
}
interface JobFlags {
  readonly livenessIndeterminate?: true;
  readonly terminationUnconfirmed?: true;
}
interface ChildReport {
  readonly status: SettleStatus;
  readonly cause?: string;
  readonly text: string;
  readonly structured?: unknown;
  /** The route the child ended on, 1-based. */
  readonly route: number;
}
/** Exactly one of `role` and `allow`. `delivery: "record-only"` is for a one-shot child only. */
type ChildrenSpawnArgs = ({
  readonly role: string;
} | {
  readonly allow: readonly string[];
}) & {
  readonly prompt: string;
  readonly mode: ChildMode;
  readonly label?: string;
  readonly outputSchema?: Readonly<Record<string, unknown>>;
  readonly delivery?: "record-only";
};
interface ChildrenSpawnValue {
  readonly childId: string;
  readonly messageId: string;
  readonly route: number;
  readonly allRoutesOut: boolean;
}
interface ChildrenForkArgs {
  readonly prefix: "all" | {
    readonly runId: string;
  };
  readonly prompt: string;
  /** The fork child's explicit allow-list: a subset of the parent's callable tools minus every delegation, workflow and goal tool. */
  readonly allow: readonly string[];
  readonly label?: string;
}
interface ChildrenForkValue {
  readonly childId: string;
}
interface ChildrenMessageArgs {
  readonly target: string;
  readonly content: string;
}
interface ChildrenMessageValue {
  readonly messageId: string;
}
interface ChildrenListArgs {
  readonly scope: "children" | "descendants";
}
interface ChildRow {
  readonly childId: string;
  readonly parentId: string;
  readonly depth: number;
  readonly role: string | null;
  readonly mode: ChildMode;
  readonly label?: string;
  readonly state: ChildState;
  readonly lastOutcome: {
    readonly status: SettleStatus;
    readonly cause?: string;
  } | null;
  readonly route: number | null;
}
interface ChildDiagnostic {
  readonly kind: "corrupt" | "unsupported" | "unavailable" | "unregistered-fork";
  readonly id: string;
  readonly detail?: string;
}
interface ChildrenListValue {
  readonly rows: readonly ChildRow[];
  readonly diagnostics: readonly ChildDiagnostic[];
}
interface ChildrenTargetArgs {
  readonly target: string;
}
type ChildrenInterruptArgs = ChildrenTargetArgs;
type ChildrenCloseArgs = ChildrenTargetArgs;
interface AcceptedValue {
  readonly accepted: true;
}
interface ChildrenCloseValue {
  readonly closed: true;
  readonly report?: ChildReport;
  readonly killedJobs: readonly string[];
}
interface ChildrenAwaitReportArgs {
  readonly target: string;
  readonly requestId?: string;
}
/** The XC-10 session id of the child, never a thread id; the root comes from the caller's identity. */
interface ChildrenStatusArgs {
  readonly childSessionId: string;
}
interface ChildrenStatusValue {
  readonly owned: boolean | "unknown";
  readonly state: ChildState;
}
interface CancelWaitArgs {
  readonly requestId: string;
}
type ChildrenCancelArgs = CancelWaitArgs;
type JobsCancelArgs = CancelWaitArgs;
interface JobsOutputArgs {
  readonly jobId: string;
  readonly wait?: boolean;
  readonly timeoutMs?: number;
  readonly requestId?: string;
}
interface OutputChunk {
  readonly stream: "stdout" | "stderr";
  readonly from: number;
  readonly to: number;
  readonly text: string;
  readonly truncated: boolean;
}
type JobsOutputValue = JobFlags & {
  readonly jobId: string;
  readonly state: JobState;
  readonly streams: readonly OutputChunk[];
  readonly exit?: JobExit;
  readonly waitElapsed: boolean;
};
interface JobsListArgs {
  readonly scope?: "own" | "descendants";
}
type JobRow = JobFlags & {
  readonly jobId: string;
  readonly ownerSessionId: string;
  readonly label: string;
  readonly state: JobState;
  readonly completion: "pending" | "inserted" | "none";
  readonly collectedAt?: string;
  readonly deliveryUncertain?: true;
  readonly exit?: JobExit;
};
interface JobsListValue {
  readonly jobs: readonly JobRow[];
}
interface JobsKillArgs {
  readonly jobId: string;
}
type JobsKillValue = JobFlags & {
  readonly jobId: string;
  readonly state: FinalJobState;
  readonly exit?: JobExit;
};
/** Before the spawn. The output location is derived by the Backend from the run key; the Agent never chooses a path. */
interface JobsReserveArgs {
  readonly runKey: string;
  readonly label: string;
  readonly mode: "background" | "foreground";
}
interface JobsReserveValue {
  readonly jobId: string;
  readonly state: "starting";
}
/** Before the runner releases the gated command. An unreadable start time is not representable. */
interface JobsAttachArgs {
  readonly jobId: string;
  readonly pid: number;
  readonly pgid: number;
  readonly startIdentity: {
    readonly pid: number;
    readonly startTime: string;
  };
}
interface JobsAttachValue {
  readonly jobId: string;
  readonly attached: true;
}
interface JobsAdoptedArgs {
  readonly jobId: string;
  readonly via: "background" | "timeout";
}
/** The confirmation exists only after the adoption is persisted. */
interface JobsAdoptedValue {
  readonly jobId: string;
  readonly confirmation: string;
}
interface JobsExitedArgs {
  readonly jobId: string;
  readonly exit: JobExit;
}
interface JobsExitedValue {
  readonly jobId: string;
  readonly recorded: true;
  readonly supplemental: boolean;
}
/** A failed result. `CHILD_START_FAILED`, `FORK_FAILED` and `FORK_PARTIAL` carry data; every other code carries only an optional detail. */
type OrchestrationFailure = {
  readonly ok: false;
  readonly code: "CHILD_START_FAILED";
  readonly cause?: string;
  readonly leftoverThreadId?: string;
  readonly detail?: string;
} | {
  readonly ok: false;
  readonly code: "FORK_FAILED";
  readonly cause?: string;
  readonly detail?: string;
} | {
  readonly ok: false;
  readonly code: "FORK_PARTIAL";
  readonly forkSessionId: string;
  readonly registered: false;
  readonly step: 2 | 3;
  readonly leftoverThreadId?: string;
  readonly detail?: string;
} | {
  readonly ok: false;
  readonly code: Exclude<string, "CHILD_START_FAILED" | "FORK_FAILED" | "FORK_PARTIAL">;
  readonly detail?: string;
};
type OrchestrationResult<V> = {
  readonly ok: true;
  readonly value: V;
} | OrchestrationFailure;
//#endregion
//#region src/operations/strict.d.ts
type Decoded<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly reason: string;
};
//#endregion
//#region src/operations/codecs.d.ts
/** One decoder per vector set, keyed by the same names the vectors use. */
declare const orchestrationCodecs: {
  readonly childrenSpawnArgs: (input: unknown) => Decoded<ChildrenSpawnArgs>;
  readonly childrenSpawnResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenSpawnValue>>;
  readonly childrenForkArgs: (input: unknown) => Decoded<ChildrenForkArgs>;
  readonly childrenForkResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenForkValue>>;
  readonly childrenMessageArgs: (input: unknown) => Decoded<ChildrenMessageArgs>;
  readonly childrenMessageResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenMessageValue>>;
  readonly childrenListArgs: (input: unknown) => Decoded<ChildrenListArgs>;
  readonly childrenListResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenListValue>>;
  readonly childrenInterruptArgs: (input: unknown) => Decoded<ChildrenTargetArgs>;
  readonly childrenInterruptResult: (input: unknown) => Decoded<OrchestrationResult<AcceptedValue>>;
  readonly childrenCloseArgs: (input: unknown) => Decoded<ChildrenTargetArgs>;
  readonly childrenCloseResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenCloseValue>>;
  readonly childrenAwaitReportArgs: (input: unknown) => Decoded<ChildrenAwaitReportArgs>;
  readonly childrenAwaitReportResult: (input: unknown) => Decoded<OrchestrationResult<ChildReport>>;
  readonly childrenStatusArgs: (input: unknown) => Decoded<ChildrenStatusArgs>;
  readonly childrenStatusResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenStatusValue>>;
  readonly childrenCancelArgs: (input: unknown) => Decoded<CancelWaitArgs>;
  readonly childrenCancelResult: (input: unknown) => Decoded<OrchestrationResult<AcceptedValue>>;
  readonly jobsOutputArgs: (input: unknown) => Decoded<JobsOutputArgs>;
  readonly jobsOutputResult: (input: unknown) => Decoded<OrchestrationResult<JobsOutputValue>>;
  readonly jobsListArgs: (input: unknown) => Decoded<JobsListArgs>;
  readonly jobsListResult: (input: unknown) => Decoded<OrchestrationResult<JobsListValue>>;
  readonly jobsKillArgs: (input: unknown) => Decoded<JobsKillArgs>;
  readonly jobsKillResult: (input: unknown) => Decoded<OrchestrationResult<JobsKillValue>>;
  readonly jobsCancelArgs: (input: unknown) => Decoded<CancelWaitArgs>;
  readonly jobsCancelResult: (input: unknown) => Decoded<OrchestrationResult<AcceptedValue>>;
  readonly jobsReserveArgs: (input: unknown) => Decoded<JobsReserveArgs>;
  readonly jobsReserveResult: (input: unknown) => Decoded<OrchestrationResult<JobsReserveValue>>;
  readonly jobsAttachArgs: (input: unknown) => Decoded<JobsAttachArgs>;
  readonly jobsAttachResult: (input: unknown) => Decoded<OrchestrationResult<JobsAttachValue>>;
  readonly jobsAdoptedArgs: (input: unknown) => Decoded<JobsAdoptedArgs>;
  readonly jobsAdoptedResult: (input: unknown) => Decoded<OrchestrationResult<JobsAdoptedValue>>;
  readonly jobsExitedArgs: (input: unknown) => Decoded<JobsExitedArgs>;
  readonly jobsExitedResult: (input: unknown) => Decoded<OrchestrationResult<JobsExitedValue>>;
};
type OrchestrationCodecName = keyof typeof orchestrationCodecs;
//#endregion
//#region src/fallback/consult.d.ts
interface Xc11Route {
  readonly provider: string;
  readonly model: string;
}
interface AvailabilitySource {
  routeStates(routes: readonly Xc11Route[], purpose: "launch" | "switch" | "display"): Promise<unknown>;
  reportFailure(route: Xc11Route, failure: {
    readonly message: string;
  }): Promise<unknown>;
}
//#endregion
//#region src/children/ports.d.ts
type PortResult<V, R extends string> = ({
  readonly ok: true;
} & V) | {
  readonly ok: false;
  readonly reason: R;
  readonly detail?: string;
};
declare const THREAD_PORT_CALLS: readonly ["createChildThread", "bindChildSession", "releaseFirstTurn", "forkThread", "withdrawForkRequest", "startTurn", "interrupt", "status", "subscribeTurnCompleted", "readDelegatedCompletion", "readRestartNotes", "suppressCompletionDelivery", "readChildResult", "readLastRun", "readMessageReceipt", "readLastHumanMessage", "close"];
type ThreadPortCall = (typeof THREAD_PORT_CALLS)[number];
/** T3's `completionWake` for a delegated task. Under `settled_only` a completion that arrives while the parent's run is live is never delivered. */
declare const COMPLETION_WAKES: readonly ["always", "settled_only"];
type CompletionWake = (typeof COMPLETION_WAKES)[number];
/** Decision (b): `spawnChild` sets `always` for an ordinary child, so a completion reaches a busy or idle parent exactly once. A `record-only` child is settled apart. */
declare const ORDINARY_CHILD_COMPLETION_WAKE: CompletionWake;
interface ModelSelection {
  readonly provider: string;
  readonly model: string;
  readonly effort?: string | undefined;
}
interface ThreadLineage {
  readonly parentThreadId: string;
  readonly rootThreadId: string;
  readonly relationshipToParent: "subagent" | "fork";
}
interface CreateChildThreadInput {
  /** Derived from the spawn attempt id, so a repeated create is the same command. */
  readonly commandId: string;
  readonly parentThreadId: string;
  /** The parent's active run and node, taken from trusted T3 context, never from model arguments. */
  readonly parentRunId: string;
  readonly parentNodeId: string;
  readonly task: string;
  readonly title?: string | undefined;
  readonly modelSelection: ModelSelection;
  readonly runtimeMode: string;
  readonly interactionMode: string;
  /**
   * The held child's working folder, passed explicitly: T3 gives a held (root-strategy) child null branch and worktree, so nothing may be inferred from the
   * thread. An absolute path of the parent's project.
   */
  readonly workingFolder: string;
  readonly completionWake: CompletionWake;
}
interface ThreadStatus {
  readonly activity: "running" | "idle" | "unknown";
  readonly queued: number | "unknown";
  readonly resident: boolean | "unknown";
  readonly settleSeqHint?: number | undefined;
}
type TurnOutcome = "completed" | "failed" | "interrupted";
interface TurnCompletedEvent {
  readonly threadId: string;
  /** The run id. */
  readonly turnId: string;
  readonly outcome: TurnOutcome;
  readonly settledAt: string;
  /** Redacted, from the run's error item. */
  readonly errorText?: string | undefined;
  /** The provider's stop reason when the completion carried one. Only an observed output-limit stop reason makes `max-tokens` an outcome (D17). */
  readonly stopReason?: string | undefined;
}
/** T3's newest run for a thread (step 13): `active` is a run that has not ended; any other outcome is T3's terminal status mapped as for a settle. */
interface LastRun {
  readonly runId: string;
  readonly outcome: TurnOutcome | "active";
  readonly settledAt: string | null;
  readonly errorText: string | null;
}
type DelegatedCompletionState = "pending" | "claimed" | "acknowledged" | "delivered" | "disposed";
interface RestartNote {
  readonly kind: string;
  readonly label: string;
  readonly id?: string | undefined;
  readonly awaited?: boolean | undefined;
}
interface ThreadPort {
  /** Records the child thread and its task with the first turn held (T3 `delegated_task.request` with `workspaceStrategy {type:"root"}`); no turn starts. */
  createChildThread(input: CreateChildThreadInput): Promise<PortResult<{
    readonly threadId: string;
    readonly lineage: ThreadLineage;
    readonly heldMessageId: string;
  }, "parent-unavailable" | "create-failed">>;
  /**
   * R1 route, as decided 2026-11-12: opens the child's provider session WITH the Pi session id the service chose (`piSessionId`, Pi's `--session-id`), calls
   * ensure-thread on the held row and persists that session before release, so no provider request exists. The identity is already active under that id, so the
   * Agent host resumes it instead of promoting the fresh session to main. The answer names the session actually bound: the service rolls back if it is not the one
   * asked for. Idempotent: a repeat returns the same session id and never makes a second one. Never starts a turn.
   */
  bindChildSession(input: {
    readonly threadId: string;
    readonly heldMessageId: string;
    readonly piSessionId: string;
  }): Promise<PortResult<{
    readonly piSessionId: string;
  }, "parent-unavailable" | "session-unavailable" | "bind-failed">>;
  /**
   * Derives T3's command id from the held message id and reads the run state before mapping T3's refusal of an already-released or unknown run to accepted:
   * a repeat is accepted only when the run is truly past its hold. Releasing is the only call that can start the first turn.
   */
  releaseFirstTurn(input: {
    readonly threadId: string;
    readonly heldMessageId: string;
  }): Promise<PortResult<{
    readonly accepted: true;
  }, "delivery-unavailable">>;
  /**
   * T3's `thread.fork` (native round 2): creates the fork THREAD only. T3 makes the Pi session copy later, when the thread's first turn starts, so no session exists to return. The
   * Backend's chosen Pi session id (`piSessionId`) is registered in the IP-25 slot under `fork:<targetThreadId>`, so the copy is made under that id (`pi --fork <file> --session-id <id>`,
   * probed on Pi 1.5.0) and the identity can be activated under it BEFORE the copy exists. The request is withdrawn if the thread is closed first.
   */
  forkThread(input: {
    readonly parentThreadId: string;
    readonly sourcePoint: "latest_stable" | {
      readonly run: string;
    };
    readonly targetThreadId: string;
    readonly piSessionId: string;
  }): Promise<PortResult<{
    readonly threadId: string;
  }, "fork-failed" | "prefix-unsupported" | "unavailable">>;
  /**
   * Releases the Pi session id asked for at `forkThread`, which is requested under two keys (the plain thread key read by the portable route's open launch, and `fork:<threadId>` read by
   * the native route's `--fork` launch); whichever route ran leaves the other unread. Called once the fork is over, success or rollback. Idempotent; its failure changes nothing.
   */
  withdrawForkRequest(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly released: true;
  }, "unavailable">>;
  /** The adapter derives T3's command id from the message id, so a repeated message id counts as accepted. */
  startTurn(input: {
    readonly threadId: string;
    readonly content: string;
    readonly delivery: "queue" | "steer";
    readonly messageId: string;
  }): Promise<PortResult<{
    readonly accepted: true;
    readonly messageId: string;
  }, "not-resumable" | "delivery-unavailable">>;
  /** An absent target is an accepted no-op. */
  interrupt(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly accepted: true;
  }, "unavailable">>;
  status(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly status: ThreadStatus;
  }, "unavailable">>;
  /** Terminal `run.updated` events mapped by run id; a non-terminal status, including `waiting`, is ignored. */
  subscribeTurnCompleted(scope: {
    readonly threadId: string;
  } | {
    readonly rootThreadId: string;
  }, handler: (event: TurnCompletedEvent) => void): {
    unsubscribe(): void;
  };
  readDelegatedCompletion(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly state: DelegatedCompletionState;
    readonly generation?: number | undefined;
    readonly messageId?: string | undefined;
  }, "unavailable">>;
  readRestartNotes(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly notes: readonly RestartNote[];
  }, "unavailable">>;
  /**
   * Record-only delivery (Plan step 12): keeps this child's completion out of its parent's chat. T3's own `delegated_task.completion-delivery.dispose` on the child's task,
   * dispatched while the child cannot have completed yet (held, before release). T3 skips a disposed task at both points it delivers a completion (the offer when the child
   * completes, and the delivery when the parent settles). Idempotent: a repeat is accepted. A failure is the service's to roll back: the guarantee is not given without it.
   */
  suppressCompletionDelivery(input: {
    readonly threadId: string;
    readonly parentThreadId: string;
  }): Promise<PortResult<{
    readonly suppressed: true;
  }, "unavailable">>;
  /**
   * The child's final result as T3 recorded it on the parent's task when the child completed: the run's final text and T3's terminal status. `not-terminal` is a child that has
   * not completed (or whose completion T3 has not yet recorded); `unavailable` is a projection that cannot be read. Never a guess.
   */
  readChildResult(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly status: TurnOutcome;
    readonly text: string;
  }, "not-terminal" | "unavailable">>;
  /**
   * Step 13: T3's newest run for the thread, as it stands now. After a restart T3 has cut a running child's run (its terminal status is T3's) and, with R2, has not re-run it;
   * boot reads it to bring M05's settle record up to date. `run: null` is a thread with no run. `unavailable` is never read as either.
   */
  readLastRun(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly run: LastRun | null;
  }, "unavailable">>;
  /**
   * Step 15 (the outbox, C4): whether T3 accepted a message under this id for the thread, read from its receipt or history. `found: true` is accepted; `found: false` is
   * known absent; `unavailable` (history unreadable, no such lookup) proves neither. Optional: an adapter without it makes every interrupted insert "unknown", and the outbox then
   * retries blind only when the inbox is known to reject a repeated id.
   */
  readMessageReceipt?(input: {
    readonly threadId: string;
    readonly messageId: string;
  }): Promise<PortResult<{
    readonly found: boolean;
  }, "unavailable">>;
  /**
   * Step 17 (wake bound, C4): the id of the newest message a HUMAN created on the thread (T3's `createdBy: "user"`), or null when none. A change of this id is what resets the
   * consecutive-wake count; the outbox's own messages are agent-created and never move it. Optional: without it only an explicit `humanMessage()` resets.
   */
  readLastHumanMessage?(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly messageId: string | null;
  }, "unavailable">>;
  /** T3 `thread.stop` with `stopDelegatedTasks: false`, never `thread.delete`. A not-found error is treated as closed. */
  close(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly closed: true;
  }, "unavailable">>;
}
/** The writer name M05 uses with M03's identity store; the main session's records stay `agent-host`. */
declare const CHILD_WRITER = "managed-work";
type IdentityStoreResult = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason: string;
};
type IdentityStoreRead = {
  readonly state: "active" | "pending" | "retired" | "absent" | "corrupt" | "unavailable";
  readonly [key: string]: unknown;
};
/** M03's store API as M05 uses it, keyed by the child's Pi session id. The envelopes are never written by hand and a retired id is never reactivated. */
interface ChildIdentityWriter {
  stage(attemptId: string, record: unknown): IdentityStoreResult;
  activate(attemptId: string, sessionId: string): IdentityStoreResult;
  discard(attemptId: string): IdentityStoreResult;
  retire(sessionId: string, reason: string): IdentityStoreResult;
  /** From then on `retire` is refused: an accepted child cannot be rolled back. */
  noteAccepted(sessionId: string): IdentityStoreResult;
  read(sessionId: string): IdentityStoreRead;
}
/** M06's `inheritPlanMode`, a direct Backend call that needs the child already in the session tree (so it runs after activation). */
interface PlanModeInheritPort {
  inheritPlanMode(parentSessionId: string, childSessionId: string, kind: "spawn" | "fork"): Promise<{
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: "INTERACTION_UNAVAILABLE";
  }>;
}
/** Completes once M06's own resume handling (`reconcileWaits`, then redeliver) has finished for a session; M05 makes no second reconcile call. */
interface ResumeBarrierPort {
  resumed(sessionId: string): Promise<void>;
}
interface Clock {
  now(): number;
}
type RouteAvailability = "available" | "out" | "unknown";
interface RouteRef {
  readonly provider: string;
  readonly model: string;
  readonly effort?: string | undefined;
}
/**
 * M09's route availability as the fallback uses it, in M09's own shapes (Plan step 21): `routeStates(routes, purpose)` answers one state object per route and `reportFailure(route, failure)` a
 * failure report; the production service or its XC-11 outcome form both read the same (fallback/consult.ts). Whatever cannot be read makes every route unknown, never out.
 */
type AvailabilityPort = AvailabilitySource;
interface ProcessStartIdentity {
  readonly pid: number;
  readonly startTime: string;
}
/** M09's process-group primitives as the job registry uses them. An unreadable start identity or unknown liveness is `unknown`, never gone. */
interface ProcessGroupPort {
  readStartIdentity(pid: number): Promise<ProcessStartIdentity | null>;
  probe(target: {
    readonly pgid: number;
    readonly startIdentity: ProcessStartIdentity;
  }): Promise<{
    readonly state: "alive" | "empty" | "unknown";
  }>;
  terminate(target: {
    readonly pgid: number;
    readonly startIdentity: ProcessStartIdentity;
  }, options: {
    readonly graceMs: number;
  }): Promise<{
    readonly state: "confirmed-empty" | "not-empty" | "unknown" | "no-process";
    readonly signalsSent: readonly ("SIGTERM" | "SIGKILL")[];
  }>;
}
//#endregion
//#region src/children/settle.d.ts
/** The settle outcome of a run status, or null when the status is not terminal or not recognised. */
declare function mapRunStatus(status: unknown): TurnOutcome | null;
//#endregion
//#region src/outbox/keys.d.ts
declare const OUTBOX_STATES: readonly ["pending", "attempting", "inserted", "recorded", "abandoned", "unknown"];
type OutboxState = (typeof OUTBOX_STATES)[number];
declare const OUTBOX_KINDS: readonly ["job-completion", "job-lost", "restart-notice", "route-notice", "goal-round", "goal-notice", "child-report"];
type OutboxKind = (typeof OUTBOX_KINDS)[number];
/** The restart notice M05 sends when T3 wrote none (decision d): once per child per Backend boot. T3 thread ids hold colons, so the key is read from its ends. */
declare const restartNoticeKey: (childId: unknown, bootEpoch: unknown) => string;
/** The lost-job notice (D9). */
declare const jobLostKey: (jobId: unknown) => string;
/** A job's completion notice (D8). */
declare const jobCompletionKey: (jobId: unknown) => string;
/** The route notice of one switch (D12: child plus switch number). */
declare const routeNoticeKey: (childId: unknown, switchNumber: unknown) => string;
//#endregion
//#region src/outbox/entry.d.ts
/** The states an entry is stored in. `unknown` is only ever an answer of `state(key)`: nothing is known, so nothing is stored. */
declare const STORED_OUTBOX_STATES: readonly ["pending", "attempting", "inserted", "recorded", "abandoned"];
type StoredOutboxState = (typeof STORED_OUTBOX_STATES)[number];
declare const FINAL_OUTBOX_STATES: readonly StoredOutboxState[];
declare const MAX_ENTRY_TEXT = 16000;
/** An owner keeps at most this many entries; the oldest FINAL ones are dropped first and a non-final one is never dropped. */
declare const MAX_OUTBOX_ENTRIES = 256;
interface OutboxEntry {
  /** Immutable. It makes a repeated delivery collide, and derives the message id of a single-entry batch. */
  readonly key: string;
  /** The session the message is for; its thread is found at delivery time. */
  readonly targetSessionId: string;
  readonly kind: OutboxKind;
  readonly state: StoredOutboxState;
  /** A volatile entry is never delivered after a restart: boot marks it `abandoned` unless it is already final. */
  readonly volatile: boolean;
  /** What the owner is told. Kept so a delivery after a restart needs nothing else. */
  readonly text: string;
  readonly createdAt: number;
  /** The id of the T3 message the entry went out in. Fixed when the entry is first attempted (the frozen batch's id); T3's command id derives from it. */
  readonly messageId: string | null;
  /** The frozen coalesced batch (sorted keys) this entry was attempted in: a retry sends the SAME keys under the SAME message id. */
  readonly batchId: string | null;
  readonly attempts: number;
  /** The delivery mode last chosen from the owner's status. The inbox is the arbiter, so it is a record, not a promise. */
  readonly mode: "steer" | "queue" | null;
  /** Set when an attempt's outcome is unknown and could not be settled by a scan; shown as `delivery-uncertain`. */
  readonly uncertainSince: number | null;
  /** Bounded backoff: no attempt before this time. */
  readonly nextAttemptAt: number | null;
  readonly settledAt: number | null;
}
/** An ordinary child completion is T3's delivery, never an entry: a key shaped like one is refused wherever an entry is made or read. */
declare const isChildCompletionKey: (key: string) => boolean;
declare function outboxEntryProblem(value: unknown): string | null;
declare function outboxProblem(value: unknown): string | null;
/** An entry's delivery as a list row shows it: an unknown outcome is `delivery-uncertain`, never plain `pending`. */
declare function deliveryView(entry: OutboxEntry): "pending" | "attempting" | "inserted" | "recorded" | "abandoned" | "delivery-uncertain";
interface NewEntry {
  readonly key: string;
  readonly targetSessionId: string;
  readonly kind: OutboxKind;
  readonly volatile: boolean;
  readonly text: string;
}
declare function newPendingEntry(spec: NewEntry, now: number): OutboxEntry;
/** Appends an entry unless one with the key exists; keeps the list within its bound by dropping the oldest FINAL entries only. */
declare function withEntry(entries: readonly OutboxEntry[], entry: OutboxEntry): readonly OutboxEntry[];
//#endregion
//#region src/stores/records.d.ts
declare const RECORD_V: 1;
/** How far a spawn got. `activated`: identity active, first turn not released. `releasing`: written before the release is asked for. `accepted`: the inbox took the prompt. */
type ChildPhase = "activated" | "releasing" | "accepted";
declare const CHILD_PHASES: readonly ChildPhase[];
/** One route of a role child as the authorizer gave it at spawn: the provider, the model and, when the role names one, the effort. */
interface StoredRoute {
  readonly provider: string;
  readonly model: string;
  readonly effort?: string;
}
/** What one route switch said, exactly: persisted with the switch so a reader sees what was told, never what would be told now. The text itself is the outbox entry's. */
interface RouteNoticeRecord {
  readonly switch: number;
  readonly kind: "aetheria-fallback";
  readonly role: string;
  readonly trigger: "error";
  readonly class: string;
  readonly from: string;
  readonly to: string;
  readonly fromIndex: number;
  readonly toIndex: number;
  readonly effort: string | null;
}
interface ChildRoute {
  /** 1-based. */
  readonly index: number;
  readonly failed: readonly number[];
  readonly switches: number;
  readonly allRoutesOut: boolean;
  /**
   * Step 22 (fallback). The child's routes in order, kept ONLY for a role child with two or more (the only kind that falls back): the next turn's route is applied from this record, so a
   * restart cannot lose it. Absent for a child written before it existed, a spawn-explicit child and a single-route role: those never switch.
   */
  readonly routes?: readonly StoredRoute[];
  /** Step 22: the role the routes belong to (M03's role name), for the notice's source fields. Present with `routes`. */
  readonly role?: string;
  /** Step 22: the one short wait this child may take was taken (recorded BEFORE it starts, so a restart cannot grant a second). */
  readonly waited?: boolean;
  /** Step 22: one entry per switch, in order, immutable once written. */
  readonly notices?: readonly RouteNoticeRecord[];
}
interface ChildSettle {
  readonly settleSeq: number;
  readonly lastTurnId: string | null;
  /** The most recent run ids seen, so a replayed or reordered event is recognised; bounded. */
  readonly seenTurnIds: readonly string[];
  readonly settledAt: string | null;
  readonly status: SettleStatus | null;
  readonly cause: string | null;
  readonly errorText: string | null;
  readonly route: number | null;
}
interface StoredReport {
  readonly status: SettleStatus;
  readonly cause: string | null;
  readonly text: string;
  readonly structured: unknown | null;
  /** 1-based: the route the child ended on. */
  readonly route: number;
}
type RequestKind = "interrupt" | "close" | "cancel";
interface PendingRequest {
  readonly kind: RequestKind;
  readonly cause: string;
  readonly at: number;
}
interface ChildRecord {
  readonly v: typeof RECORD_V;
  readonly threadId: string;
  /** The root session id admission counts this child under. */
  readonly admissionRoot: string;
  readonly phase: ChildPhase;
  readonly route: ChildRoute;
  readonly closed: boolean;
  readonly closedCause: string | null;
  readonly delivery: "ordinary" | "record-only";
  /**
   * The mode the child was spawned in and its label, kept because neither is anywhere else: T3's lineage does not hold them and M03's record names the role and authority only
   * (step 10, list rows and the one-shot rules). A record written before they existed reads with both null; mode null is never guessed.
   */
  readonly mode: ChildMode | null;
  readonly label: string | null;
  /** The JSON Schema (supported subset, children/report-schema.ts) the child's final report must match, or null. Null for records written before it existed. */
  readonly outputSchema: Readonly<Record<string, unknown>> | null;
  /**
   * The stored final report of a record-only child (step 12), written once when its settle is read from T3 and never changed: `awaitReport` returns it as it is on every call.
   * `text` is the child's final text exactly as T3 recorded it (a raw invalid report stays here with status failed/schema-invalid); `structured` is the parsed JSON when a schema
   * was given and matched. Null until the child has settled and its text has been read.
   */
  readonly report: StoredReport | null;
  /**
   * Step 13: the boot epoch of a restart whose notice to the parent has not been delivered (the outbox seam is step 15's, or the delivery failed, or T3's own note could not be read).
   * Set when boot finds the child's run cut; cleared when the notice is delivered or T3's own note covers it. The next boot retries it under THIS epoch's key, so a repeat never
   * makes a second message. Null for a record written before it existed.
   */
  readonly restartNoticeEpoch: number | null;
  /** Step 14: admitted turns by key (see `Admission`); empty for a record written before it existed. */
  readonly admissions: readonly Admission[];
  readonly settle: ChildSettle;
  readonly pendingRequest: PendingRequest | null;
  /** Outbox entries (C4) live in the owner's record (outbox/entry.ts): a restart notice, a route notice, a stored-only report. Never an ordinary child completion. */
  readonly outbox: readonly OutboxEntry[];
  readonly diagnostic: string | null;
}
/**
 * One admitted turn (step 14, `admitTurn`): the key the trusted module gave, the message id the turn was sent under, and the origin recorded as data. `admitting` is written BEFORE
 * T3 is asked, so a lost reply is retried with the SAME message id (T3 derives its command id from it); `admitted` once T3 accepted. Bounded: the oldest key is forgotten first.
 */
interface Admission {
  readonly key: string;
  readonly messageId: string;
  readonly state: "admitting" | "admitted";
  readonly origin: Readonly<Record<string, unknown>>;
  readonly at: number;
}
interface MainSettle {
  readonly settleSeq: number;
  /** The run id of the newest settled run. */
  readonly lastTurnId: string | null;
  readonly status: SettleStatus | null;
  readonly cause: string | null;
  /** Run ids already settled, so a replay changes nothing (bounded like a child's). Absent in a record written before it existed. */
  readonly seenTurnIds?: readonly string[];
}
interface ForkRollbackTombstone {
  readonly kind: "fork-rolled-back";
  readonly threadId: string;
  /** The expected Pi id whose M03 child identity M05 retired. */
  readonly sessionId: string;
}
interface MainRecord {
  readonly v: typeof RECORD_V;
  readonly sessionId: string;
  readonly settle: MainSettle;
  readonly outbox: readonly OutboxEntry[];
  /** Step 14: admitted turns by key; absent in a record written before it existed. */
  readonly admissions?: readonly Admission[];
  /** Step 14: the cause of an interrupt asked for before T3 was, named by the settle that follows. */
  readonly pendingRequest?: PendingRequest | null;
  /** Step 18: durable evidence for a Pi session the host promoted to main during a rolled-back fork. */
  readonly forkRollback?: ForkRollbackTombstone | undefined;
}
declare function newChildRecord(threadId: string, init: {
  readonly admissionRoot: string;
  readonly delivery?: "ordinary" | "record-only";
  readonly route?: Partial<ChildRoute>;
  readonly phase?: ChildPhase;
  readonly mode?: ChildMode | null;
  readonly label?: string | null;
  readonly outputSchema?: Readonly<Record<string, unknown>> | null;
}): ChildRecord;
type Validated<R> = {
  readonly ok: true;
  readonly record: R;
} | {
  readonly ok: false;
  readonly unsupported: boolean;
  readonly problem: string;
};
declare function validateChildRecord(input: unknown): Validated<ChildRecord>;
declare function validateMainRecord(input: unknown): Validated<MainRecord>;
//#endregion
//#region src/jobs/record.d.ts
declare const JOB_RECORD_V: 1;
/** A job id is a single safe path component: it names the job's folder. */
declare const SAFE_JOB_ID: RegExp;
/** The output reference is relative to the shell runs folder under the state root and is never a path the caller chose: letters, digits and `._-`, no empty or dotted segment. */
declare const SAFE_OUTPUT_REF: RegExp;
declare const MAX_CURSOR_OWNERS = 32;
interface JobExitRecord {
  readonly code: number | null;
  readonly signal: string | null;
  readonly at: number;
}
interface JobStartIdentity {
  readonly pid: number;
  readonly startTime: string;
}
interface JobCursor {
  readonly stdout: number;
  readonly stderr: number;
}
interface JobLost {
  readonly cause: string;
  readonly livenessIndeterminate: boolean;
  readonly terminationUnconfirmed: boolean;
  readonly at: number;
}
type AdoptionVia = "background" | "timeout";
interface JobRecord {
  readonly v: typeof JOB_RECORD_V;
  readonly jobId: string;
  /** The verified owner and root: from the carrier that reserved the run, never an argument. */
  readonly ownerSessionId: string;
  readonly rootSessionId: string;
  readonly label: string | null;
  /** The runner's key for the run: a repeated reserve with it finds this job, so a lost reply never makes a second record. */
  readonly runKey: string;
  /** Whether the run was reserved as a foreground one (it becomes a job only when adopted). */
  readonly foreground: boolean;
  readonly state: JobState;
  readonly adopted: {
    readonly via: AdoptionVia;
    readonly at: number;
  } | null;
  readonly pid: number | null;
  readonly pgid: number | null;
  readonly startIdentity: JobStartIdentity | null;
  /** Relative to `<state root>/shell/runs`: where M09's run folder holds the output. The Backend derives it; the caller never names a path. */
  readonly output: string | null;
  /** Per-owner byte offsets already returned, so a read returns only new output. */
  readonly cursors: Readonly<Record<string, JobCursor>>;
  /** `pending` until the completion notice went out; `inserted` after. A collected terminal state suppresses the notice (see `collectedAt`). */
  readonly completion: "pending" | "inserted";
  /** When an owner first saw the terminal state through a read or a wait. */
  readonly collectedAt: number | null;
  readonly exit: JobExitRecord | null;
  /** An exit observed after the job was already lost or killed: supplemental evidence, never a second notice. */
  readonly lateExit: JobExitRecord | null;
  readonly lost: JobLost | null;
  readonly createdAt: number;
  readonly updatedAt: number;
  readonly outbox: readonly OutboxEntry[];
  /**
   * Step 19a (terminal retention): when the Backend's sweep deleted this job's run folder. Absent or null until then. It is optional on read, so a record written before the sweep existed stays
   * valid; once set it never changes.
   */
  readonly outputRemoved?: number | null;
}
declare function newJobRecord(jobId: string, init: {
  readonly ownerSessionId: string;
  readonly rootSessionId: string;
  readonly runKey: string;
  readonly label: string | null;
  readonly foreground: boolean;
  readonly now: number;
  readonly output?: string | null;
}): JobRecord;
declare function validateJobRecord(input: unknown): Validated<JobRecord>;
//#endregion
//#region src/jobs/index.d.ts
declare const JOB_STATES: readonly ["starting", "running", "exited", "killed", "failed", "lost"];
declare const FINAL_JOB_STATES: readonly ["exited", "killed", "failed", "lost"];
/**
 * The order of the D22 lifecycle bridge for one run. Reserve comes before the spawn (a refused or unavailable reserve means the run is refused, never run
 * unrecorded); attach comes before the runner releases the gated command; adopted comes when the run becomes a job; exited carries the exit the runner observed.
 * The Backend never receives the runner's exit promise or callback.
 */
declare const JOB_LIFECYCLE_ORDER: readonly ["jobs.reserve", "jobs.attach", "jobs.adopted", "jobs.exited"];
//#endregion
//#region src/stores/format.d.ts
interface StoreFormat {
  readonly store: string;
  readonly formatVersion: number;
}
declare const ORCHESTRATION_STORE: StoreFormat;
declare const JOBS_STORE: StoreFormat;
/** The `v` every record carries. */
declare const RECORD_VERSION = 1;
/** Paths relative to the state root. Child files are named by a SHA-256 of the thread id (T3 thread ids are not path-safe); main files by a safe session id. */
declare const STORE_LAYOUT: Readonly<{
  orchestrationFormat: "orchestration/FORMAT";
  orchestrationChildren: "orchestration/children";
  orchestrationMain: "orchestration/main";
  jobsFormat: "jobs/FORMAT";
  jobsRoot: "jobs";
  jobRecord: "record.json";
}>;
//#endregion
//#region src/authority/explicit.d.ts
/** Tool names no explicit child ever holds: the workflow tool, the goal tools and the generic delegation tools (the role-spawn tools are told apart by the catalog). */
declare const EXPLICIT_EXCLUDED: readonly string[];
interface ExplicitRuleOptions {
  /** Whether a name is a role-spawn tool in the CURRENT role catalog. */
  readonly isRoleTool: (name: string) => boolean;
}
interface ExplicitDerivationInput {
  readonly record: {
    readonly explicitAllow?: readonly string[] | undefined;
  };
  readonly parent: {
    readonly callable: readonly string[];
    readonly maxDepth: number;
  };
}
type ExplicitDerivationResult = {
  readonly ok: true;
  readonly callable: readonly string[];
  readonly maxDepth: number;
  readonly background: string;
} | {
  readonly ok: false;
  readonly detail: string;
};
/** M03's injected port: `{ derive }` over the rule. `isRoleTool` is the catalog the caller already holds. */
declare function createExplicitAuthorityPort(options: ExplicitRuleOptions): {
  derive(input: ExplicitDerivationInput): ExplicitDerivationResult;
};
interface AllowProblem {
  readonly name: string;
  readonly why: string;
}
/**
 * Everything wrong with an allow-list given at spawn: not a list, empty, a repeated or malformed name, and every name a fork or explicit child may never hold. Empty means the list may be staged.
 * It is checked BEFORE staging, and the resolver and the rule each narrow it again, so a forged list can never gain anything.
 */
declare function explicitAllowProblems(allow: unknown, options: ExplicitRuleOptions): AllowProblem[];
//#endregion
//#region src/parameters.d.ts
type ParameterStatus = "carried, not accepted" | "proposed for gate";
interface Parameter {
  readonly value: number;
  readonly unit: string;
  readonly status: ParameterStatus;
  readonly source: string;
}
declare const PARAMETERS: Readonly<{
  maxParallelToolCalls: Parameter;
  maxActiveChildren: Parameter;
  maxResidentChildren: Parameter;
  maxConsecutiveWakes: Parameter;
  waitDefaultMs: Parameter;
  waitCapMs: Parameter;
  shortWaitLimitMs: Parameter;
  jobOutputRetention: Parameter;
  childStartDeadlineMs: Parameter;
  jobRetentionSweepMs: Parameter;
}>;
type ParameterName = keyof typeof PARAMETERS;
declare const PARAMETER_NAMES: ParameterName[];
declare function parameter<N extends ParameterName>(name: N): (typeof PARAMETERS)[N]["value"];
/** Problems with a record of values by name: every name present and nothing else, each a positive integer, and the two relations the caps rely on. */
declare function validateParameters(values: unknown): string[];
declare const PARAMETER_ACCEPTANCE = "unaccepted test values until the user's M12 gate";
interface ParameterSnapshot {
  readonly schema: 1;
  readonly accepted: false;
  readonly acceptance: typeof PARAMETER_ACCEPTANCE;
  readonly parameters: Readonly<Record<ParameterName, Parameter>>;
}
/** The record as a store keeps it: provenance and status travel with the values, and nothing says they were accepted. */
declare function parameterSnapshot(): ParameterSnapshot;
declare const decodeParameterSnapshot: (input: unknown) => Decoded<ParameterSnapshot>;
//#endregion
//#region src/stores/ports.d.ts
interface StoreFs {
  mkdirSync(path: string, options: {
    readonly recursive: true;
    readonly mode: number;
  }): unknown;
  /** Always called with `flag: "wx"`, so a write never replaces a file in place. */
  writeFileSync(path: string, data: string, options: {
    readonly flag: "wx";
    readonly mode: number;
  }): void;
  renameSync(from: string, to: string): void;
  readFileSync(path: string, encoding: "utf8"): string;
  readdirSync(path: string): string[];
  unlinkSync(path: string): void;
}
interface StoreDeps {
  readonly fs: StoreFs;
  sha256Hex(text: string): string;
}
type StoreFailureCode = "STORE_UNDECLARED" | "STORE_CORRUPT" | "STORE_NEWER" | "STORE_OLDER" | "STORE_FOREIGN" | "STORE_UNREADABLE" | "STORE_IO" | "STORE_WRITER_EXISTS" | "STORE_INVALID" | "STORE_BAD_NAME" | "STORE_CLOSED" | "STORE_ABSENT";
type WriteResult = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: StoreFailureCode;
  readonly reason: string;
};
/** `absent` means only ENOENT or ENOTDIR. Everything else that cannot yield a record is named, and is never treated as empty. */
type ReadResult<R> = {
  readonly status: "ok";
  readonly record: R;
} | {
  readonly status: "absent";
} | {
  readonly status: "corrupt" | "unsupported" | "unavailable";
  readonly detail: string;
};
//#endregion
//#region src/backend/node-ports.d.ts
declare function nodeStoreDeps(): StoreDeps;
//#endregion
//#region src/stores/files.d.ts
interface ListDiagnostic {
  readonly file: string;
  readonly status: "corrupt" | "unsupported" | "unavailable";
  readonly detail: string;
}
type ListResult<R> = {
  readonly ok: true;
  readonly records: R[];
  readonly diagnostics: ListDiagnostic[];
} | {
  readonly ok: false;
  readonly reason: string;
};
//#endregion
//#region src/stores/orchestration.d.ts
interface OrchestrationStore {
  readonly format: typeof ORCHESTRATION_STORE;
  readChild(threadId: string): ReadResult<ChildRecord>;
  writeChild(record: ChildRecord): WriteResult;
  /** Read-modify-write of an existing readable record. The thread id cannot change; a damaged record is never overwritten. */
  updateChild(threadId: string, change: (record: ChildRecord) => ChildRecord): WriteResult;
  /** Removing a record that is already absent is a success. */
  removeChild(threadId: string): WriteResult;
  listChildren(): ListResult<ChildRecord>;
  readMain(sessionId: string): ReadResult<MainRecord>;
  writeMain(record: MainRecord): WriteResult;
  updateMain(sessionId: string, change: (record: MainRecord) => MainRecord): WriteResult;
  /** Removes an already reconciled main-session record; removing an absent record is a success. */
  removeMain(sessionId: string): WriteResult;
  listMain(): ListResult<MainRecord>;
  /** Releases this root's writer slot. Writes after close are refused. */
  close(): void;
}
type OpenResult = {
  readonly ok: true;
  readonly store: OrchestrationStore;
} | {
  readonly ok: false;
  readonly code: StoreFailureCode;
  readonly reason: string;
};
declare function openOrchestrationStore(deps: StoreDeps, options: {
  readonly stateRoot: string;
}): OpenResult;
//#endregion
//#region src/stores/jobs.d.ts
interface JobsStore {
  readonly format: typeof JOBS_STORE;
  readJob(jobId: string): ReadResult<JobRecord>;
  writeJob(record: JobRecord): WriteResult;
  /** Read-modify-write of an existing readable record. The job id cannot change; a damaged record is never overwritten. */
  updateJob(jobId: string, change: (record: JobRecord) => JobRecord): WriteResult;
  /** Removing a record that is already absent is a success. Removes the record file; a leftover empty folder is not a job. */
  removeJob(jobId: string): WriteResult;
  listJobs(): ListResult<JobRecord>;
  close(): void;
}
type OpenJobsResult = {
  readonly ok: true;
  readonly store: JobsStore;
} | {
  readonly ok: false;
  readonly code: StoreFailureCode;
  readonly reason: string;
};
declare function openJobsStore(deps: StoreDeps, options: {
  readonly stateRoot: string;
}): OpenJobsResult;
//#endregion
//#region src/jobs/registry.d.ts
/** The session and root the carrier verified for the wire request. */
interface JobCaller {
  readonly sessionId: string;
  readonly rootSessionId: string;
}
type JobErrorCode = "JOB_INVALID" | "JOB_UNKNOWN" | "JOB_FOREIGN" | "JOB_CONFLICT" | "JOB_STALE" | "JOB_STORE_UNAVAILABLE";
type JobResult<Extra extends object = object> = ({
  readonly ok: true;
  readonly job: JobRecord; /** True when the fact was already recorded: nothing was written. */
  readonly replay: boolean;
} & Extra) | {
  readonly ok: false;
  readonly code: JobErrorCode;
  readonly detail: string;
};
interface AdoptionConfirmation {
  readonly jobId: string;
  readonly via: AdoptionVia;
  readonly at: number;
}
interface JobRegistryDeps {
  readonly store: JobsStore;
  readonly now: () => number;
  readonly newJobId: () => string;
}
interface ReserveRequest {
  readonly runKey: unknown;
  readonly label?: unknown;
  readonly foreground: unknown;
  readonly output?: unknown;
}
interface AttachRequest {
  readonly jobId: unknown;
  readonly runKey: unknown;
  readonly pid: unknown;
  readonly pgid: unknown;
  readonly startIdentity: unknown;
}
interface AdoptedRequest {
  readonly jobId: unknown;
  readonly runKey: unknown;
  readonly via: unknown;
}
interface ExitedRequest {
  readonly jobId: unknown;
  readonly runKey: unknown;
  readonly code: unknown;
  readonly signal: unknown;
}
type JobProcessOutcome = {
  readonly state: "killed";
  readonly at: number;
} | {
  readonly state: "lost";
  readonly at: number;
  readonly cause: string;
  readonly livenessIndeterminate: boolean;
  readonly terminationUnconfirmed: boolean;
};
interface JobRegistry {
  reserve(caller: JobCaller, request: ReserveRequest): JobResult;
  attach(caller: JobCaller, request: AttachRequest): JobResult;
  adopted(caller: JobCaller, request: AdoptedRequest): JobResult<{
    readonly confirmation: AdoptionConfirmation;
  }>;
  exited(caller: JobCaller, request: ExitedRequest): JobResult;
  /** The process-control boundary's committed result; observed exits and prior failures always win. */
  processOutcome(jobId: string, runKey: string, outcome: JobProcessOutcome): JobResult;
  get(jobId: string): {
    readonly status: "ok";
    readonly job: JobRecord;
  } | {
    readonly status: "absent";
  } | {
    readonly status: "unavailable";
    readonly detail: string;
  };
  /** Every readable job (unreadable ones are named, never skipped silently). */
  list(): {
    readonly ok: true;
    readonly jobs: readonly JobRecord[];
    readonly unreadable: number;
  } | {
    readonly ok: false;
    readonly detail: string;
  };
  /**
   * Step 17: the owner has seen the job's terminal state. Sets `collectedAt` once; a repeat changes nothing. Refused for a job that is not terminal, so a sighting of a running job
   * never suppresses a notice. The caller withdraws the uninserted notice under the outbox's own serialisation (jobs/output.ts).
   */
  collect(caller: JobCaller, jobId: string): JobResult;
  /**
   * Step 19a: the retention sweep deleted this job's run folder. The registry's one write for it, only for an adopted job that is terminal and collected; the first time stands and a repeat changes
   * nothing. The sweep is the caller (the Backend itself, not a session), so no owner is asked.
   */
  outputRemoved(jobId: string, at: number): JobResult;
  /** Step 17: moves one owner's read cursor forward (never back). Under the caller's per-job serialisation, so two reads cannot commit the same range. */
  commitCursor(caller: JobCaller, jobId: string, cursor: {
    readonly stdout: number;
    readonly stderr: number;
  }, options?: {
    readonly collect?: boolean;
  }): JobResult;
  /** Called after every committed transition with the record as written. A listener's failure never fails the transition. */
  onChange(listener: (job: JobRecord) => void): () => void;
}
declare function createJobRegistry(deps: JobRegistryDeps): JobRegistry;
//#endregion
//#region src/jobs/lifecycle.d.ts
type HostProbe = {
  readonly state: "live";
} | {
  readonly state: "empty";
} | {
  readonly state: "unknown";
  readonly code: string;
};
interface HostTerminationResult {
  readonly state: "confirmed-empty" | "not-empty" | "unknown";
  readonly signalsSent: readonly ("SIGTERM" | "SIGKILL")[];
  readonly detail: string;
}
interface HostProcessIdentity {
  readonly pid: number;
  readonly pgid: number;
  readonly startTime: string;
}
interface HostProcessPort {
  /** The process's start time as the host prints it, or null when it cannot be read. */
  startTime(pid: number): Promise<string | null>;
  probeGroup(pgid: number): HostProbe;
  /** Verify the recorded start identity and TERM/grace/KILL the group through M09; an absent method fails safe. */
  terminateGroup?(identity: HostProcessIdentity): Promise<HostTerminationResult>;
  /** The run folder and its two output files, as real files owned by this user. */
  inspectRun(runKey: string): Promise<{
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly reason: string;
  }>;
}
interface JobLifecycleDeps {
  readonly registry: JobRegistry;
  readonly host: HostProcessPort;
  readonly now?: (() => number) | undefined;
  /**
   * F1: the Backend's standing check (the child service's `callerRefusal`). A reserve starts new work, so a closed child's reserve is refused with `NOT_AUTHORIZED` before anything is written; a
   * check that throws is unavailable, never an allowance. Absent: no standing is checked (a harness without children).
   */
  readonly callerRefusal?: ((caller: JobCaller) => OrchestrationResult<never> | null) | undefined;
}
interface JobReconcileReport {
  readonly reconciled: readonly string[];
  readonly lostJobs: readonly JobRecord[];
  readonly unreadable: number;
  readonly problems: readonly string[];
}
interface JobLifecycle {
  reserve(caller: JobCaller, args: JobsReserveArgs): Promise<OrchestrationResult<JobsReserveValue>>;
  attach(caller: JobCaller, args: JobsAttachArgs): Promise<OrchestrationResult<JobsAttachValue>>;
  adopted(caller: JobCaller, args: JobsAdoptedArgs): Promise<OrchestrationResult<JobsAdoptedValue>>;
  exited(caller: JobCaller, args: JobsExitedArgs): Promise<OrchestrationResult<JobsExitedValue>>;
  /** Owner-scoped jobKill; only M09's identity-checked process-group primitive may send signals. */
  kill(caller: JobCaller, args: JobsKillArgs): Promise<OrchestrationResult<JobsKillValue>>;
  /** Backend boot: reconcile active records and retry groups whose prior termination was unconfirmed. */
  reconcileBoot(): Promise<JobReconcileReport>;
  /** Trusted close-child seam: kill every adopted job of the owner and name every job acted on. */
  killOwner(ownerSessionId: string): Promise<readonly string[]>;
}
/** M09's run id: the name of a run folder, which the Backend derives an output reference from. */
declare const RUN_KEY: RegExp;
/**
 * Who is owed a `job:<id>:lost` notice (Plan step 19): only a job that had a running command. A run that was reserved but never got a process identity (its attach was refused or it was stopped before
 * its release) never ran a command, so when its record becomes `lost` nothing is owed to the model; the record stays `lost` and visible in the list. The one rule for boot reconciliation and
 * for a kill's `lost` answer.
 */
declare const lostNoticeOwed: (job: {
  readonly pid: number | null;
}) => boolean;
declare function createJobLifecycle(deps: JobLifecycleDeps): JobLifecycle;
//#endregion
//#region ../aetheria-tools/src/shell/group.d.ts
interface TerminateOptions {
  /** Wait between TERM and KILL. */
  readonly graceMs: number;
  /** Wait after KILL for the group to be proved empty. */
  readonly boundMs: number;
  /** Interval between liveness probes. */
  readonly pollMs: number;
}
//#endregion
//#region src/outbox/outbox.d.ts
/** Whose record holds an entry. */
type OutboxOwner = {
  readonly kind: "job";
  readonly jobId: string;
} | {
  readonly kind: "child";
  readonly threadId: string;
} | {
  readonly kind: "main";
  readonly sessionId: string;
};
type OutboxStateAnswer = StoredOutboxState | "unknown";
type OutboxErrorCode = "OUTBOX_REFUSED" | "OUTBOX_OWNER_UNKNOWN" | "OUTBOX_UNAVAILABLE";
type EnqueueResult = {
  readonly ok: true;
  readonly created: boolean;
} | {
  readonly ok: false;
  readonly code: OutboxErrorCode;
  readonly detail: string;
};
/**
 * What a delivery call did, worst news last in the order below: `inserted` (at least one message went in and is marked), `unrecorded` (T3 accepted but the mark could not be written;
 * the receipt settles it next time), `uncertain` (the outcome is unknown), `unavailable` (a record could not be read or written, so nothing was sent), `held` (T3 or the owner could
 * not take it now), `nothing` (nothing was due).
 */
type DeliveryStatus = "inserted" | "unrecorded" | "uncertain" | "unavailable" | "held" | "nothing";
interface DeliveryResult {
  readonly status: DeliveryStatus;
  readonly mode?: "steer" | "queue" | undefined;
  readonly keys: readonly string[];
}
interface OutboxRow {
  readonly key: string;
  readonly kind: OutboxKind;
  readonly state: StoredOutboxState;
  readonly delivery: ReturnType<typeof deliveryView>;
  readonly attempts: number;
  readonly uncertainSince: number | null;
  readonly nextAttemptAt: number | null;
}
interface OutboxDeps {
  readonly orchestration: OrchestrationStore;
  /** Absent: a job owner is unknown. */
  readonly jobs?: JobsStore | undefined;
  readonly threads: Pick<ThreadPort, "status" | "startTurn"> & {
    readonly readMessageReceipt?: ThreadPort["readMessageReceipt"];
  };
  /** The T3 thread of a session; undefined while it has none (the entry waits). */
  readonly threadOfSession: (sessionId: string) => string | undefined;
  readonly now: () => number;
  readonly sha256Hex: (text: string) => string;
  /** True only when the inbox is known to turn a repeated message id into no second message (T3's command id derives from it); then an unsettled attempt is retried blind. */
  readonly dedupEstablished: boolean;
}
/**
 * What the wake bound (jobs/wakes.ts) asks of a delivery: only these kinds; `admit` is asked before a NEW attempt (never a retry of a batch already out) and false holds it;
 * `opened` is told once per confirmed insertion that opens a turn (`queue` into an idle owner).
 */
interface DeliveryGate {
  readonly kinds?: readonly OutboxKind[] | undefined;
  readonly admit?: (() => boolean) | undefined;
  readonly opened?: (() => void) | undefined;
}
interface Outbox {
  /**
   * Step 17: delivers EVERY owner's due entries for one session as coalesced batches: completions that are due together go out as one message under one frozen keyed id.
   * Serialised per target session, so two callers and a collection cannot interleave.
   */
  deliverSession(sessionId: string, gate?: DeliveryGate): Promise<DeliveryResult>;
  /**
   * Step 17: withdraws entries that have not been attempted (pending, no batch, no unknown outcome) to `abandoned`; one that is attempting, uncertain or final is left alone. Serialised
   * with delivery to the entry's target, so a withdrawal and an insertion cannot both happen. Returns the keys withdrawn.
   */
  withdraw(owner: OutboxOwner, keys: readonly string[]): Promise<readonly string[]>;
  /** Writes a pending entry in the owner's record, once per key. */
  enqueue(owner: OutboxOwner, spec: NewEntry): EnqueueResult;
  /** Records a stored-only report (a child's final report): `recorded`, never delivered. */
  recordOnly(owner: OutboxOwner, spec: {
    readonly key: string;
    readonly targetSessionId: string;
    readonly text: string;
  }): EnqueueResult;
  /** Delivers the owner's due entries (all of them, or the named keys), grouped by frozen batch. Serialised per owner. */
  deliver(owner: OutboxOwner, keys?: readonly string[]): Promise<DeliveryResult>;
  state(key: string): OutboxStateAnswer;
  rows(owner: OutboxOwner): readonly OutboxRow[];
  /** Boot: a volatile entry that is not final becomes `abandoned`. */
  reconcileBoot(): {
    readonly abandoned: readonly string[];
    readonly unreadable: readonly string[];
  };
}
declare function createOutbox(deps: OutboxDeps): Outbox;
//#endregion
//#region src/jobs/output.d.ts
interface JobOutputPort {
  size(output: string, stream: "stdout" | "stderr"): Promise<{
    readonly ok: true;
    readonly size: number;
  } | {
    readonly ok: false;
    readonly reason: string;
  }>;
  read(output: string, stream: "stdout" | "stderr", from: number, length: number): Promise<{
    readonly ok: true;
    readonly bytes: Uint8Array;
  } | {
    readonly ok: false;
    readonly reason: string;
  }>;
}
interface JobOutputDeps {
  readonly registry: JobRegistry;
  readonly port: JobOutputPort;
  /** Absent: a terminal sighting still sets `collectedAt`, and no notice is withdrawn. */
  readonly outbox?: Pick<Outbox, "withdraw"> | undefined;
  /** True when `owner` is a descendant of `ancestor` (M03's parent chain). */
  readonly isDescendant: (ancestor: string, owner: string) => boolean;
  readonly waitDefaultMs: () => number;
  readonly waitCapMs: () => number;
  /** The most bytes one read returns per stream. Default 64 KiB. */
  readonly maxChunkBytes?: number | undefined;
}
interface JobOutput {
  output(caller: JobCaller, args: JobsOutputArgs, signal?: AbortSignal): Promise<OrchestrationResult<JobsOutputValue>>;
  list(caller: JobCaller, args: JobsListArgs): Promise<OrchestrationResult<JobsListValue>>;
  cancel(caller: JobCaller, args: CancelWaitArgs): Promise<OrchestrationResult<AcceptedValue>>;
  /**
   * Step 19: the owner has seen a job's terminal state by another answer than a read (its own `jobs.kill` returned the final state). Sets `collectedAt` and withdraws an uninserted completion
   * notice, exactly as a read of the terminal state does; never throws, and does nothing for a running, lost or another session's job.
   */
  seen(caller: JobCaller, jobId: string): Promise<void>;
}
declare function createJobOutput(deps: JobOutputDeps): JobOutput;
//#endregion
//#region src/jobs/retention.d.ts
type RetentionRemoval = {
  readonly ok: true;
  readonly state: "removed" | "absent";
} | {
  readonly ok: false;
  readonly reason: string;
};
interface JobRetentionPort {
  /** Remove the run folder named by the job's output reference. `absent` means the folder is certainly not there (ENOENT or ENOTDIR); anything unclear is a refusal. */
  remove(output: string): Promise<RetentionRemoval>;
}
interface JobRetentionDeps {
  readonly registry: Pick<JobRegistry, "list" | "outputRemoved">;
  readonly port: JobRetentionPort;
  readonly now: () => number;
  /** The retention in milliseconds (`jobOutputRetention` days). */
  readonly retentionMs: () => number;
}
interface RetentionProblem {
  readonly jobId: string;
  readonly problem: string;
}
interface RetentionReport {
  readonly removed: readonly string[];
  readonly problems: readonly RetentionProblem[];
  /** Job records the registry could not read; they are never swept. */
  readonly unreadable: number;
}
interface JobRetention {
  sweep(): Promise<RetentionReport>;
}
/** When the job became terminal, as far as its record says; later updates only move a killed or failed job's time forward, which delays a removal and never hastens one. */
declare function terminalAt(job: JobRecord): number;
declare function createJobRetention(deps: JobRetentionDeps): JobRetention;
interface RetentionSweepsOptions {
  readonly retention: JobRetention;
  /** Milliseconds between the end of one sweep and the start of the next. An unaccepted test value (`jobRetentionSweepMs`). */
  readonly intervalMs: number;
  /** Test seam: schedule `fn` after `ms` and return its cancel. The default is an unref'd timer. */
  readonly schedule?: (fn: () => void | Promise<void>, ms: number) => () => void;
  readonly onError?: (error: unknown) => void;
  readonly onReport?: (report: RetentionReport) => void;
}
interface RetentionSweeps {
  /** Resolves when no sweep is running. */
  idle(): Promise<void>;
  /** Cancel the timer and wait for a sweep in flight; safe to repeat. */
  stop(): Promise<void>;
}
declare function startRetentionSweeps(options: RetentionSweepsOptions): RetentionSweeps;
//#endregion
//#region src/backend/host-process.d.ts
/**
 * Removes a swept job's run folder (step 19a). The reference is the run id the Backend derived at reserve. The folder must be a real directory (a link is refused, never followed), owned by this
 * user, and hold only plain files (M09 writes stdout, stderr and the ADOPTED marker): anything else is refused and nothing is deleted. The files are unlinked one by one and the folder then removed
 * with `rmdir`, never recursively, so a crash leaves either the folder or nothing, and a restart finds the folder absent. ENOENT and ENOTDIR are the only proof of absence.
 */
declare function nodeJobRetentionPort(options: {
  readonly stateRoot: string;
  readonly uid?: () => number | undefined;
}): JobRetentionPort;
/**
 * Reads a job's output files (step 17), read-only: the reference is the run id the Backend derived at reserve, the file is opened without following a link and must be a regular
 * file, and a short read or any error is reported as unreadable, never as empty.
 */
declare function nodeJobOutputPort(options: {
  readonly stateRoot: string;
}): JobOutputPort;
declare function nodeHostProcessPort(options: {
  readonly stateRoot: string;
  readonly terminationOptions?: TerminateOptions | undefined;
}): HostProcessPort;
//#endregion
//#region src/jobs/wakes.d.ts
interface JobWakesDeps {
  readonly outbox: Pick<Outbox, "deliverSession">;
  readonly wakeCap: () => number;
  readonly now: () => number;
  /** The coalescing delay: notices arriving within it share one message. */
  readonly coalesceMs: number;
  /** Runs `fn` after `ms` and returns a cancel. Default: a timer that does not keep the process alive. */
  readonly schedule?: ((fn: () => unknown, ms: number) => () => void) | undefined;
  /** M06's resume barrier for the session, finished before delivery; a rejection holds the delivery. */
  readonly beforeDeliver?: ((sessionId: string) => Promise<void>) | undefined;
  /** The id of the newest human-created message on the owner's thread (null: none). A change resets the count. */
  readonly humanMessageId?: ((sessionId: string) => Promise<string | null>) | undefined;
}
interface JobWakes {
  /** A completion notice was queued for this owner: deliver it (and any that arrive within the coalescing delay) once. */
  noticed(sessionId: string): void;
  /** Delivers this owner's due completions now. */
  flush(sessionId: string): Promise<DeliveryResult>;
  /** A direct human message reached the owner: reset the count and release what waited. */
  humanMessage(sessionId: string): Promise<DeliveryResult>;
  /** Consecutive completion-opened turns so far. */
  count(sessionId: string): number;
  /** Cancels every scheduled delivery and waits for the deliveries in flight (disposal). */
  drain(): Promise<void>;
}
declare function createJobWakes(deps: JobWakesDeps): JobWakes;
//#endregion
//#region src/stores/identity.d.ts
interface M03Result {
  readonly ok: boolean;
  readonly code?: string;
  readonly reason?: string;
}
interface M03Read {
  readonly status: string;
  readonly record?: unknown;
  readonly reason?: string;
  readonly problem?: string;
  readonly attemptId?: string;
}
interface M03Sweep {
  readonly removedPending: readonly string[];
  readonly problems: readonly string[];
}
/** The part of M03's IdentityStore this adapter uses (structural, so no import of the resources package is needed). */
interface M03IdentityStoreLike {
  stage(attemptId: string, record: unknown): M03Result;
  activate(attemptId: string, sessionId: string): M03Result;
  discard(attemptId: string): M03Result;
  retire(sessionId: string, reason: string): M03Result;
  noteAccepted(sessionId: string): M03Result;
  read(sessionId: string): M03Read;
  sweep(observer: {
    attempt(attemptId: string): {
      live: boolean | null;
    };
  } | undefined): M03Sweep;
}
type SweepPendingResult = {
  readonly ok: true;
  readonly removed: readonly string[];
  readonly problems: readonly string[];
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason: string;
};
interface ManagedIdentityWriter extends ChildIdentityWriter {
  /** Removes pending attempts nobody is starting. Use at boot only. */
  sweepPending(): SweepPendingResult;
}
declare function createChildIdentityWriter(store: M03IdentityStoreLike): ManagedIdentityWriter;
//#endregion
//#region ../aetheria-resources/src/identity/resolve.d.ts
type StoreRead = {
  status: 'absent';
} | {
  status: 'pending';
} | {
  status: 'active';
  record: unknown;
} | {
  status: 'retired';
  reason?: string;
} | {
  status: 'corrupt';
  problem: string;
};
//#endregion
//#region ../aetheria-resources/src/identity/store.d.ts
type StoreCode = 'AUTH_IDENTITY_INVALID' | 'AUTH_RETIRE_REFUSED' | 'STORE_BAD_NAME' | 'STORE_ATTEMPT_EXISTS' | 'STORE_NO_PENDING' | 'STORE_NO_RECORD' | 'STORE_SESSION_EXISTS' | 'STORE_SESSION_MISMATCH' | 'STORE_WRONG_WRITER' | 'STORE_CORRUPT' | 'STORE_UNSAFE_PATH' | 'STORE_RETIRED' | 'STORE_IO';
type StoreResult = {
  readonly ok: true;
  readonly cleanup?: 'pending-left';
} | {
  readonly ok: false;
  readonly code: StoreCode;
  readonly reason: string;
};
type FsPort = Pick<typeof nodeFs, 'mkdirSync' | 'writeFileSync' | 'chmodSync' | 'linkSync' | 'renameSync' | 'unlinkSync' | 'readdirSync' | 'lstatSync' | 'openSync' | 'fstatSync' | 'readFileSync' | 'closeSync'>;
interface LifecycleObservation {
  exists: boolean | null;
  closed: boolean | null;
  acceptedPrompt: boolean | null;
}
interface LifecycleObserver {
  /** Is the staged attempt still being started by a live process? `null` means unknown. */
  attempt?(attemptId: string): {
    live: boolean | null;
  };
  session?(sessionId: string): LifecycleObservation;
}
interface SweepReport {
  readonly removedPending: string[];
  readonly retired: string[];
  readonly retained: {
    id: string;
    why: string;
  }[];
  readonly problems: string[];
}
interface IdentityStore {
  stage(attemptId: string, record: unknown): StoreResult;
  activate(attemptId: string, sessionId: string): StoreResult;
  discard(attemptId: string): StoreResult;
  retire(sessionId: string, reason: string): StoreResult;
  /** M03-only exception: retire an unaccepted agent-host main identity with exact evidence from a rolled-back fork. */
  retireRolledBackMain(sessionId: string, evidence: unknown): StoreResult;
  /** Record that a prompt was accepted: from then on `retire` is refused. Operational metadata; the identity facts never change. */
  noteAccepted(sessionId: string): StoreResult;
  read(sessionId: string): StoreRead & {
    attemptId?: string;
  };
  sweep(observer: LifecycleObserver | undefined): SweepReport;
}
declare function createIdentityStore(options: {
  stateRoot: string;
  writer: string;
  fs?: Partial<FsPort>;
}): IdentityStore;
/** M03's narrow Backend call: the component executes as `agent-host`, and only a proved fork rollback may retire a main record. */
declare function retireRolledBackMain(input: {
  readonly stateRoot: string;
  readonly sessionId: string;
  readonly evidence: unknown;
}): StoreResult;
//#endregion
//#region src/children/fork.d.ts
interface ForkRequest {
  readonly caller: CallerContext;
  readonly args: ChildrenForkArgs;
  readonly signal?: AbortSignal | undefined;
}
//#endregion
//#region src/children/boot.d.ts
interface LineageThread {
  readonly threadId: string;
  readonly parentThreadId: string;
  readonly rootThreadId: string;
  readonly relationshipToParent: "subagent" | "fork";
  /** The Pi session M04's thread index bound to the thread; null when none is bound; "unknown" when the index could not be read. */
  readonly sessionId: string | null | "unknown";
  readonly closed: boolean;
}
interface LineageReaderPort {
  listChildThreads(): Promise<{
    readonly ok: true;
    readonly threads: readonly LineageThread[];
  } | {
    readonly ok: false;
    readonly reason: "unavailable";
  }>;
}
interface BootDeps {
  readonly threads: ThreadPort;
  readonly lineage: LineageReaderPort;
  readonly store: OrchestrationStore;
  readonly identity: ChildIdentityWriter & {
    sweepPending?(): SweepPendingResult;
  };
}
interface BootReport {
  readonly lineage: "ok" | "unavailable";
  /** Thread ids closed by this boot. */
  readonly closed: string[];
  /** Session ids retired through M03 by this boot. */
  readonly retired: string[];
  /** Thread ids whose release could not be confirmed; kept, marked used, never re-run. */
  readonly unconfirmed: string[];
  readonly unknown: {
    readonly threadId: string;
    readonly why: string;
  }[];
  /** Thread ids whose close failed; retried at the next boot. */
  readonly leftover: string[];
  readonly orphanRecords: string[];
  readonly sweptPending: string[];
  readonly problems: string[];
}
interface ForkRollbackReport {
  readonly lineage: "ok" | "unavailable";
  readonly retired: string[];
  readonly removed: string[];
  readonly unknown: {
    readonly threadId: string;
    readonly sessionId: string | null;
    readonly why: string;
  }[];
  readonly problems: string[];
}
interface ForkRollbackRetirer {
  retireRolledBackMain(input: {
    readonly stateRoot: string;
    readonly sessionId: string;
    readonly evidence: unknown;
  }): {
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: string;
    readonly reason: string;
  };
}
interface ForkRollbackBootDeps {
  readonly threads: ThreadPort;
  readonly lineage: LineageReaderPort;
  readonly store: Pick<OrchestrationStore, "listMain" | "updateMain" | "removeMain">;
  readonly stateRoot: string;
  readonly identityApi: ForkRollbackRetirer;
}
declare function reconcileChildren(deps: BootDeps): Promise<BootReport>;
/**
 * `m05-stray-main` (user route `m05-stray-main-route`): a rolled-back fork's Pi launch can leave the session the Agent host promoted to an unaccepted `main` identity. M05 may not retire
 * it (M03 refuses any writer but `agent-host`, and M05 never impersonates it), so this asks M03's one narrow API to, and only with evidence M05 holds: its own `fork-rolled-back`
 * tombstone in `orchestration/main`, T3's index binding that fork thread to the session, and the thread closed and idle. M03 checks the same evidence again against its own files.
 * Only after the identity is retired does M05 remove the stale `orchestration/main` records. An observation that cannot be made, or an M03 refusal, retains everything and is reported;
 * a repeat over settled state changes nothing, and a boot that died between the retire and the removal finishes the removal.
 */
declare function reconcileForkRollbacks(deps: ForkRollbackBootDeps): Promise<ForkRollbackReport>;
//#endregion
//#region src/children/control.d.ts
/** The carrier-verified caller of a control operation: its Pi session and the root session of its tree. Never an argument. */
interface ControlCaller {
  readonly sessionId: string;
  readonly rootSessionId: string;
}
/** The user's own act (the Stop and close controls): trusted module authority, never an argument. */
interface UserCaller {
  readonly user: true;
}
interface ChildControl {
  messageChild(request: {
    readonly caller: ControlCaller;
    readonly args: {
      readonly target: string;
      readonly content: string;
    };
  }): Promise<OrchestrationResult<ChildrenMessageValue>>;
  /**
   * A session lists its own subtree. The user (M10, for a root whose device it has already checked) names the root explicitly. `rootThreadId` is NOT part of the XC-6 wire shape, which stays
   * `{scope}`: it exists only on this direct call, and a session caller that carries one is refused.
   */
  listChildren(request: {
    readonly caller: ControlCaller | UserCaller;
    readonly args: {
      readonly scope: "children" | "descendants";
      readonly rootThreadId?: string | undefined;
    };
  }): Promise<OrchestrationResult<ChildrenListValue>>;
  /** An exact ancestor, or the user (cancelTree's own act; never XC-6 or model input). */
  interruptChild(request: {
    readonly caller: ControlCaller | UserCaller;
    readonly args: {
      readonly target: string;
    };
  }): Promise<OrchestrationResult<AcceptedValue>>;
  /** An exact ancestor (the carrier's caller) or the user (a direct Backend call from M10, never XC-6 or model input). */
  closeChild(request: {
    readonly caller: ControlCaller | UserCaller;
    readonly args: {
      readonly target: string;
    };
  }): Promise<OrchestrationResult<ChildrenCloseValue>>;
  /** XC-10: asked about a child's Pi session id by the root that wants to assign it work. */
  childStatus(request: {
    readonly rootSessionId: string;
    readonly childSessionId: string;
  }): Promise<OrchestrationResult<ChildrenStatusValue>>;
}
//#endregion
//#region src/children/reports.d.ts
interface ChildReports {
  awaitReport(request: {
    readonly caller: ControlCaller;
    readonly args: {
      readonly target: string;
      readonly requestId?: string | undefined;
    };
    readonly signal?: AbortSignal | undefined;
  }): Promise<OrchestrationResult<ChildReport>>;
  /** Ends the caller's own wait with that request id; an unknown or finished id, or another session's, is an accepted no-op. */
  cancelWait(request: {
    readonly caller: ControlCaller;
    readonly args: {
      readonly requestId: string;
    };
  }): Promise<OrchestrationResult<AcceptedValue>>;
  /** The service calls this after it recorded a settle for the child: record-only children get their report read and stored, and their waiters are answered. */
  settled(threadId: string): void;
  /**
   * The user's read of a child's stored report (M10's child views): direct call, never XC-6. The user names the root (already checked by the caller against the device), and the child must
   * sit under it. It never waits: a stored report, `pending` (the child has not settled) or `not-record-only`; what cannot be read is unavailable, and a settled child whose result was not
   * yet readable is read once more, now.
   */
  readReport(request: {
    readonly caller: unknown;
    readonly args: {
      readonly target: string;
      readonly rootThreadId?: string | undefined;
    };
  }): Promise<OrchestrationResult<UserReportValue>>;
}
type UserReportValue = {
  readonly state: "reported";
  readonly report: ChildReport;
} | {
  readonly state: "pending";
} | {
  readonly state: "not-record-only";
};
//#endregion
//#region src/children/cancel.d.ts
type CancelAction = "interrupted" | "closed" | "left-idle" | "left-closed" | "failed" | "unavailable";
interface CancelRow {
  readonly childId: string;
  readonly action: CancelAction;
  readonly detail?: string;
}
interface CancelTreeValue {
  readonly rootThreadId: string;
  readonly rows: readonly CancelRow[];
  /** Whether T3 confirmed the root's stop. */
  readonly rootStopped: boolean;
  /** True only when every child was handled and the root stopped. Never a claim that everything was cancelled otherwise. */
  readonly complete: boolean;
}
interface CancelTurnValue {
  readonly abortedSpawns: number;
  readonly closed: readonly string[];
  readonly failed: readonly {
    readonly childId: string;
    readonly detail: string;
  }[];
  readonly unavailable: readonly {
    readonly childId: string;
    readonly detail: string;
  }[];
}
interface ChildCancel {
  cancelTree(request: {
    readonly caller: unknown;
    readonly args: {
      readonly rootThreadId: string;
    };
  }): Promise<OrchestrationResult<CancelTreeValue>>;
  cancelParentTurn(request: {
    readonly caller: ControlCaller;
  }): Promise<OrchestrationResult<CancelTurnValue>>;
}
//#endregion
//#region src/children/classify.d.ts
/** What a settled-event subscriber hears: T3's status, except that an observed output-limit stop is `max-tokens`. */
type SettledOutcome = "completed" | "failed" | "interrupted" | "max-tokens";
//#endregion
//#region src/children/turns.d.ts
/** The authority a trusted module presents. It is a value the Backend hands to its own modules; nothing a session, a model or the user can produce is accepted. */
interface TrustedAuthority {
  readonly kind: "backend-module";
  readonly module: string;
}
type AdmitAnswer = {
  readonly status: "admitted";
  readonly messageId: string;
} | {
  readonly status: "refused";
  readonly reason: "busy" | "unauthorized" | "closed";
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
type InterruptAnswer = {
  readonly status: "accepted";
} | {
  readonly status: "refused";
  readonly reason: "unauthorized";
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
interface SettledEvent {
  readonly sessionId: string;
  readonly threadId: string;
  readonly runId: string;
  readonly settleSeq: number;
  readonly outcome: SettledOutcome;
  readonly cause: string | null;
}
type SettledScope = {
  readonly sessionId: string;
} | {
  readonly rootSessionId: string;
};
type SubscribeAnswer = {
  readonly status: "subscribed";
  unsubscribe(): void;
} | {
  readonly status: "refused";
  readonly reason: "unauthorized";
} | {
  readonly status: "unavailable";
  readonly detail: string;
};
interface Turns {
  admitTurn(request: {
    readonly authority: unknown;
    readonly sessionId: string;
    readonly origin: unknown;
    readonly content: string;
    readonly key: string;
  }): Promise<AdmitAnswer>;
  interruptTurn(request: {
    readonly authority: unknown;
    readonly sessionId: string;
  }): Promise<InterruptAnswer>;
  subscribeSettled(request: {
    readonly authority: unknown;
    readonly scope: SettledScope;
    readonly handler: (event: SettledEvent) => void;
  }): SubscribeAnswer;
  /** The service records a main session's settle here (children keep theirs in the route record) and every settle is announced. */
  recordMainSettle(event: {
    readonly threadId: string;
    readonly turnId: string;
    readonly outcome: TurnOutcome;
    readonly settledAt: string;
    readonly errorText: string | null;
    readonly stopReason: string | null;
  }): {
    readonly recorded: true;
    readonly settleSeq: number;
  } | {
    readonly recorded: false;
    readonly reason: string;
    readonly duplicate?: true;
    readonly settleSeq?: number;
  };
  announceChild(threadId: string, runId: string, settleSeq: number, status: TurnOutcome, cause: string | null): void;
}
//#endregion
//#region src/children/restart.d.ts
/** What the delivery seam is given: the immutable key makes a repeated delivery collide. */
interface RestartNotice {
  readonly key: string;
  readonly childThreadId: string;
  readonly parentThreadId: string;
  readonly text: string;
}
interface RestartOptions {
  /** Distinguishes this Backend boot; the Backend supplies it (its start time). */
  readonly bootEpoch: number;
  /** The outbox delivery seam (step 15). Absent: every notice stays pending, named in the report. */
  readonly notify?: ((notice: RestartNotice) => Promise<{
    readonly ok: boolean;
  }>) | undefined;
  /** Completes when M06's resume handling of the parent session has finished; a rejection holds the notice. */
  readonly afterResume?: ((parentSessionId: string) => Promise<void>) | undefined;
  /** How long boot waits for that chain per notice before it holds the notice for the next boot. Default 5000 ms (an unaccepted test value). */
  readonly resumeWaitMs?: number | undefined;
}
interface RestartReport {
  readonly lineage: "ok" | "unavailable";
  readonly settled: {
    readonly threadId: string;
    readonly outcome: string;
    readonly cause: string | null;
  }[];
  /** Children whose run the restart cut (settled now as interrupted / backend-restarted). */
  readonly interruptedByRestart: string[];
  readonly stillRunning: string[];
  readonly unknown: {
    readonly threadId: string;
    readonly why: string;
  }[];
  readonly notices: {
    readonly sent: string[];
    readonly byT3: string[];
    readonly pending: string[];
  };
}
//#endregion
//#region src/children/service.d.ts
/** Trusted T3 context of the calling session. It is never model input: the parent run and node come from here. */
interface CallerContext {
  readonly sessionId: string;
  readonly threadId: string;
  readonly runId: string;
  readonly nodeId: string;
  readonly workingFolder: string;
}
type AuthorizeSpawnResult = {
  readonly ok: true;
  readonly parent: {
    readonly sessionId: string;
    readonly rootSessionId: string;
    readonly parentChain: readonly string[];
  };
  /** The child's XC-1 facts as M03's authorize and the role catalog derive them. */
  readonly child: {
    readonly authoritySource: "role" | "spawn-explicit";
    readonly role: string | null;
    readonly roleOrigin: "checkout" | "home" | null;
    readonly roleDigest: string | null;
    readonly explicitAllow?: readonly string[];
  };
  /** The child's routes in order (route 1 first). */
  readonly routes: readonly RouteRef[];
  readonly runtimeMode: string;
  readonly interactionMode: string;
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason: string;
};
/** The M03 verdict, supplied by the Backend: resolve the caller's current resolver-issued identity, authorize the role or generic tool (role, depth, project layer). */
interface SpawnAuthorizer {
  authorize(input: {
    readonly callerSessionId: string;
    readonly workingFolder: string;
    readonly args: ChildrenSpawnArgs;
  }): Promise<AuthorizeSpawnResult> | AuthorizeSpawnResult;
  /**
   * Step 11: the verdict on a fork (the tool `subagent_fork`, at depth 0 only): the child is `spawn-explicit` and its `explicitAllow` may equal or narrow `allow`, never widen it. Absent
   * until the Backend supplies it: a fork is then unavailable.
   */
  authorizeFork?(input: {
    readonly callerSessionId: string;
    readonly workingFolder: string;
    readonly allow: readonly string[];
  }): Promise<AuthorizeSpawnResult> | AuthorizeSpawnResult;
}
type ServiceParameter = Extract<ParameterName, "maxActiveChildren" | "maxResidentChildren" | "childStartDeadlineMs" | "waitCapMs" | "shortWaitLimitMs">;
interface ChildServiceDeps {
  readonly threads: ThreadPort;
  readonly identity: ChildIdentityWriter;
  readonly planMode: PlanModeInheritPort;
  readonly store: OrchestrationStore;
  readonly clock: Clock;
  readonly authorizer: SpawnAuthorizer;
  /** M09's route availability for the launch route and for fallback (steps 21 and 22); null or absent means every route is unknown and nothing is classified. */
  readonly availability?: AvailabilityPort | null;
  /** Step 22: the timer of the one short wait, `(fn, ms) => cancel`. Default: an unref'd timeout. A test seam. */
  readonly schedule?: (fn: () => unknown, ms: number) => () => void;
  /** Test-only: read FX-AV-labelled availability answers. Never set in production, where such an answer is refused as unavailable. */
  readonly allowFixtureAvailability?: boolean;
  readonly newAttemptId: () => string;
  /** The Pi session id of a new child, chosen here and given to Pi (`--session-id`): a UUID shape Pi and M03 accept (alphanumerics, `-`, `_`, `.`; at most 128). */
  readonly newSessionId: () => string;
  /** Control operations (step 10). M04's thread index as translation only: the Pi session a thread holds and the thread a session is bound to; undefined when unknown or ambiguous. */
  readonly sessionOfThread: (threadId: string) => string | undefined;
  readonly threadOfSession: (sessionId: string) => string | undefined;
  /** T3's child lineage, as boot reads it: unavailable is never an empty list. */
  readonly lineage: LineageReaderPort;
  /** A fresh id for each message a control operation sends; T3 derives its command id from it, so a repeated id is a replay. */
  readonly newMessageId: () => string;
  /** Delays (ms) between a record-only child's report read at the settle and its retries; absent uses the default. A test seam. */
  readonly reportRetryDelaysMs?: readonly number[];
  /** Step 11: a fresh T3 thread id for a fork's copy. Absent: forking is unavailable. */
  readonly newThreadId?: () => string;
  /** Overrides of the unaccepted test parameters; absent names use the parameter record. */
  readonly parameters?: Partial<Record<ServiceParameter, number>>;
  /** Step 15: the job store, so the outbox can hold a job's entries. Absent: a job owner is unknown to the outbox. */
  readonly jobs?: JobsStore;
  /** Step 15: the hash that derives an outbox message id from its keys. Absent: there is no outbox (a restart notice stays pending, as before). */
  readonly sha256Hex?: (text: string) => string;
  /** Step 15: true only when the inbox is known to turn a repeated message id into no second message; then an unsettled attempt is retried blind. Default false. */
  readonly inboxDedupEstablished?: boolean;
  /** Step 18's seam: kills the jobs a closed child adopted and returns their ids. Absent until jobs exist. */
  readonly killJobs?: (childSessionId: string) => Promise<readonly string[]>;
}
type CurrentRoute = {
  readonly kind: "none";
} | {
  readonly kind: "route";
  readonly index: number;
  readonly route: {
    readonly provider: string;
    readonly model: string;
    readonly effort?: string;
  };
  readonly role: string;
  readonly switches: number;
} | {
  readonly kind: "unknown";
  readonly detail: string;
};
interface SpawnRequest {
  readonly caller: CallerContext;
  readonly args: ChildrenSpawnArgs;
  readonly signal?: AbortSignal | undefined;
}
type SettleOutcome = {
  readonly recorded: true;
  readonly settleSeq: number;
} | {
  readonly recorded: false;
  readonly reason: string;
  readonly duplicate?: true;
  readonly settleSeq?: number;
};
interface RunUpdate {
  readonly threadId?: unknown;
  readonly runId?: unknown;
  readonly status?: unknown;
  readonly completedAt?: unknown;
  readonly errorText?: unknown;
}
interface ChildService extends ChildControl, Omit<ChildReports, "settled">, ChildCancel, Pick<Turns, "admitTurn" | "interruptTurn" | "subscribeSettled"> {
  spawnChild(request: SpawnRequest): Promise<OrchestrationResult<ChildrenSpawnValue>>;
  /** Step 11: a native fork registered as an owned, continuable child with a narrowed explicit authority (children/fork.ts). */
  forkChild(request: ForkRequest): Promise<OrchestrationResult<ChildrenForkValue>>;
  /** Settles from a raw terminal `run.updated`: the status goes through the step 4 mapping, so `waiting` and every unknown status record nothing. */
  handleRunUpdated(run: RunUpdate): SettleOutcome;
  handleTurnCompleted(event: TurnCompletedEvent): SettleOutcome;
  /** Records the cause of an effect BEFORE it is requested, so a later settle can name it. Only the contract's causes are accepted. */
  recordRequest(threadId: string, kind: RequestKind, cause: string): {
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: string;
    readonly reason: string;
  };
  /** Settles every child under a root from T3's terminal runs. */
  watch(rootThreadId: string): {
    unsubscribe(): void;
  };
  /** Step 13: after a restart, brings each accepted child's settle record up to date from T3's newest run and tells the parent once (children/restart.ts). */
  reconcileRestarts(options: RestartOptions): Promise<RestartReport>;
  /**
   * Step 23: the route a role child's NEXT turn runs on, from its persisted route state, by the trusted thread id. `none`: no record or no stored routes (a spawn-explicit child, a fork, a
   * single-route role, a thread M05 does not know), so nothing is overridden. `unknown`: the record cannot be read, which is a visible failure for the caller, never a silent default.
   * Synchronous, read-only and never throws: the Pi selection seam is synchronous.
   */
  currentRoute(threadId: string): CurrentRoute;
  /**
   * F1: null when the session may start new work; `NOT_AUTHORIZED` when it is a closed child, `ORCHESTRATION_UNAVAILABLE` when its route record cannot be read. A session with no child route record
   * (a main session, or one with no bound thread) is unaffected. The job lifecycle asks this before it reserves a run. Synchronous, read-only, never throws.
   */
  callerRefusal(sessionId: string): OrchestrationResult<never> | null;
  /** Step 22: resolves when no route-fallback decision is in progress (a wait that has not elapsed is not). */
  routeIdle(): Promise<void>;
  /** Step 22: a cancel intent was recorded for this child, so its short wait, if any, ends now. The record already says so; this only ends the timer. */
  cancelRouteWork(threadId: string): void;
  /** Step 15: the outbox (C4) over this service's records and the job store; undefined without a hash. */
  readonly outbox: Outbox | undefined;
  /**
   * Step 15: the restart-notice delivery seam, filled: the notice is an outbox entry of the child under child:<id>:restart:<bootEpoch>, delivered to the parent once, repeat-safe.
   * Pass it as `notify` to `reconcileRestarts`. Not ok while the outcome is unknown or the parent cannot take it; the entry then waits and the next boot settles it.
   */
  restartNotify(notice: RestartNotice): Promise<{
    readonly ok: boolean;
  }>;
  /** Step 15: boot drops every volatile outbox entry that never became final. */
  reconcileOutbox(): {
    readonly abandoned: readonly string[];
    readonly unreadable: readonly string[];
  };
}
declare const REQUEST_CAUSES: Readonly<Record<RequestKind, readonly string[]>>;
declare function createChildService(deps: ChildServiceDeps): ChildService;
//#endregion
//#region src/backend/index.d.ts
declare const MANAGED_WORK_BACKEND_ENTRY: "aetheria:orchestration-backend";
//#endregion
export { type AcceptedValue, type AdmitAnswer, type AdoptedRequest, type AdoptionConfirmation, type AdoptionVia, type AllowProblem, type AttachRequest, type AuthorizeSpawnResult, type AvailabilityPort, BACKEND_DIRECT_CALLS, type BackendDirectCall, type BootDeps, type BootReport, CHILDREN_OPERATIONS, CHILD_PHASES, CHILD_WRITER, COMPLETION_WAKES, type CallerContext, type CancelAction, type CancelRow, type CancelTreeValue, type CancelTurnValue, type CancelWaitArgs, type ChildCancel, type ChildControl, type ChildDiagnostic, type ChildIdentityWriter, type ChildMode, type ChildPhase, type ChildRecord, type ChildReport, type ChildRoute, type ChildRow, type ChildService, type ChildServiceDeps, type ChildSettle, type ChildState, type ChildrenAwaitReportArgs, type ChildrenCancelArgs, type ChildrenCloseArgs, type ChildrenCloseValue, type ChildrenForkArgs, type ChildrenForkValue, type ChildrenInterruptArgs, type ChildrenListArgs, type ChildrenListValue, type ChildrenMessageArgs, type ChildrenMessageValue, type ChildrenSpawnArgs, type ChildrenSpawnValue, type ChildrenStatusArgs, type ChildrenStatusValue, type ChildrenTargetArgs, type Clock, type CompletionWake, type ControlCaller, type CreateChildThreadInput, type CurrentRoute, type Decoded, type DelegatedCompletionState, type DeliveryGate, type DeliveryResult, type DeliveryStatus, EXPLICIT_EXCLUDED, type EnqueueResult, type ExitedRequest, type ExplicitDerivationInput, type ExplicitDerivationResult, type ExplicitRuleOptions, FINAL_JOB_STATES, FINAL_OUTBOX_STATES, type FinalJobState, type ForkRollbackBootDeps, type ForkRollbackReport, type ForkRollbackRetirer, type HostProbe, type HostProcessIdentity, type HostProcessPort, type HostTerminationResult, type IdentityStoreRead, type IdentityStoreResult, type InterruptAnswer, JOBS_OPERATIONS, JOBS_STORE, JOB_LIFECYCLE_OPERATIONS, JOB_LIFECYCLE_ORDER, JOB_RECORD_V, JOB_STATES, type JobCaller, type JobCursor, type JobErrorCode, type JobExit, type JobExitRecord, type JobFlags, type JobLifecycle, type JobLifecycleDeps, type JobLost, type JobOutput, type JobOutputDeps, type JobOutputPort, type JobReconcileReport, type JobRecord, type JobRegistry, type JobRegistryDeps, type JobResult, type JobRetention, type JobRetentionDeps, type JobRetentionPort, type JobRow, type JobStartIdentity, type JobState, type JobWakes, type JobWakesDeps, type JobsAdoptedArgs, type JobsAdoptedValue, type JobsAttachArgs, type JobsAttachValue, type JobsCancelArgs, type JobsExitedArgs, type JobsExitedValue, type JobsKillArgs, type JobsKillValue, type JobsListArgs, type JobsListValue, type JobsOutputArgs, type JobsOutputValue, type JobsReserveArgs, type JobsReserveValue, type JobsStore, type LineageReaderPort, type LineageThread, type ListDiagnostic, type ListResult, type M03IdentityStoreLike, M03_AUTHORIZE_CODES, MANAGED_WORK_BACKEND_ENTRY, MANAGED_WORK_PACKAGE, MAX_CURSOR_OWNERS, MAX_ENTRY_TEXT, MAX_OUTBOX_ENTRIES, type MainRecord, type ManagedIdentityWriter, type ModelSelection, type NewEntry, ORCHESTRATION_CODES, ORCHESTRATION_CODE_CLASSES, ORCHESTRATION_OPERATIONS, ORCHESTRATION_STORE, ORDINARY_CHILD_COMPLETION_WAKE, OUTBOX_KINDS, OUTBOX_STATES, type OpenJobsResult, type OpenResult, type OrchestrationCode, type OrchestrationCodeClass, type OrchestrationCodecName, type OrchestrationFailure, type OrchestrationOperation, type OrchestrationResult, type OrchestrationStore, type Outbox, type OutboxDeps, type OutboxEntry, type OutboxErrorCode, type OutboxKind, type OutboxOwner, type OutboxRow, type OutboxState, type OutboxStateAnswer, type Outcome, type OutputChunk, PARAMETERS, PARAMETER_ACCEPTANCE, PARAMETER_NAMES, type Parameter, type ParameterName, type ParameterSnapshot, type ParameterStatus, type PendingRequest, type PlanModeInheritPort, type PortResult, type ProcessGroupPort, type ProcessStartIdentity, RECORD_VERSION, REQUEST_CAUSES, RUN_KEY, type ReadResult, type RequestKind, type ReserveRequest, type RestartNote, type RestartNotice, type RestartOptions, type RestartReport, type ResumeBarrierPort, type RetentionProblem, type RetentionRemoval, type RetentionReport, type RetentionSweeps, type RetentionSweepsOptions, type RouteAvailability, type RouteRef, type RunUpdate, SAFE_JOB_ID, SAFE_OUTPUT_REF, STORED_OUTBOX_STATES, STORE_LAYOUT, type SettleOutcome, type SettleStatus, type SettledEvent, type SettledOutcome, type SettledScope, type SpawnAuthorizer, type SpawnRequest, type StoreDeps, type StoreFailureCode, type StoreFormat, type StoreFs, type StoredOutboxState, type SubscribeAnswer, type SweepPendingResult, THREAD_PORT_CALLS, type ThreadLineage, type ThreadPort, type ThreadPortCall, type ThreadStatus, type TrustedAuthority, type TurnCompletedEvent, type TurnOutcome, type Turns, type UserCaller, type UserReportValue, type WriteResult, type Xc6ReplyKind, createChildIdentityWriter, createChildService, createExplicitAuthorityPort, createIdentityStore, createJobLifecycle, createJobOutput, createJobRegistry, createJobRetention, createJobWakes, createOutbox, decodeParameterSnapshot, deliveryView, explicitAllowProblems, isChildCompletionKey, jobCompletionKey, jobLostKey, lostNoticeOwed, mapRunStatus, newChildRecord, newJobRecord, newPendingEntry, nodeHostProcessPort, nodeJobOutputPort, nodeJobRetentionPort, nodeStoreDeps, openJobsStore, openOrchestrationStore, orchestrationCodecs, outboxEntryProblem, outboxProblem, outcomeOfCode, parameter, parameterSnapshot, reconcileChildren, reconcileForkRollbacks, restartNoticeKey, retireRolledBackMain, routeNoticeKey, startRetentionSweeps, terminalAt, validateChildRecord, validateJobRecord, validateMainRecord, validateParameters, withEntry, xc6ReplyKindOf };