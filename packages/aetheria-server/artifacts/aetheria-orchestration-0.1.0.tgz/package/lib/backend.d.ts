import * as nodeFs from "node:fs";
//#region src/identity.d.ts
declare const MANAGED_WORK_PACKAGE: "@aetheria/orchestration";
//#endregion
//#region src/operations/names.d.ts
declare const CHILDREN_OPERATIONS: readonly ["children.spawn", "children.fork", "children.message", "children.list", "children.interrupt", "children.close", "children.await-report", "children.status", "children.cancel"];
declare const JOBS_OPERATIONS: readonly ["jobs.output", "jobs.list", "jobs.kill", "jobs.cancel"];
declare const JOB_LIFECYCLE_OPERATIONS: readonly ["jobs.reserve", "jobs.attach", "jobs.adopted", "jobs.exited"];
declare const ORCHESTRATION_OPERATIONS: readonly ["children.spawn", "children.fork", "children.message", "children.list", "children.interrupt", "children.close", "children.await-report", "children.status", "children.cancel", "jobs.output", "jobs.list", "jobs.kill", "jobs.cancel", "jobs.reserve", "jobs.attach", "jobs.adopted", "jobs.exited"];
type OrchestrationOperation = (typeof ORCHESTRATION_OPERATIONS)[number];
/**
 * Calls that exist only between trusted Backend modules (D17, D20). They are never XC-6 operations and no tool can reach them: the caller must be a Backend
 * module, so none has a wire name and none appears in ORCHESTRATION_OPERATIONS.
 */
declare const BACKEND_DIRECT_CALLS: readonly ["admitTurn", "interruptTurn", "subscribeSettled", "cancelTree"];
type BackendDirectCall = (typeof BACKEND_DIRECT_CALLS)[number];
//#endregion
//#region src/operations/codes.d.ts
/** Every design C1 code except `AUTH_*` (M03's), plus the four this contract adds: JOB_CONFLICT, JOB_IDENTITY_MISMATCH, ORCHESTRATION_UNAVAILABLE and ABORTED. */
declare const ORCHESTRATION_CODE_CLASSES: {
  readonly CHILD_LIMIT: "refusal";
  readonly CHILD_NOT_OWNED: "refusal";
  readonly CHILD_NOT_ADJACENT: "refusal";
  readonly CHILD_NOT_RESUMABLE: "refusal";
  readonly NOT_AUTHORIZED: "refusal";
  readonly JOB_IDENTITY_MISMATCH: "refusal";
  readonly JOB_CONFLICT: "conflict";
  readonly JOB_NOT_FOUND: "absence";
  readonly CHILD_START_FAILED: "failure";
  readonly FORK_FAILED: "failure";
  readonly FORK_PARTIAL: "failure";
  readonly CHILD_DELIVERY_UNAVAILABLE: "unavailable";
  readonly CHILD_PARENT_UNAVAILABLE: "unavailable";
  readonly ORCHESTRATION_UNAVAILABLE: "unavailable";
  readonly ABORTED: "aborted";
};
type OrchestrationCode = keyof typeof ORCHESTRATION_CODE_CLASSES;
type OrchestrationCodeClass = (typeof ORCHESTRATION_CODE_CLASSES)[OrchestrationCode];
declare const ORCHESTRATION_CODES: OrchestrationCode[];
/** What M03's `authorize` and the identity store can answer for a spawn or fork; these arrive as the XC-6 `refused` reply, never inside `done`. */
declare const M03_AUTHORIZE_CODES: readonly ["ROLE_PROJECT_LAYER", "ROLE_GENERIC_DELEGATION", "AUTH_TOOL_NOT_ALLOWED", "AUTH_DEPTH_EXCEEDED", "AUTH_IDENTITY_UNAVAILABLE", "AUTH_ROLE_REMOVED", "AUTH_IDENTITY_INVALID"];
type Outcome = "refused" | "failed" | "unavailable" | "aborted";
/** The distinct outcome a code renders as; an unknown code is a programming error, never a default. */
declare function outcomeOfCode(code: string): Outcome;
type Xc6ReplyKind = "done" | "refused" | "unavailable";
/** Which XC-6 reply carries a code (see the header). */
declare function xc6ReplyKindOf(code: string): Xc6ReplyKind;
//#endregion
//#region src/operations/types.d.ts
type ChildMode = "one-shot" | "continuable";
type ChildState = "running" | "idle" | "closed" | "unknown";
type JobState = "starting" | "running" | "exited" | "killed" | "failed" | "lost";
type FinalJobState = "exited" | "killed" | "failed" | "lost";
type SettleStatus = "completed" | "failed" | "interrupted";
/** Exactly one of an exit code or a terminating signal, as the runner observed it. */
interface JobExit {
  readonly code: number | null;
  readonly signal: string | null;
}
interface JobFlags {
  readonly livenessIndeterminate?: true;
  readonly terminationUnconfirmed?: true;
}
interface ChildReport {
  readonly status: SettleStatus;
  readonly cause?: string;
  readonly text: string;
  readonly structured?: unknown;
  /** The route the child ended on, 1-based. */
  readonly route: number;
}
/** Exactly one of `role` and `allow`. `delivery: "record-only"` is for a one-shot child only. */
type ChildrenSpawnArgs = ({
  readonly role: string;
} | {
  readonly allow: readonly string[];
}) & {
  readonly prompt: string;
  readonly mode: ChildMode;
  readonly label?: string;
  readonly outputSchema?: Readonly<Record<string, unknown>>;
  readonly delivery?: "record-only";
};
interface ChildrenSpawnValue {
  readonly childId: string;
  readonly messageId: string;
  readonly route: number;
  readonly allRoutesOut: boolean;
}
interface ChildrenForkArgs {
  readonly prefix: "all" | {
    readonly runId: string;
  };
  readonly prompt: string;
  /** The fork child's explicit allow-list: a subset of the parent's callable tools minus every delegation, workflow and goal tool. */
  readonly allow: readonly string[];
  readonly label?: string;
  readonly reuseForkSessionId?: string;
}
interface ChildrenForkValue {
  readonly childId: string;
}
interface ChildrenMessageArgs {
  readonly target: string;
  readonly content: string;
}
interface ChildrenMessageValue {
  readonly messageId: string;
}
interface ChildrenListArgs {
  readonly scope: "children" | "descendants";
}
interface ChildRow {
  readonly childId: string;
  readonly parentId: string;
  readonly depth: number;
  readonly role: string | null;
  readonly mode: ChildMode;
  readonly label?: string;
  readonly state: ChildState;
  readonly lastOutcome: {
    readonly status: SettleStatus;
    readonly cause?: string;
  } | null;
  readonly route: number | null;
}
interface ChildDiagnostic {
  readonly kind: "corrupt" | "unsupported" | "unavailable" | "unregistered-fork";
  readonly id: string;
  readonly detail?: string;
}
interface ChildrenListValue {
  readonly rows: readonly ChildRow[];
  readonly diagnostics: readonly ChildDiagnostic[];
}
interface ChildrenTargetArgs {
  readonly target: string;
}
type ChildrenInterruptArgs = ChildrenTargetArgs;
type ChildrenCloseArgs = ChildrenTargetArgs;
interface AcceptedValue {
  readonly accepted: true;
}
interface ChildrenCloseValue {
  readonly closed: true;
  readonly report?: ChildReport;
  readonly killedJobs: readonly string[];
}
interface ChildrenAwaitReportArgs {
  readonly target: string;
  readonly requestId?: string;
}
/** The XC-10 session id of the child, never a thread id; the root comes from the caller's identity. */
interface ChildrenStatusArgs {
  readonly childSessionId: string;
}
interface ChildrenStatusValue {
  readonly owned: boolean | "unknown";
  readonly state: ChildState;
}
interface CancelWaitArgs {
  readonly requestId: string;
}
type ChildrenCancelArgs = CancelWaitArgs;
type JobsCancelArgs = CancelWaitArgs;
interface JobsOutputArgs {
  readonly jobId: string;
  readonly wait?: boolean;
  readonly timeoutMs?: number;
  readonly requestId?: string;
}
interface OutputChunk {
  readonly stream: "stdout" | "stderr";
  readonly from: number;
  readonly to: number;
  readonly text: string;
  readonly truncated: boolean;
}
type JobsOutputValue = JobFlags & {
  readonly jobId: string;
  readonly state: JobState;
  readonly streams: readonly OutputChunk[];
  readonly exit?: JobExit;
  readonly waitElapsed: boolean;
};
interface JobsListArgs {
  readonly scope?: "own" | "descendants";
}
type JobRow = JobFlags & {
  readonly jobId: string;
  readonly ownerSessionId: string;
  readonly label: string;
  readonly state: JobState;
  readonly completion: "pending" | "inserted" | "none";
  readonly collectedAt?: string;
  readonly deliveryUncertain?: true;
  readonly exit?: JobExit;
};
interface JobsListValue {
  readonly jobs: readonly JobRow[];
}
interface JobsKillArgs {
  readonly jobId: string;
}
type JobsKillValue = JobFlags & {
  readonly jobId: string;
  readonly state: FinalJobState;
  readonly exit?: JobExit;
};
/** Before the spawn. The output location is derived by the Backend from the run key; the Agent never chooses a path. */
interface JobsReserveArgs {
  readonly runKey: string;
  readonly label: string;
  readonly mode: "background" | "foreground";
}
interface JobsReserveValue {
  readonly jobId: string;
  readonly state: "starting";
}
/** Before the runner releases the gated command. An unreadable start time is not representable. */
interface JobsAttachArgs {
  readonly jobId: string;
  readonly pid: number;
  readonly pgid: number;
  readonly startIdentity: {
    readonly pid: number;
    readonly startTime: string;
  };
}
interface JobsAttachValue {
  readonly jobId: string;
  readonly attached: true;
}
interface JobsAdoptedArgs {
  readonly jobId: string;
  readonly via: "background" | "timeout";
}
/** The confirmation exists only after the adoption is persisted. */
interface JobsAdoptedValue {
  readonly jobId: string;
  readonly confirmation: string;
}
interface JobsExitedArgs {
  readonly jobId: string;
  readonly exit: JobExit;
}
interface JobsExitedValue {
  readonly jobId: string;
  readonly recorded: true;
  readonly supplemental: boolean;
}
/** A failed result. `CHILD_START_FAILED`, `FORK_FAILED` and `FORK_PARTIAL` carry data; every other code carries only an optional detail. */
type OrchestrationFailure = {
  readonly ok: false;
  readonly code: "CHILD_START_FAILED";
  readonly cause?: string;
  readonly leftoverThreadId?: string;
  readonly detail?: string;
} | {
  readonly ok: false;
  readonly code: "FORK_FAILED";
  readonly cause?: string;
  readonly detail?: string;
} | {
  readonly ok: false;
  readonly code: "FORK_PARTIAL";
  readonly forkSessionId: string;
  readonly registered: false;
  readonly step: 2 | 3;
  readonly leftoverThreadId?: string;
  readonly detail?: string;
} | {
  readonly ok: false;
  readonly code: Exclude<string, "CHILD_START_FAILED" | "FORK_FAILED" | "FORK_PARTIAL">;
  readonly detail?: string;
};
type OrchestrationResult<V> = {
  readonly ok: true;
  readonly value: V;
} | OrchestrationFailure;
//#endregion
//#region src/operations/strict.d.ts
type Decoded<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly reason: string;
};
//#endregion
//#region src/operations/codecs.d.ts
/** One decoder per vector set, keyed by the same names the vectors use. */
declare const orchestrationCodecs: {
  readonly childrenSpawnArgs: (input: unknown) => Decoded<ChildrenSpawnArgs>;
  readonly childrenSpawnResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenSpawnValue>>;
  readonly childrenForkArgs: (input: unknown) => Decoded<ChildrenForkArgs>;
  readonly childrenForkResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenForkValue>>;
  readonly childrenMessageArgs: (input: unknown) => Decoded<ChildrenMessageArgs>;
  readonly childrenMessageResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenMessageValue>>;
  readonly childrenListArgs: (input: unknown) => Decoded<ChildrenListArgs>;
  readonly childrenListResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenListValue>>;
  readonly childrenInterruptArgs: (input: unknown) => Decoded<ChildrenTargetArgs>;
  readonly childrenInterruptResult: (input: unknown) => Decoded<OrchestrationResult<AcceptedValue>>;
  readonly childrenCloseArgs: (input: unknown) => Decoded<ChildrenTargetArgs>;
  readonly childrenCloseResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenCloseValue>>;
  readonly childrenAwaitReportArgs: (input: unknown) => Decoded<ChildrenAwaitReportArgs>;
  readonly childrenAwaitReportResult: (input: unknown) => Decoded<OrchestrationResult<ChildReport>>;
  readonly childrenStatusArgs: (input: unknown) => Decoded<ChildrenStatusArgs>;
  readonly childrenStatusResult: (input: unknown) => Decoded<OrchestrationResult<ChildrenStatusValue>>;
  readonly childrenCancelArgs: (input: unknown) => Decoded<CancelWaitArgs>;
  readonly childrenCancelResult: (input: unknown) => Decoded<OrchestrationResult<AcceptedValue>>;
  readonly jobsOutputArgs: (input: unknown) => Decoded<JobsOutputArgs>;
  readonly jobsOutputResult: (input: unknown) => Decoded<OrchestrationResult<JobsOutputValue>>;
  readonly jobsListArgs: (input: unknown) => Decoded<JobsListArgs>;
  readonly jobsListResult: (input: unknown) => Decoded<OrchestrationResult<JobsListValue>>;
  readonly jobsKillArgs: (input: unknown) => Decoded<JobsKillArgs>;
  readonly jobsKillResult: (input: unknown) => Decoded<OrchestrationResult<JobsKillValue>>;
  readonly jobsCancelArgs: (input: unknown) => Decoded<CancelWaitArgs>;
  readonly jobsCancelResult: (input: unknown) => Decoded<OrchestrationResult<AcceptedValue>>;
  readonly jobsReserveArgs: (input: unknown) => Decoded<JobsReserveArgs>;
  readonly jobsReserveResult: (input: unknown) => Decoded<OrchestrationResult<JobsReserveValue>>;
  readonly jobsAttachArgs: (input: unknown) => Decoded<JobsAttachArgs>;
  readonly jobsAttachResult: (input: unknown) => Decoded<OrchestrationResult<JobsAttachValue>>;
  readonly jobsAdoptedArgs: (input: unknown) => Decoded<JobsAdoptedArgs>;
  readonly jobsAdoptedResult: (input: unknown) => Decoded<OrchestrationResult<JobsAdoptedValue>>;
  readonly jobsExitedArgs: (input: unknown) => Decoded<JobsExitedArgs>;
  readonly jobsExitedResult: (input: unknown) => Decoded<OrchestrationResult<JobsExitedValue>>;
};
type OrchestrationCodecName = keyof typeof orchestrationCodecs;
//#endregion
//#region src/children/ports.d.ts
type PortResult<V, R extends string> = ({
  readonly ok: true;
} & V) | {
  readonly ok: false;
  readonly reason: R;
  readonly detail?: string;
};
declare const THREAD_PORT_CALLS: readonly ["createChildThread", "bindChildSession", "releaseFirstTurn", "forkThread", "startTurn", "interrupt", "status", "subscribeTurnCompleted", "readDelegatedCompletion", "readRestartNotes", "close"];
type ThreadPortCall = (typeof THREAD_PORT_CALLS)[number];
/** T3's `completionWake` for a delegated task. Under `settled_only` a completion that arrives while the parent's run is live is never delivered. */
declare const COMPLETION_WAKES: readonly ["always", "settled_only"];
type CompletionWake = (typeof COMPLETION_WAKES)[number];
/** Decision (b): `spawnChild` sets `always` for an ordinary child, so a completion reaches a busy or idle parent exactly once. A `record-only` child is settled apart. */
declare const ORDINARY_CHILD_COMPLETION_WAKE: CompletionWake;
interface ModelSelection {
  readonly provider: string;
  readonly model: string;
  readonly effort?: string | undefined;
}
interface ThreadLineage {
  readonly parentThreadId: string;
  readonly rootThreadId: string;
  readonly relationshipToParent: "subagent" | "fork";
}
interface CreateChildThreadInput {
  /** Derived from the spawn attempt id, so a repeated create is the same command. */
  readonly commandId: string;
  readonly parentThreadId: string;
  /** The parent's active run and node, taken from trusted T3 context, never from model arguments. */
  readonly parentRunId: string;
  readonly parentNodeId: string;
  readonly task: string;
  readonly title?: string | undefined;
  readonly modelSelection: ModelSelection;
  readonly runtimeMode: string;
  readonly interactionMode: string;
  /**
   * The held child's working folder, passed explicitly: T3 gives a held (root-strategy) child null branch and worktree, so nothing may be inferred from the
   * thread. An absolute path of the parent's project.
   */
  readonly workingFolder: string;
  readonly completionWake: CompletionWake;
}
interface ThreadStatus {
  readonly activity: "running" | "idle" | "unknown";
  readonly queued: number | "unknown";
  readonly resident: boolean | "unknown";
  readonly settleSeqHint?: number | undefined;
}
type TurnOutcome = "completed" | "failed" | "interrupted";
interface TurnCompletedEvent {
  readonly threadId: string;
  /** The run id. */
  readonly turnId: string;
  readonly outcome: TurnOutcome;
  readonly settledAt: string;
  /** Redacted, from the run's error item. */
  readonly errorText?: string | undefined;
}
type DelegatedCompletionState = "pending" | "claimed" | "acknowledged" | "delivered" | "disposed";
interface RestartNote {
  readonly kind: string;
  readonly label: string;
  readonly id?: string | undefined;
  readonly awaited?: boolean | undefined;
}
interface ThreadPort {
  /** Records the child thread and its task with the first turn held (T3 `delegated_task.request` with `workspaceStrategy {type:"root"}`); no turn starts. */
  createChildThread(input: CreateChildThreadInput): Promise<PortResult<{
    readonly threadId: string;
    readonly lineage: ThreadLineage;
    readonly heldMessageId: string;
  }, "parent-unavailable" | "create-failed">>;
  /**
   * R1 route: opens the child's provider session, calls ensure-thread on the held row and persists that session before release, so the real Pi session id exists
   * with no provider request. Idempotent: a repeat returns the same session id and never makes a second one. Never starts a turn.
   */
  bindChildSession(input: {
    readonly threadId: string;
    readonly heldMessageId: string;
  }): Promise<PortResult<{
    readonly piSessionId: string;
  }, "parent-unavailable" | "session-unavailable" | "bind-failed">>;
  /**
   * Derives T3's command id from the held message id and reads the run state before mapping T3's refusal of an already-released or unknown run to accepted:
   * a repeat is accepted only when the run is truly past its hold. Releasing is the only call that can start the first turn.
   */
  releaseFirstTurn(input: {
    readonly threadId: string;
    readonly heldMessageId: string;
  }): Promise<PortResult<{
    readonly accepted: true;
  }, "delivery-unavailable">>;
  forkThread(input: {
    readonly parentThreadId: string;
    readonly sourcePoint: "latest_stable" | {
      readonly run: string;
    };
    readonly targetThreadId: string;
  }): Promise<PortResult<{
    readonly threadId: string;
    readonly forkSessionId: string;
  }, "fork-failed" | "prefix-unsupported">>;
  /** The adapter derives T3's command id from the message id, so a repeated message id counts as accepted. */
  startTurn(input: {
    readonly threadId: string;
    readonly content: string;
    readonly delivery: "queue" | "steer";
    readonly messageId: string;
  }): Promise<PortResult<{
    readonly accepted: true;
    readonly messageId: string;
  }, "not-resumable" | "delivery-unavailable">>;
  /** An absent target is an accepted no-op. */
  interrupt(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly accepted: true;
  }, "unavailable">>;
  status(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly status: ThreadStatus;
  }, "unavailable">>;
  /** Terminal `run.updated` events mapped by run id; a non-terminal status, including `waiting`, is ignored. */
  subscribeTurnCompleted(scope: {
    readonly threadId: string;
  } | {
    readonly rootThreadId: string;
  }, handler: (event: TurnCompletedEvent) => void): {
    unsubscribe(): void;
  };
  readDelegatedCompletion(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly state: DelegatedCompletionState;
    readonly generation?: number | undefined;
    readonly messageId?: string | undefined;
  }, "unavailable">>;
  readRestartNotes(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly notes: readonly RestartNote[];
  }, "unavailable">>;
  /** T3 `thread.stop` with `stopDelegatedTasks: false`, never `thread.delete`. A not-found error is treated as closed. */
  close(input: {
    readonly threadId: string;
  }): Promise<PortResult<{
    readonly closed: true;
  }, "unavailable">>;
}
/** The writer name M05 uses with M03's identity store; the main session's records stay `agent-host`. */
declare const CHILD_WRITER = "managed-work";
type IdentityStoreResult = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason: string;
};
type IdentityStoreRead = {
  readonly state: "active" | "pending" | "retired" | "absent" | "corrupt" | "unavailable";
  readonly [key: string]: unknown;
};
/** M03's store API as M05 uses it, keyed by the child's Pi session id. The envelopes are never written by hand and a retired id is never reactivated. */
interface ChildIdentityWriter {
  stage(attemptId: string, record: unknown): IdentityStoreResult;
  activate(attemptId: string, sessionId: string): IdentityStoreResult;
  discard(attemptId: string): IdentityStoreResult;
  retire(sessionId: string, reason: string): IdentityStoreResult;
  /** From then on `retire` is refused: an accepted child cannot be rolled back. */
  noteAccepted(sessionId: string): IdentityStoreResult;
  read(sessionId: string): IdentityStoreRead;
}
/** M06's `inheritPlanMode`, a direct Backend call that needs the child already in the session tree (so it runs after activation). */
interface PlanModeInheritPort {
  inheritPlanMode(parentSessionId: string, childSessionId: string, kind: "spawn" | "fork"): Promise<{
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: "INTERACTION_UNAVAILABLE";
  }>;
}
/** Completes once M06's own resume handling (`reconcileWaits`, then redeliver) has finished for a session; M05 makes no second reconcile call. */
interface ResumeBarrierPort {
  resumed(sessionId: string): Promise<void>;
}
interface Clock {
  now(): number;
}
type RouteAvailability = "available" | "out" | "unknown";
interface RouteRef {
  readonly provider: string;
  readonly model: string;
  readonly effort?: string | undefined;
}
/** M09's XC-11 availability service as the fallback policy uses it; `unavailable` makes every route unknown, never out. */
interface AvailabilityPort {
  routeStates(input: {
    readonly routes: readonly RouteRef[];
    readonly purpose: "launch" | "switch";
  }): Promise<{
    readonly ok: true;
    readonly states: readonly RouteAvailability[];
  } | {
    readonly ok: false;
    readonly reason: "unavailable";
  }>;
  reportFailure(input: {
    readonly route: RouteRef;
    readonly errorText: string;
  }): Promise<{
    readonly ok: true;
    readonly class: "limit" | "sign-in" | "struggling" | "other";
    readonly resetHintMs?: number | undefined;
  } | {
    readonly ok: false;
    readonly reason: "unavailable";
  }>;
}
interface ProcessStartIdentity {
  readonly pid: number;
  readonly startTime: string;
}
/** M09's process-group primitives as the job registry uses them. An unreadable start identity or unknown liveness is `unknown`, never gone. */
interface ProcessGroupPort {
  readStartIdentity(pid: number): Promise<ProcessStartIdentity | null>;
  probe(target: {
    readonly pgid: number;
    readonly startIdentity: ProcessStartIdentity;
  }): Promise<{
    readonly state: "alive" | "empty" | "unknown";
  }>;
  terminate(target: {
    readonly pgid: number;
    readonly startIdentity: ProcessStartIdentity;
  }, options: {
    readonly graceMs: number;
  }): Promise<{
    readonly state: "confirmed-empty" | "not-empty" | "unknown" | "no-process";
    readonly signalsSent: readonly ("SIGTERM" | "SIGKILL")[];
  }>;
}
//#endregion
//#region src/children/settle.d.ts
/** The settle outcome of a run status, or null when the status is not terminal or not recognised. */
declare function mapRunStatus(status: unknown): TurnOutcome | null;
//#endregion
//#region src/jobs/index.d.ts
declare const JOB_STATES: readonly ["starting", "running", "exited", "killed", "failed", "lost"];
declare const FINAL_JOB_STATES: readonly ["exited", "killed", "failed", "lost"];
/**
 * The order of the D22 lifecycle bridge for one run. Reserve comes before the spawn (a refused or unavailable reserve means the run is refused, never run
 * unrecorded); attach comes before the runner releases the gated command; adopted comes when the run becomes a job; exited carries the exit the runner observed.
 * The Backend never receives the runner's exit promise or callback.
 */
declare const JOB_LIFECYCLE_ORDER: readonly ["jobs.reserve", "jobs.attach", "jobs.adopted", "jobs.exited"];
//#endregion
//#region src/outbox/keys.d.ts
declare const OUTBOX_STATES: readonly ["pending", "attempting", "inserted", "recorded", "abandoned", "unknown"];
type OutboxState = (typeof OUTBOX_STATES)[number];
declare const OUTBOX_KINDS: readonly ["job-completion", "route-notice", "goal-round", "goal-notice", "child-report"];
type OutboxKind = (typeof OUTBOX_KINDS)[number];
/** The restart notice M05 sends when T3 wrote none (decision d): once per child per Backend boot. T3 thread ids hold colons, so the key is read from its ends. */
declare const restartNoticeKey: (childId: unknown, bootEpoch: unknown) => string;
/** The lost-job notice (D9). */
declare const jobLostKey: (jobId: unknown) => string;
/** A job's completion notice (D8). */
declare const jobCompletionKey: (jobId: unknown) => string;
/** The route notice of one switch (D12: child plus switch number). */
declare const routeNoticeKey: (childId: unknown, switchNumber: unknown) => string;
//#endregion
//#region src/stores/format.d.ts
interface StoreFormat {
  readonly store: string;
  readonly formatVersion: number;
}
declare const ORCHESTRATION_STORE: StoreFormat;
declare const JOBS_STORE: StoreFormat;
/** The `v` every record carries. */
declare const RECORD_VERSION = 1;
/** Paths relative to the state root. Child files are named by a SHA-256 of the thread id (T3 thread ids are not path-safe); main files by a safe session id. */
declare const STORE_LAYOUT: Readonly<{
  orchestrationFormat: "orchestration/FORMAT";
  orchestrationChildren: "orchestration/children";
  orchestrationMain: "orchestration/main";
  jobsFormat: "jobs/FORMAT";
  jobsRoot: "jobs";
  jobRecord: "record.json";
}>;
//#endregion
//#region src/parameters.d.ts
type ParameterStatus = "carried, not accepted" | "proposed for gate";
interface Parameter {
  readonly value: number;
  readonly unit: string;
  readonly status: ParameterStatus;
  readonly source: string;
}
declare const PARAMETERS: Readonly<{
  maxParallelToolCalls: Parameter;
  maxActiveChildren: Parameter;
  maxResidentChildren: Parameter;
  maxConsecutiveWakes: Parameter;
  waitDefaultMs: Parameter;
  waitCapMs: Parameter;
  shortWaitLimitMs: Parameter;
  jobOutputRetention: Parameter;
  childStartDeadlineMs: Parameter;
}>;
type ParameterName = keyof typeof PARAMETERS;
declare const PARAMETER_NAMES: ParameterName[];
declare function parameter<N extends ParameterName>(name: N): (typeof PARAMETERS)[N]["value"];
/** Problems with a record of values by name: every name present and nothing else, each a positive integer, and the two relations the caps rely on. */
declare function validateParameters(values: unknown): string[];
declare const PARAMETER_ACCEPTANCE = "unaccepted test values until the user's M12 gate";
interface ParameterSnapshot {
  readonly schema: 1;
  readonly accepted: false;
  readonly acceptance: typeof PARAMETER_ACCEPTANCE;
  readonly parameters: Readonly<Record<ParameterName, Parameter>>;
}
/** The record as a store keeps it: provenance and status travel with the values, and nothing says they were accepted. */
declare function parameterSnapshot(): ParameterSnapshot;
declare const decodeParameterSnapshot: (input: unknown) => Decoded<ParameterSnapshot>;
//#endregion
//#region src/stores/ports.d.ts
interface StoreFs {
  mkdirSync(path: string, options: {
    readonly recursive: true;
    readonly mode: number;
  }): unknown;
  /** Always called with `flag: "wx"`, so a write never replaces a file in place. */
  writeFileSync(path: string, data: string, options: {
    readonly flag: "wx";
    readonly mode: number;
  }): void;
  renameSync(from: string, to: string): void;
  readFileSync(path: string, encoding: "utf8"): string;
  readdirSync(path: string): string[];
  unlinkSync(path: string): void;
}
interface StoreDeps {
  readonly fs: StoreFs;
  sha256Hex(text: string): string;
}
type StoreFailureCode = "STORE_UNDECLARED" | "STORE_CORRUPT" | "STORE_NEWER" | "STORE_OLDER" | "STORE_FOREIGN" | "STORE_UNREADABLE" | "STORE_IO" | "STORE_WRITER_EXISTS" | "STORE_INVALID" | "STORE_BAD_NAME" | "STORE_CLOSED" | "STORE_ABSENT";
type WriteResult = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: StoreFailureCode;
  readonly reason: string;
};
/** `absent` means only ENOENT or ENOTDIR. Everything else that cannot yield a record is named, and is never treated as empty. */
type ReadResult<R> = {
  readonly status: "ok";
  readonly record: R;
} | {
  readonly status: "absent";
} | {
  readonly status: "corrupt" | "unsupported" | "unavailable";
  readonly detail: string;
};
//#endregion
//#region src/backend/node-ports.d.ts
declare function nodeStoreDeps(): StoreDeps;
//#endregion
//#region src/stores/records.d.ts
declare const RECORD_V: 1;
/** How far a spawn got. `activated`: identity active, first turn not released. `releasing`: written before the release is asked for. `accepted`: the inbox took the prompt. */
type ChildPhase = "activated" | "releasing" | "accepted";
declare const CHILD_PHASES: readonly ChildPhase[];
interface ChildRoute {
  /** 1-based. */
  readonly index: number;
  readonly failed: readonly number[];
  readonly switches: number;
  readonly allRoutesOut: boolean;
}
interface ChildSettle {
  readonly settleSeq: number;
  readonly lastTurnId: string | null;
  /** The most recent run ids seen, so a replayed or reordered event is recognised; bounded. */
  readonly seenTurnIds: readonly string[];
  readonly settledAt: string | null;
  readonly status: SettleStatus | null;
  readonly cause: string | null;
  readonly errorText: string | null;
  readonly route: number | null;
}
type RequestKind = "interrupt" | "close" | "cancel";
interface PendingRequest {
  readonly kind: RequestKind;
  readonly cause: string;
  readonly at: number;
}
interface ChildRecord {
  readonly v: typeof RECORD_V;
  readonly threadId: string;
  /** The root session id admission counts this child under. */
  readonly admissionRoot: string;
  readonly phase: ChildPhase;
  readonly route: ChildRoute;
  readonly closed: boolean;
  readonly closedCause: string | null;
  readonly delivery: "ordinary" | "record-only";
  readonly settle: ChildSettle;
  readonly pendingRequest: PendingRequest | null;
  /** Outbox entries (C4) live in the owner's record; step 15 defines and validates them. */
  readonly outbox: readonly unknown[];
  readonly diagnostic: string | null;
}
interface MainSettle {
  readonly settleSeq: number;
  readonly lastTurnId: string | null;
  readonly status: SettleStatus | null;
  readonly cause: string | null;
}
interface MainRecord {
  readonly v: typeof RECORD_V;
  readonly sessionId: string;
  readonly settle: MainSettle;
  readonly outbox: readonly unknown[];
}
declare function newChildRecord(threadId: string, init: {
  readonly admissionRoot: string;
  readonly delivery?: "ordinary" | "record-only";
  readonly route?: Partial<ChildRoute>;
  readonly phase?: ChildPhase;
}): ChildRecord;
type Validated<R> = {
  readonly ok: true;
  readonly record: R;
} | {
  readonly ok: false;
  readonly unsupported: boolean;
  readonly problem: string;
};
declare function validateChildRecord(input: unknown): Validated<ChildRecord>;
declare function validateMainRecord(input: unknown): Validated<MainRecord>;
//#endregion
//#region src/stores/orchestration.d.ts
interface ListDiagnostic {
  readonly file: string;
  readonly status: "corrupt" | "unsupported" | "unavailable";
  readonly detail: string;
}
type ListResult<R> = {
  readonly ok: true;
  readonly records: R[];
  readonly diagnostics: ListDiagnostic[];
} | {
  readonly ok: false;
  readonly reason: string;
};
interface OrchestrationStore {
  readonly format: typeof ORCHESTRATION_STORE;
  readChild(threadId: string): ReadResult<ChildRecord>;
  writeChild(record: ChildRecord): WriteResult;
  /** Read-modify-write of an existing readable record. The thread id cannot change; a damaged record is never overwritten. */
  updateChild(threadId: string, change: (record: ChildRecord) => ChildRecord): WriteResult;
  /** Removing a record that is already absent is a success. */
  removeChild(threadId: string): WriteResult;
  listChildren(): ListResult<ChildRecord>;
  readMain(sessionId: string): ReadResult<MainRecord>;
  writeMain(record: MainRecord): WriteResult;
  updateMain(sessionId: string, change: (record: MainRecord) => MainRecord): WriteResult;
  listMain(): ListResult<MainRecord>;
  /** Releases this root's writer slot. Writes after close are refused. */
  close(): void;
}
type OpenResult = {
  readonly ok: true;
  readonly store: OrchestrationStore;
} | {
  readonly ok: false;
  readonly code: StoreFailureCode;
  readonly reason: string;
};
declare function openOrchestrationStore(deps: StoreDeps, options: {
  readonly stateRoot: string;
}): OpenResult;
//#endregion
//#region src/stores/identity.d.ts
interface M03Result {
  readonly ok: boolean;
  readonly code?: string;
  readonly reason?: string;
}
interface M03Read {
  readonly status: string;
  readonly record?: unknown;
  readonly reason?: string;
  readonly problem?: string;
  readonly attemptId?: string;
}
interface M03Sweep {
  readonly removedPending: readonly string[];
  readonly problems: readonly string[];
}
/** The part of M03's IdentityStore this adapter uses (structural, so no import of the resources package is needed). */
interface M03IdentityStoreLike {
  stage(attemptId: string, record: unknown): M03Result;
  activate(attemptId: string, sessionId: string): M03Result;
  discard(attemptId: string): M03Result;
  retire(sessionId: string, reason: string): M03Result;
  noteAccepted(sessionId: string): M03Result;
  read(sessionId: string): M03Read;
  sweep(observer: {
    attempt(attemptId: string): {
      live: boolean | null;
    };
  } | undefined): M03Sweep;
}
type SweepPendingResult = {
  readonly ok: true;
  readonly removed: readonly string[];
  readonly problems: readonly string[];
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason: string;
};
interface ManagedIdentityWriter extends ChildIdentityWriter {
  /** Removes pending attempts nobody is starting. Use at boot only. */
  sweepPending(): SweepPendingResult;
}
declare function createChildIdentityWriter(store: M03IdentityStoreLike): ManagedIdentityWriter;
//#endregion
//#region ../aetheria-resources/src/identity/resolve.d.ts
type StoreRead = {
  status: 'absent';
} | {
  status: 'pending';
} | {
  status: 'active';
  record: unknown;
} | {
  status: 'retired';
  reason?: string;
} | {
  status: 'corrupt';
  problem: string;
};
//#endregion
//#region ../aetheria-resources/src/identity/store.d.ts
type StoreCode = 'AUTH_IDENTITY_INVALID' | 'AUTH_RETIRE_REFUSED' | 'STORE_BAD_NAME' | 'STORE_ATTEMPT_EXISTS' | 'STORE_NO_PENDING' | 'STORE_NO_RECORD' | 'STORE_SESSION_EXISTS' | 'STORE_SESSION_MISMATCH' | 'STORE_WRONG_WRITER' | 'STORE_CORRUPT' | 'STORE_UNSAFE_PATH' | 'STORE_RETIRED' | 'STORE_IO';
type StoreResult = {
  readonly ok: true;
  readonly cleanup?: 'pending-left';
} | {
  readonly ok: false;
  readonly code: StoreCode;
  readonly reason: string;
};
type FsPort = Pick<typeof nodeFs, 'mkdirSync' | 'writeFileSync' | 'chmodSync' | 'linkSync' | 'renameSync' | 'unlinkSync' | 'readdirSync' | 'lstatSync' | 'openSync' | 'fstatSync' | 'readFileSync' | 'closeSync'>;
interface LifecycleObservation {
  exists: boolean | null;
  closed: boolean | null;
  acceptedPrompt: boolean | null;
}
interface LifecycleObserver {
  /** Is the staged attempt still being started by a live process? `null` means unknown. */
  attempt?(attemptId: string): {
    live: boolean | null;
  };
  session?(sessionId: string): LifecycleObservation;
}
interface SweepReport {
  readonly removedPending: string[];
  readonly retired: string[];
  readonly retained: {
    id: string;
    why: string;
  }[];
  readonly problems: string[];
}
interface IdentityStore {
  stage(attemptId: string, record: unknown): StoreResult;
  activate(attemptId: string, sessionId: string): StoreResult;
  discard(attemptId: string): StoreResult;
  retire(sessionId: string, reason: string): StoreResult;
  /** Record that a prompt was accepted: from then on `retire` is refused. Operational metadata; the identity facts never change. */
  noteAccepted(sessionId: string): StoreResult;
  read(sessionId: string): StoreRead & {
    attemptId?: string;
  };
  sweep(observer: LifecycleObserver | undefined): SweepReport;
}
declare function createIdentityStore(options: {
  stateRoot: string;
  writer: string;
  fs?: Partial<FsPort>;
}): IdentityStore;
//#endregion
//#region src/children/service.d.ts
/** Trusted T3 context of the calling session. It is never model input: the parent run and node come from here. */
interface CallerContext {
  readonly sessionId: string;
  readonly threadId: string;
  readonly runId: string;
  readonly nodeId: string;
  readonly workingFolder: string;
}
type AuthorizeSpawnResult = {
  readonly ok: true;
  readonly parent: {
    readonly sessionId: string;
    readonly rootSessionId: string;
    readonly parentChain: readonly string[];
  };
  /** The child's XC-1 facts as M03's authorize and the role catalog derive them. */
  readonly child: {
    readonly authoritySource: "role" | "spawn-explicit";
    readonly role: string | null;
    readonly roleOrigin: "checkout" | "home" | null;
    readonly roleDigest: string | null;
    readonly explicitAllow?: readonly string[];
  };
  /** The child's routes in order (route 1 first). */
  readonly routes: readonly RouteRef[];
  readonly runtimeMode: string;
  readonly interactionMode: string;
} | {
  readonly ok: false;
  readonly code: string;
  readonly reason: string;
};
/** The M03 verdict, supplied by the Backend: resolve the caller's current resolver-issued identity, authorize the role or generic tool (role, depth, project layer). */
interface SpawnAuthorizer {
  authorize(input: {
    readonly callerSessionId: string;
    readonly workingFolder: string;
    readonly args: ChildrenSpawnArgs;
  }): Promise<AuthorizeSpawnResult> | AuthorizeSpawnResult;
}
type ServiceParameter = Extract<ParameterName, "maxActiveChildren" | "maxResidentChildren" | "childStartDeadlineMs">;
interface ChildServiceDeps {
  readonly threads: ThreadPort;
  readonly identity: ChildIdentityWriter;
  readonly planMode: PlanModeInheritPort;
  readonly store: OrchestrationStore;
  readonly clock: Clock;
  readonly authorizer: SpawnAuthorizer;
  /** M09's XC-11 service for the launch route; null or absent means every route is unknown. */
  readonly availability?: AvailabilityPort | null;
  readonly newAttemptId: () => string;
  /** Overrides of the unaccepted test parameters; absent names use the parameter record. */
  readonly parameters?: Partial<Record<ServiceParameter, number>>;
}
interface SpawnRequest {
  readonly caller: CallerContext;
  readonly args: ChildrenSpawnArgs;
  readonly signal?: AbortSignal | undefined;
}
type SettleOutcome = {
  readonly recorded: true;
  readonly settleSeq: number;
} | {
  readonly recorded: false;
  readonly reason: string;
  readonly duplicate?: true;
  readonly settleSeq?: number;
};
interface RunUpdate {
  readonly threadId?: unknown;
  readonly runId?: unknown;
  readonly status?: unknown;
  readonly completedAt?: unknown;
  readonly errorText?: unknown;
}
interface ChildService {
  spawnChild(request: SpawnRequest): Promise<OrchestrationResult<ChildrenSpawnValue>>;
  /** Settles from a raw terminal `run.updated`: the status goes through the step 4 mapping, so `waiting` and every unknown status record nothing. */
  handleRunUpdated(run: RunUpdate): SettleOutcome;
  handleTurnCompleted(event: TurnCompletedEvent): SettleOutcome;
  /** Records the cause of an effect BEFORE it is requested, so a later settle can name it. Only the contract's causes are accepted. */
  recordRequest(threadId: string, kind: RequestKind, cause: string): {
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: string;
    readonly reason: string;
  };
  /** Settles every child under a root from T3's terminal runs. */
  watch(rootThreadId: string): {
    unsubscribe(): void;
  };
}
declare const REQUEST_CAUSES: Readonly<Record<RequestKind, readonly string[]>>;
declare function createChildService(deps: ChildServiceDeps): ChildService;
//#endregion
//#region src/children/boot.d.ts
interface LineageThread {
  readonly threadId: string;
  readonly parentThreadId: string;
  readonly rootThreadId: string;
  readonly relationshipToParent: "subagent" | "fork";
  /** The Pi session M04's thread index bound to the thread; null when none is bound; "unknown" when the index could not be read. */
  readonly sessionId: string | null | "unknown";
  readonly closed: boolean;
}
interface LineageReaderPort {
  listChildThreads(): Promise<{
    readonly ok: true;
    readonly threads: readonly LineageThread[];
  } | {
    readonly ok: false;
    readonly reason: "unavailable";
  }>;
}
interface BootDeps {
  readonly threads: ThreadPort;
  readonly lineage: LineageReaderPort;
  readonly store: OrchestrationStore;
  readonly identity: ChildIdentityWriter & {
    sweepPending?(): SweepPendingResult;
  };
}
interface BootReport {
  readonly lineage: "ok" | "unavailable";
  /** Thread ids closed by this boot. */
  readonly closed: string[];
  /** Session ids retired through M03 by this boot. */
  readonly retired: string[];
  /** Thread ids whose release could not be confirmed; kept, marked used, never re-run. */
  readonly unconfirmed: string[];
  readonly unknown: {
    readonly threadId: string;
    readonly why: string;
  }[];
  /** Thread ids whose close failed; retried at the next boot. */
  readonly leftover: string[];
  readonly orphanRecords: string[];
  readonly sweptPending: string[];
  readonly problems: string[];
}
declare function reconcileChildren(deps: BootDeps): Promise<BootReport>;
//#endregion
//#region src/backend/index.d.ts
declare const MANAGED_WORK_BACKEND_ENTRY: "aetheria:orchestration-backend";
//#endregion
export { type AcceptedValue, type AuthorizeSpawnResult, type AvailabilityPort, BACKEND_DIRECT_CALLS, type BackendDirectCall, type BootDeps, type BootReport, CHILDREN_OPERATIONS, CHILD_PHASES, CHILD_WRITER, COMPLETION_WAKES, type CallerContext, type CancelWaitArgs, type ChildDiagnostic, type ChildIdentityWriter, type ChildMode, type ChildPhase, type ChildRecord, type ChildReport, type ChildRoute, type ChildRow, type ChildService, type ChildServiceDeps, type ChildSettle, type ChildState, type ChildrenAwaitReportArgs, type ChildrenCancelArgs, type ChildrenCloseArgs, type ChildrenCloseValue, type ChildrenForkArgs, type ChildrenForkValue, type ChildrenInterruptArgs, type ChildrenListArgs, type ChildrenListValue, type ChildrenMessageArgs, type ChildrenMessageValue, type ChildrenSpawnArgs, type ChildrenSpawnValue, type ChildrenStatusArgs, type ChildrenStatusValue, type ChildrenTargetArgs, type Clock, type CompletionWake, type CreateChildThreadInput, type Decoded, type DelegatedCompletionState, FINAL_JOB_STATES, type FinalJobState, type IdentityStoreRead, type IdentityStoreResult, JOBS_OPERATIONS, JOBS_STORE, JOB_LIFECYCLE_OPERATIONS, JOB_LIFECYCLE_ORDER, JOB_STATES, type JobExit, type JobFlags, type JobRow, type JobState, type JobsAdoptedArgs, type JobsAdoptedValue, type JobsAttachArgs, type JobsAttachValue, type JobsCancelArgs, type JobsExitedArgs, type JobsExitedValue, type JobsKillArgs, type JobsKillValue, type JobsListArgs, type JobsListValue, type JobsOutputArgs, type JobsOutputValue, type JobsReserveArgs, type JobsReserveValue, type LineageReaderPort, type LineageThread, type ListDiagnostic, type ListResult, type M03IdentityStoreLike, M03_AUTHORIZE_CODES, MANAGED_WORK_BACKEND_ENTRY, MANAGED_WORK_PACKAGE, type MainRecord, type ManagedIdentityWriter, type ModelSelection, ORCHESTRATION_CODES, ORCHESTRATION_CODE_CLASSES, ORCHESTRATION_OPERATIONS, ORCHESTRATION_STORE, ORDINARY_CHILD_COMPLETION_WAKE, OUTBOX_KINDS, OUTBOX_STATES, type OpenResult, type OrchestrationCode, type OrchestrationCodeClass, type OrchestrationCodecName, type OrchestrationFailure, type OrchestrationOperation, type OrchestrationResult, type OrchestrationStore, type OutboxKind, type OutboxState, type Outcome, type OutputChunk, PARAMETERS, PARAMETER_ACCEPTANCE, PARAMETER_NAMES, type Parameter, type ParameterName, type ParameterSnapshot, type ParameterStatus, type PendingRequest, type PlanModeInheritPort, type PortResult, type ProcessGroupPort, type ProcessStartIdentity, RECORD_VERSION, REQUEST_CAUSES, type ReadResult, type RequestKind, type RestartNote, type ResumeBarrierPort, type RouteAvailability, type RouteRef, type RunUpdate, STORE_LAYOUT, type SettleOutcome, type SettleStatus, type SpawnAuthorizer, type SpawnRequest, type StoreDeps, type StoreFailureCode, type StoreFormat, type StoreFs, type SweepPendingResult, THREAD_PORT_CALLS, type ThreadLineage, type ThreadPort, type ThreadPortCall, type ThreadStatus, type TurnCompletedEvent, type TurnOutcome, type WriteResult, type Xc6ReplyKind, createChildIdentityWriter, createChildService, createIdentityStore, decodeParameterSnapshot, jobCompletionKey, jobLostKey, mapRunStatus, newChildRecord, nodeStoreDeps, openOrchestrationStore, orchestrationCodecs, outcomeOfCode, parameter, parameterSnapshot, reconcileChildren, restartNoticeKey, routeNoticeKey, validateChildRecord, validateMainRecord, validateParameters, xc6ReplyKindOf };