//#region src/types.d.ts
/**
 * The caller's project facts: the repository root, whether it is the Aetheria checkout, and the project's cycles folder. The caller (the Backend, from the
 * caller's XC-1 identity) supplies them; no agent argument reaches this object. `problems` are the facts' own notes, shown to the evidence role.
 */
interface EvidenceProject {
  readonly root: string;
  readonly place: "home" | "foreign";
  readonly settingsPaths: {
    readonly cycles: string;
  };
  readonly problems?: readonly string[] | undefined;
}
/**
 * Read-only access to files of the project working tree, by path relative to the project root. `exists` answers false only when the path is
 * definitely absent (ENOENT or ENOTDIR); any other failure — permission, I/O, an escape from the root — rejects, so an unreadable path is never absent.
 */
interface RepositoryFiles {
  exists(path: string): Promise<boolean>;
  readText(path: string): Promise<string>;
}
/**
 * Runs one fixed, read-only Git command in the project repository and returns its stdout. The runner adds the repository, the fixed options, the output
 * cap and the call's signal; the caller passes only the sub-command arguments. A failure rejects with a `GitCommandError` carrying the exit code.
 */
type GitRunner = (args: readonly string[], signal?: AbortSignal | undefined) => Promise<string>;
interface EvidenceSeams {
  readonly files: RepositoryFiles;
  readonly git: GitRunner;
}
interface HistoryOptions {
  /** The cycle slug. Not trusted: anything but a kebab-case slug is `invalid`. */
  readonly cycle: unknown;
  readonly project: EvidenceProject;
  /** The evidence role's identity, reported back unchanged; null when none is given. */
  readonly role?: string | null | undefined;
  readonly signal?: AbortSignal | undefined;
}
type Verdict = "invalid" | "unverified" | "plan-unchanged" | "plan-changed";
/** The helper's fields. Which are present depends on how far the evidence got; every `unverified` carries `reason`. */
interface HistoryEvidence {
  verdict: Verdict;
  reason?: string;
  cycle?: string;
  record?: string;
  planPath?: string;
  role?: string | null;
  suppliedBy?: string;
  history?: string[];
  baselinePointerChanges?: string[];
  currentPlan?: string | null;
  currentPlanSha256?: string | null;
  baseline?: string;
  baselineCommit?: string;
  baselinePlanPath?: string | null;
  baselinePlan?: string | null;
  baselinePlanSha256?: string | null;
  baselineGateHistory?: string | null;
  planApprovalRecorded?: boolean;
  comparison?: string;
  approvalCommit?: string;
  approvalGateEntry?: string;
  baselinePointerVerified?: boolean;
  firstBaselinePointerCommit?: string;
  historyHead?: string;
  /** The project facts' own problems, present only when there are some (replaces the DSH `settingsProblems`). */
  projectProblems?: string[];
}
//#endregion
//#region src/backend/files.d.ts
/** Files of the project working tree at `root` (an absolute path). Nothing is read until asked. */
declare function createRepositoryFiles(root: string): RepositoryFiles;
//#endregion
//#region src/backend/git.d.ts
/** A runner for the repository at `root` (an absolute path). Nothing runs until a command is requested. */
declare function createFixedGitRunner(root: string): GitRunner;
//#endregion
//#region src/history.d.ts
declare const CYCLE_SLUG: RegExp;
/** The most approval/pointer events the integrity walk follows; more fails closed rather than truncating. */
declare const MAX_HISTORY_EVENTS = 128;
/**
 * Gather the history evidence for one cycle, over the injected seams.
 * @param options.cycle - the cycle slug; the one value an agent supplies.
 * @param options.project - the caller's project facts: repository root, place and cycles folder.
 * @param options.role - the evidence role's identity, reported back.
 * @param options.signal - cancellation, passed to every Git command.
 * @returns a JSON value; failures are reported as `unverified` with a reason, never thrown as passes and never as approval.
 */
declare function historyEvidence(options: HistoryOptions, seams: EvidenceSeams): Promise<HistoryEvidence>;
//#endregion
//#region src/errors.d.ts
declare class GitCommandError extends Error {
  readonly exitCode: number | null;
  constructor(message: string, exitCode: number | null, cause?: unknown);
}
//#endregion
//#region src/backend/index.d.ts
interface AuditHistoryInput {
  /** The cycle slug; anything but a kebab-case slug is answered `invalid`. */
  readonly cycle: unknown;
  /** The caller's project facts: the repository root, place and cycles folder, with any problems the facts carry. */
  readonly project: EvidenceProject;
  /** The calling evidence role, reported back; null when none. */
  readonly role?: string | null | undefined;
  readonly signal?: AbortSignal | undefined;
}
/** The fixed audit `history` operation for one cycle in the caller's project. */
declare function auditHistory(input: AuditHistoryInput): Promise<HistoryEvidence>;
//#endregion
export { AuditHistoryInput, CYCLE_SLUG, type EvidenceProject, type EvidenceSeams, GitCommandError, type GitRunner, type HistoryEvidence, type HistoryOptions, MAX_HISTORY_EVENTS, type RepositoryFiles, type Verdict, auditHistory, createFixedGitRunner, createRepositoryFiles, historyEvidence };