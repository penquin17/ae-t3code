//#region src/contracts/permission-ledger.d.ts
type LedgerEvidence = 'refusal-test' | 'audit';
type PlatformStatus = 'tested' | 'not-run';
interface LedgerRow {
  readonly id: string;
  /** What is refused, in words that name no mechanism this row does not have. */
  readonly claim: string;
  /** The code that decides: a repository path and a text that appears in it. Never "hidden", "approval" or a list of names. */
  readonly boundary: {
    readonly file: string;
    readonly symbol: string;
  };
  /** Linux is blocked (no Linux host, M12): a row never claims it. */
  readonly platforms: {
    readonly macos: 'tested';
    readonly linux: 'not-run';
  };
  /** The refusal test: a repository path and the exact title of a live test in it. */
  readonly test: {
    readonly path: string;
    readonly title: string;
  };
  readonly evidence: LedgerEvidence;
  readonly owner: string;
  /** What this row does not prevent. */
  readonly notClaimed: string;
}
interface NonClaim {
  readonly id: string;
  readonly text: string;
  /** Where the statement comes from: a source line, a test, or the step-26 audit finding. */
  readonly basis: string;
}
declare const H4_LEDGER: readonly LedgerRow[];
declare const H4_NON_CLAIMS: readonly NonClaim[];
declare const REQUIRED_NON_CLAIMS: readonly ["shell", "children", "external-processes", "extensions", "network", "credentials", "arbitrary-paths", "other-machines", "reads", "approval-is-not-confinement", "hidden-is-not-enforcement", "full-access-skips"];
/** The problems in a ledger; an empty list means the shape holds. The cross-check against files is the test's (this module reads no file). */
declare function checkLedger(rows: readonly LedgerRow[], nonClaims: readonly NonClaim[]): string[];
//#endregion
//#region src/contracts/coverage.d.ts
type GuaranteeId = 'A6' | 'T1' | 'H5' | 'H4';
//#endregion
//#region src/contracts/codes.d.ts
type OutcomeClass = 'refused-unchanged' | 'failed-unchanged' | 'applied-with-warning';
interface CodeEntry<C extends string = string> {
  readonly code: C;
  readonly guarantee: GuaranteeId;
  readonly outcomeClass: OutcomeClass;
  readonly meaning: string;
  readonly source: string;
}
declare const CODE_REGISTRY: readonly [CodeEntry<"READINESS_NOT_LOADED">, CodeEntry<"READINESS_CHANGED">, CodeEntry<"READINESS_RETARGETED">, CodeEntry<"READINESS_UNSUPPORTED_SCOPE">, CodeEntry<"READINESS_ANCESTOR_LIMIT">, CodeEntry<"READINESS_UNREADABLE">, CodeEntry<"READINESS_TOO_LARGE">, CodeEntry<"READINESS_UNSTABLE">, CodeEntry<"T1_NOT_OBSERVED">, CodeEntry<"T1_STALE">, CodeEntry<"T1_EXISTS">, CodeEntry<"T1_NOT_FOUND">, CodeEntry<"T1_RETARGETED">, CodeEntry<"T1_DANGLING_LINK">, CodeEntry<"T1_WRITE_BUSY">, CodeEntry<"T1_IS_DIRECTORY">, CodeEntry<"T1_LINK_LOOP">, CodeEntry<"T1_OBSERVATION_DROPPED">, CodeEntry<"WRITE_FAILED">, CodeEntry<"AWARENESS_HELD">, CodeEntry<"AWARENESS_LEFTOVER">, CodeEntry<"AWARENESS_ASSIGNED">, CodeEntry<"AWARENESS_UNAVAILABLE">, CodeEntry<"AWARENESS_OVERLAP">, CodeEntry<"AWARENESS_INVALID">, CodeEntry<"AWARENESS_STALE">, CodeEntry<"AWARENESS_UNVERIFIED">, CodeEntry<"AWARENESS_NO_SESSION">, CodeEntry<"AWARENESS_NO_AGENT">, CodeEntry<"AWARENESS_NOT_MAIN">, CodeEntry<"COORDINATION_UNAVAILABLE">];
type Code = (typeof CODE_REGISTRY)[number]['code'];
declare const codeEntry: (code: string) => CodeEntry<Code>;
//#endregion
//#region src/contracts/refusals.d.ts
interface Boundary {
  readonly file: string;
  readonly symbol: string;
}
interface RefusalRow {
  readonly code: string;
  readonly class: OutcomeClass;
  readonly message: string;
  readonly boundary: Boundary;
  readonly guarantee: GuaranteeId | 'AUTH';
  readonly owner: 'M04' | 'M03';
}
interface NonCodeRefusal {
  readonly id: string;
  readonly code: null;
  readonly class: OutcomeClass;
  readonly messagePattern: string;
  readonly boundary: Boundary;
  readonly owner: 'T3';
  readonly note: string;
}
declare const REFUSAL_TABLE: readonly RefusalRow[];
declare const NON_CODE_REFUSALS: readonly NonCodeRefusal[];
declare const refusalRow: (code: string) => RefusalRow;
/**
 * Problems in a table against the code registry: a registry code with no row, a row without class, message or boundary, a duplicate. With `read` (a function from a
 * repository path to its text, or null) it also checks that each boundary file exists and holds its symbol. Empty means consistent.
 */
declare function checkRefusalTable(rows: readonly RefusalRow[], registry: readonly CodeEntry[], read?: (file: string) => string | null): string[];
//#endregion
export { Boundary, CODE_REGISTRY, type Code, type CodeEntry, H4_LEDGER, H4_NON_CLAIMS, LedgerEvidence, LedgerRow, NON_CODE_REFUSALS, NonClaim, NonCodeRefusal, type OutcomeClass, PlatformStatus, REFUSAL_TABLE, REQUIRED_NON_CLAIMS, RefusalRow, checkLedger, checkRefusalTable, codeEntry, refusalRow };