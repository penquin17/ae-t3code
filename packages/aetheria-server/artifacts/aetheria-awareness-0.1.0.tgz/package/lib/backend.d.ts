//#region ../aetheria-resources/src/identity/schema.d.ts
declare const KERNEL_VERSION = "0.1.0";
/** Why a record or an identity cannot be used. `AUTH_RETIRE_REFUSED` belongs to the store API and is not here. */
declare const CODES: readonly string[];
type Kind = 'main' | 'child';
type AuthoritySource = 'main' | 'role' | 'spawn-explicit';
type RoleOrigin = 'checkout' | 'home';
/** The complete persisted fact set. Rule digests, depth, project and authority are never in it. */
interface IdentityRecord {
  readonly sessionId: string;
  readonly kind: Kind;
  readonly rootSessionId: string;
  readonly parentChain: readonly string[];
  readonly role: string | null;
  readonly roleOrigin: RoleOrigin | null;
  readonly roleDigest: string | null;
  readonly authoritySource: AuthoritySource;
  readonly explicitAllow?: readonly string[];
}
type RecordResult = {
  readonly ok: true;
  readonly record: IdentityRecord;
} | {
  readonly ok: false;
  readonly code: 'AUTH_IDENTITY_INVALID';
  readonly problems: readonly string[];
};
/**
 * Validate a stored record against the three valid combinations. `depth` may be supplied only as a check: it must equal
 * `parentChain.length` and is dropped from the result (it is derived at every start). Any other unknown field is invalid.
 */
declare function validateRecord(input: unknown): RecordResult;
interface SettingsPaths {
  readonly vault: string;
  readonly cycles: string;
  readonly docs: string;
}
interface ProjectFacts {
  readonly root: string;
  readonly place: 'home' | 'foreign';
  readonly settingsPaths: SettingsPaths;
}
/** The ported settings defaults (DSH `settings.mjs`): relative, slash-ended folders. */
declare const DEFAULT_SETTINGS_PATHS: SettingsPaths;
/** Check what a project resolver returned; the identity never carries an unchecked project. */
declare function validateProject(input: unknown): {
  ok: true;
  project: ProjectFacts;
} | {
  ok: false;
  problems: string[];
};
//#endregion
//#region ../aetheria-resources/src/kernel/role-schema.d.ts
/** Generic delegation tools a child's own layer adds; a role may not declare them (declared and matched identity would differ). */
declare const GENERIC_DELEGATION: ReadonlySet<string>;
//#endregion
//#region ../aetheria-resources/src/identity/resolve.d.ts
/**
 * Capabilities no child ever holds: the workflow tool and the goal tools (design C5, D13; names contingent on M07). They are registered in no child's
 * list, and a child that reaches one anyway is refused with `AUTH_TOOL_NOT_ALLOWED`, whatever its allow-list says.
 */
declare const CHILD_FORBIDDEN: ReadonlySet<string>;
type StoreRead = {
  status: 'absent';
} | {
  status: 'pending';
} | {
  status: 'active';
  record: unknown;
} | {
  status: 'retired';
  reason?: string;
} | {
  status: 'corrupt';
  problem: string;
};
interface RoleDefinition {
  readonly name: string;
  readonly projectLayer: boolean;
  readonly allow: readonly string[];
  readonly maxDepth: number;
  readonly background: string;
  readonly origin: 'checkout' | 'home';
  readonly digest: string | null;
}
interface IdentityPorts {
  read(sessionId: string): StoreRead;
  readonly roles: {
    lookup(role: string): RoleDefinition | null;
    roleOfTool(tool: string): RoleDefinition | null;
  };
  project(workingFolder: string): unknown;
  /** The composition's full callable tool set; a main session's authority. */
  readonly callable: readonly string[];
}
interface Authority {
  readonly callable: readonly string[];
  readonly maxDepth: number;
  readonly background: string;
  readonly projectLayerAllowed: boolean;
}
interface CallerIdentity extends IdentityRecord {
  readonly depth: number;
  readonly project: ProjectFacts;
  readonly issuedBy: string;
  readonly authority: Authority;
}
type UnavailableReason = 'missing-record' | 'invalid-record' | 'retired' | 'role-removed' | 'authority-unavailable';
type Resolution = {
  readonly ok: true;
  readonly identity: CallerIdentity;
} | {
  readonly ok: false;
  readonly reason: UnavailableReason;
  readonly code: string;
  readonly detail: unknown;
  readonly record?: IdentityRecord;
};
/** Resolve a session's caller identity from its stored record, recomputing depth, project, issuedBy and authority. */
declare function identityOf(ports: IdentityPorts, sessionId: string, workingFolder: string): Resolution;
type Verdict = {
  readonly allowed: true;
} | {
  readonly allowed: false;
  readonly code: string;
  readonly reason: string;
};
/**
 * May this resolved identity run this tool? The verdict depends only on the resolution, the tool name and the catalog: `input`
 * is accepted so every caller passes the same arguments, and is never read, so frozen, mutated or hostile input cannot change it.
 * Read and messaging callers decide which tools to ask about; this predicate never turns unknown authority into main.
 *
 * Depth: starting a role is gated by the TARGET role's `maxDepth` (the child would sit at `depth + 1`, so the caller's depth must be
 * below it; DSH roles.test.mjs:559, :695). A generic delegation tool, reachable only at depth 0, is gated by the caller's own
 * authority `maxDepth`.
 */
declare function authorize(ports: Pick<IdentityPorts, 'roles'>, resolution: Resolution | undefined, toolName: string, _input?: unknown): Verdict;
type Guarded<T> = {
  readonly ran: true;
  readonly value: T;
} | {
  readonly ran: false;
  readonly verdict: Verdict & {
    readonly allowed: false;
  };
};
/**
 * Run an effect only if the predicate allows the tool. The one wrapper an Aetheria-owned executor calls inside its `execute`: a refusal returns the
 * verdict and the effect is never called, so nothing changes. The effect receives the input it was given, unchanged by this function.
 */
declare function runAuthorized<T>(ports: Pick<IdentityPorts, 'roles'>, resolution: Resolution | undefined, toolName: string, input: unknown, effect: (input: unknown) => T): Guarded<T>;
//#endregion
//#region ../aetheria-resources/src/identity/store.d.ts
declare const STORE_FORMAT_VERSION = 1;
//#endregion
//#region src/contracts/coverage.d.ts
type GuaranteeId = 'A6' | 'T1' | 'H5' | 'H4';
interface CoverageRow {
  readonly id: GuaranteeId;
  readonly name: string;
  readonly enforcedAt: string;
  readonly fails: string;
  readonly covers: string;
  readonly doesNotCover: string;
}
declare const COVERAGE_FIELDS: readonly ["enforcedAt", "fails", "covers", "doesNotCover"];
declare const COVERAGE: readonly CoverageRow[];
declare const SHELL_STATEMENT = "Shell writes are visibility only, not guarded: the tracker's git status snapshots show changed paths and prevent nothing.";
declare const coverageRow: (id: string) => CoverageRow;
declare const coverageSentence: (id: string) => string;
//#endregion
//#region src/contracts/checks.d.ts
declare const coverageProblems: (rows: readonly CoverageRow[]) => string[];
declare const docCoverageProblems: (doc: string) => string[];
declare const docCodeProblems: (doc: string) => string[];
declare const codeMentions: (source: string) => string[];
declare const unregisteredCodeMentions: (source: string) => string[];
//#endregion
//#region src/contracts/codes.d.ts
type OutcomeClass = 'refused-unchanged' | 'failed-unchanged' | 'applied-with-warning';
interface CodeEntry<C extends string = string> {
  readonly code: C;
  readonly guarantee: GuaranteeId;
  readonly outcomeClass: OutcomeClass;
  readonly meaning: string;
  readonly source: string;
}
declare const CODE_REGISTRY: readonly [CodeEntry<"READINESS_NOT_LOADED">, CodeEntry<"READINESS_CHANGED">, CodeEntry<"READINESS_RETARGETED">, CodeEntry<"READINESS_UNSUPPORTED_SCOPE">, CodeEntry<"READINESS_ANCESTOR_LIMIT">, CodeEntry<"READINESS_UNREADABLE">, CodeEntry<"READINESS_TOO_LARGE">, CodeEntry<"READINESS_UNSTABLE">, CodeEntry<"T1_NOT_OBSERVED">, CodeEntry<"T1_STALE">, CodeEntry<"T1_EXISTS">, CodeEntry<"T1_NOT_FOUND">, CodeEntry<"T1_RETARGETED">, CodeEntry<"T1_DANGLING_LINK">, CodeEntry<"T1_WRITE_BUSY">, CodeEntry<"T1_IS_DIRECTORY">, CodeEntry<"T1_LINK_LOOP">, CodeEntry<"T1_OBSERVATION_DROPPED">, CodeEntry<"WRITE_FAILED">, CodeEntry<"AWARENESS_HELD">, CodeEntry<"AWARENESS_LEFTOVER">, CodeEntry<"AWARENESS_ASSIGNED">, CodeEntry<"AWARENESS_UNAVAILABLE">, CodeEntry<"AWARENESS_OVERLAP">, CodeEntry<"AWARENESS_INVALID">, CodeEntry<"AWARENESS_STALE">, CodeEntry<"AWARENESS_UNVERIFIED">, CodeEntry<"AWARENESS_NO_SESSION">, CodeEntry<"AWARENESS_NO_AGENT">, CodeEntry<"AWARENESS_NOT_MAIN">, CodeEntry<"COORDINATION_UNAVAILABLE">];
type Code = (typeof CODE_REGISTRY)[number]['code'];
declare const codeEntry: (code: string) => CodeEntry<Code>;
//#endregion
//#region src/contracts/outcome.d.ts
interface GuardedOutcome {
  readonly code: Code;
  readonly outcomeClass: OutcomeClass;
  readonly coverage: string;
}
interface CleanSuccess {
  readonly clean: true;
}
declare const cleanSuccess: () => CleanSuccess;
declare const outcomeFor: (code: string) => GuardedOutcome;
declare const renderOutcome: (outcome: GuardedOutcome, detail?: string) => string;
//#endregion
//#region src/observation/types.d.ts
/** The version token (D6): the content digest decides; size and modification time are reported, and size is a quick pre-filter that can only refuse. */
interface VersionToken {
  readonly digest: string;
  readonly size: number;
  readonly mtimeMs: number;
}
/** What the host reports about one spelling of a target at one moment. */
type Resolution$1 = ExistingFile | AbsentTarget | DanglingLink | LinkLoop | NotAFile;
interface ExistingFile {
  readonly kind: 'file';
  /** The absolute, lexical spelling the caller used (symlinks and case untouched). */
  readonly spelling: string;
  /** The real path of the file: every link followed. */
  readonly canonicalPath: string;
  /** File identity (D6): device and inode as decimal strings (64-bit safe). */
  readonly dev: string;
  readonly ino: string;
  readonly size: number;
  readonly mtimeMs: number;
  /** Streams the content digest of the file as inspected. No size cap. Rejects with `UnstableReadError` when the file changed while it was read. */
  readonly digest: () => Promise<string>;
}
interface AbsentTarget {
  readonly kind: 'absent';
  readonly spelling: string;
  /** Real path of the deepest existing ancestor plus the remaining names: the identity of an absent file. */
  readonly canonicalPath: string;
}
interface DanglingLink {
  readonly kind: 'dangling-link';
  readonly spelling: string;
}
interface LinkLoop {
  readonly kind: 'link-loop';
  readonly spelling: string;
}
/** A directory, or another file that is not a regular file (a pipe, a device): read, write and edit act on regular files only. */
interface NotAFile {
  readonly kind: 'directory';
  readonly spelling: string;
  readonly canonicalPath: string;
  readonly notRegular?: true;
}
/** What a successful read tells the session. `token` is the digest/size/mtime of the bytes the read RETURNED. */
interface ReadObservation {
  readonly spelling: string;
  readonly canonicalPath: string;
  readonly dev: string;
  readonly ino: string;
  readonly token: VersionToken;
}
interface AbsentObservation {
  readonly spelling: string;
  readonly canonicalPath: string;
}
/** A session's own successful write: the new file's identity and token, and the identity it replaced (its entry is dropped). */
interface WriteRecord extends ReadObservation {
  readonly replaced?: {
    readonly dev: string;
    readonly ino: string;
  };
}
interface DropTarget {
  readonly spelling?: string;
  readonly canonicalPath?: string;
}
type RefusalCode = 'T1_NOT_OBSERVED' | 'T1_STALE' | 'T1_EXISTS' | 'T1_NOT_FOUND' | 'T1_RETARGETED' | 'T1_DANGLING_LINK' | 'T1_LINK_LOOP' | 'T1_IS_DIRECTORY';
type Verdict$1 = {
  readonly ok: true;
  readonly mode: 'replace' | 'create';
  readonly observed: VersionToken | null;
} | {
  readonly ok: false;
  readonly code: Extract<Code, RefusalCode>;
  readonly detail: string;
  readonly outcome: GuardedOutcome;
};
/** Thrown by a digest or stable read when the bytes and the file's metadata could belong to different versions. */
declare class UnstableReadError extends Error {
  readonly code = "UNSTABLE_READ";
  constructor(message: string);
}
//#endregion
//#region src/observation/session.d.ts
interface SessionObservations {
  /** Grant after a guarded `read` succeeded with the bytes it returned. Only `read` calls this; an edit's own internal reads never do. */
  observe(read: ReadObservation): void;
  /** Record that the session saw the target absent, so a later creation is refused T1_EXISTS. */
  observeAbsent(target: AbsentObservation): void;
  checkForWrite(resolution: Resolution$1): Promise<Verdict$1>;
  checkForEdit(resolution: Resolution$1): Promise<Verdict$1>;
  /** The session's own successful write: replace the entry with the new file's identity and token. */
  recordAfterWrite(write: WriteRecord): void;
  /** Forget a target (observation-update failed, D17): the next check is T1_NOT_OBSERVED until an explicit read. */
  drop(target: DropTarget): void;
  clear(): void;
  /** Counts only, for diagnostics and tests: never content, paths or digests. */
  snapshot(): {
    files: number;
    spellings: number;
    absent: number;
  };
}
declare function createSessionObservations(): SessionObservations;
/** The text a model reads for a refused verdict (the code, the cause, "native write/edit only", the guarantee's limit); null for an allowed one. */
declare const renderVerdict: (verdict: Verdict$1) => string | null;
//#endregion
//#region src/observation/registry.d.ts
interface ObservationRegistry {
  /** The session's state, created empty on first use. The same id always gives the same object until `dispose`. */
  forSession(sessionId: string): SessionObservations;
  /** Clear and forget one session (its disposal). */
  dispose(sessionId: string): void;
  /** Clear every session (host disposal). */
  clearAll(): void;
}
declare function createObservationRegistry(): ObservationRegistry;
//#endregion
//#region src/read/window.d.ts
declare const DEFAULT_MAX_LINES = 2000;
declare const DEFAULT_MAX_BYTES: number;
/** Today's configured value (preset `readMaxLineLength: 10000`), carried as a parameter the user may change. */
declare const DEFAULT_MAX_LINE_LENGTH = 10000;
interface Truncation {
  readonly content: string;
  readonly truncated: boolean;
  readonly truncatedBy: 'lines' | 'bytes' | null;
  readonly totalLines: number;
  readonly totalBytes: number;
  readonly outputLines: number;
  readonly outputBytes: number;
  readonly lastLinePartial: boolean;
  readonly firstLineExceedsLimit: boolean;
  readonly maxLines: number;
  readonly maxBytes: number;
}
interface TextWindowOptions {
  /** 1-indexed first line. Absent, 0 and negative values start at line 1 (as Pi does). */
  readonly offset?: number;
  readonly limit?: number;
  readonly maxLineLength?: number;
  readonly maxLines?: number;
  readonly maxBytes?: number;
  /** The path as the model gave it; it only appears in the "line exceeds the byte limit" hint. */
  readonly path?: string;
}
interface TextWindow {
  /** What the tool returns as text. */
  readonly text: string;
  /** True when the start line was past the end of the file: `text` is then only the footer. */
  readonly pastEnd: boolean;
  /** Lines in the file, counted as Pi counts them (a final newline does not add one). */
  readonly totalLines: number;
  /** Present when the byte or line cap applied (Pi's `details.truncation`). */
  readonly truncation?: Truncation;
}
declare const endOfFileFooter: (totalLines: number) => string;
declare const lineCutNote: (maxLineLength: number) => string;
declare const formatSize: (bytes: number) => string;
declare function formatTextWindow(input: string | Uint8Array, options?: TextWindowOptions): TextWindow;
//#endregion
//#region src/readiness/types.d.ts
interface FsInfo {
  readonly type: 'file' | 'directory' | 'symlink' | 'other';
  readonly size?: number | undefined;
  readonly version?: string | undefined;
}
interface ReadinessFs {
  /** Metadata of the path itself (links not followed); undefined when absent. */
  lstat(path: string): Promise<FsInfo | undefined>;
  /** The real path of `path`; a link whose target is missing resolves to itself. */
  resolve(path: string): Promise<string>;
  processPath(target: string): string;
  /** Metadata of the target; undefined when absent. */
  stat(target: string, signal?: AbortSignal): Promise<FsInfo | undefined>;
  /** At most `maxBytes`; rejects with code FS_TOO_LARGE when the file is longer. */
  readBytes(target: string, signal: AbortSignal | undefined, maxBytes: number): Promise<Uint8Array>;
  listDir(target: string, signal?: AbortSignal): Promise<ReadonlyArray<{
    readonly name: string;
    readonly type?: FsInfo['type'] | undefined;
  }>>;
}
type ReadinessCode = Extract<Code, 'READINESS_NOT_LOADED' | 'READINESS_CHANGED' | 'READINESS_RETARGETED' | 'READINESS_UNSUPPORTED_SCOPE' | 'READINESS_ANCESTOR_LIMIT' | 'READINESS_UNREADABLE' | 'READINESS_TOO_LARGE' | 'READINESS_UNSTABLE'>;
/** A readiness failure that must leave the target unchanged. `code` is a registered READINESS_* code. */
declare class ReadinessError extends Error {
  readonly code: ReadinessCode;
  constructor(message: string, code: ReadinessCode);
}
interface ChainConfig {
  readonly sha256Hex: (text: string) => string;
  /** Instruction file names looked for in every directory of the chain, in order, then the local ones. Exact names only. */
  readonly candidates: readonly string[];
  readonly markers: readonly string[];
  readonly maxSourceBytes: number;
  readonly maxContextBytes: number;
  readonly maxAncestors: number;
  /** An absolute file read once per chain as the 'user-global' frame; none by default. */
  readonly globalFile: string | undefined;
  readonly globalLabel: string | undefined;
}
/** One path rule that M03's `ruleSources(identity, {targetPath})` says governs the target, with the means to read ITS text (never a same-path read). */
interface PathRuleInput {
  /** The absolute directory the rule governs. */
  readonly dir: string;
  /** What the model sees. */
  readonly label: string;
  /** The digest M03's query returned for the rule. */
  readonly digest: string;
  /** M03's loader: the rule's text and its digest, or the reason it cannot be read. */
  readonly load: (signal?: AbortSignal) => Promise<{
    readonly body: string;
    readonly digest: string;
  } | {
    readonly problem: string;
  }>;
}
interface FrameFile {
  readonly path: string;
  readonly version: string;
}
/** One directory's complete guidance as the model sees it. `digest` is `sha256:<hex>` of exactly `text`; `id` is the projection block id. */
interface Frame {
  readonly dir: string;
  readonly id: string;
  readonly text: string;
  readonly digest: string;
  readonly files: readonly FrameFile[];
}
interface Chain {
  readonly target: string;
  /** The hash the chain was built with (removal frames use it). */
  readonly sha256Hex: (text: string) => string;
  readonly frames: readonly Frame[];
  /** Every directory the target is governed through, global first. */
  readonly directories: readonly string[];
  /** Absent candidates by directory (paths relative to the session's project root). */
  readonly absent: ReadonlyMap<string, readonly string[]>;
  /** Path rules that contributed, with the digest they were read at. */
  readonly ruleDigests: readonly {
    readonly label: string;
    readonly digest: string;
  }[];
}
/** The digest last delivered for each directory (or 'user-global'). A required frame equal to it needs no new delivery. */
type DeliveredFrames = ReadonlyMap<string, string>;
//#endregion
//#region src/readiness/chain.d.ts
declare const GLOBAL_DIR = "user-global";
declare const DEFAULT_LIMITS: Readonly<{
  maxSourceBytes: 65536;
  maxContextBytes: 65536;
  maxAncestors: 128;
}>;
interface ChainOptions {
  readonly sha256Hex: (text: string) => string;
  readonly candidates?: readonly string[];
  readonly localCandidates?: readonly string[];
  readonly markers?: readonly string[];
  readonly maxSourceBytes?: number;
  readonly maxContextBytes?: number;
  readonly maxAncestors?: number;
  readonly globalFile?: string | undefined;
  readonly globalLabel?: string | undefined;
}
/** The chain settings: names, markers, the DSH limits, an optional global file. Candidate names are plain file names, never paths. */
declare function chainConfig(options: ChainOptions): ChainConfig;
/** The project root for a directory: the nearest ancestor holding a marker (ported from M03's place.ts, which ported DSH's). */
declare function projectRootFor(fs: ReadinessFs, dir: string, cwd: string, config: ChainConfig): Promise<string>;
/** The block id of the frame for a directory: stable per directory so a later frame supersedes an earlier one. */
declare const frameId: (dir: string, sha256Hex: (text: string) => string) => string;
/** A directory whose instructions were shown earlier and now has none. */
declare function removalFrame(dir: string, sha256Hex: (text: string) => string): Frame;
interface CollectInput {
  readonly filePath: unknown;
  readonly cwd: string;
  readonly config: ChainConfig;
  readonly signal?: AbortSignal | undefined;
  /** The path rules M03 says govern the target, each with its own loader. */
  readonly pathRules?: readonly PathRuleInput[] | undefined;
  /**
   * The trust gate. When true, project files (instruction candidates in the chain's directories and `.agents/rules/*.md` of each project root)
   * are DETECTED and listed in `withheld` but never read or framed. The global file is not a project file and is still read.
   */
  readonly withholdProject?: boolean | undefined;
}
interface CollectedChain extends Chain {
  /** Project files present but not read because the trust gate withheld them. */
  readonly withheld: readonly string[];
}
/**
 * Collect the governing chain for one mutation target. Returns the ordered frames — one per directory with at least one present candidate —
 * each with a digest over its rendered text.
 */
declare function collectChain(fs: ReadinessFs, input: CollectInput): Promise<CollectedChain>;
/**
 * The frames that must be the latest delivered, per directory, for a target: every present frame, and a removal frame for each directory in the
 * chain that now has no instructions but whose earlier frame this engine delivered.
 */
declare function requiredFrames(chain: Chain, delivered: DeliveredFrames): Frame[];
/** Required frames whose digest is not the one last delivered for their directory. */
declare function missingFrames(chain: Chain, delivered: DeliveredFrames): Frame[];
//#endregion
//#region src/readiness/extension-set.d.ts
interface DeclaredExtensionSet {
  /** Aetheria's bundle: the first `--extension`. */
  readonly bundlePath: string;
  /** T3's injected extension: the second and last `--extension`; it must also be what T3 recorded in T3_PI_MCP_EXTENSION_PATH. */
  readonly t3ExtensionPath: string;
  /** T3's fixed file name for its injected extension (apps/t3code/packages/provider-pi/src/server/mcpExtensionSource.ts). */
  readonly t3ExtensionFilename: string;
  /** The isolated Pi home (PI_CODING_AGENT_DIR). Its `extensions` folder must hold nothing. */
  readonly piHome: string;
}
/** What the Pi process was launched with: its argument vector and environment. */
interface ExtensionObservation {
  readonly args: readonly string[];
  readonly env: Readonly<Record<string, string | undefined>>;
}
/** The `--extension` / `-e` values in launch order, in all four spellings Pi accepts. */
declare function launchedExtensions(args: readonly string[]): string[];
/**
 * Why this launch is not the declared extension set, or null when it is. With `options.fs`, also requires the isolated Pi home's `extensions`
 * folder and the working folder's `.pi/extensions` to hold nothing. Pi's settings-declared packages are not inspected (stated limit); the
 * provider-side payload comparison of steps 25 and 37 is what catches an extension loaded that way.
 */
declare function extensionSetProblem(observed: ExtensionObservation | undefined, declared: DeclaredExtensionSet, options?: {
  readonly fs?: ReadinessFs | undefined;
  readonly cwd?: string | undefined;
}): Promise<string | null>;
//#endregion
//#region src/mutation/coordination.d.ts
type MutationMode = 'create' | 'replace';
interface CoordinationCheckInput {
  readonly operation: 'write' | 'edit';
  readonly toolCallId: string;
  readonly spelling: string;
  readonly canonicalPath: string;
  readonly mode: MutationMode;
  readonly identity: unknown;
  readonly signal?: AbortSignal | undefined;
}
type CoordinationCheck = {
  readonly status: 'allowed';
} |
/** The board refuses (a holder, a leftover, an assignment): `code` is one of the `AWARENESS_*` codes. */
{
  readonly status: 'refused';
  readonly code: Code;
  readonly detail: string;
} |
/** The board cannot be read: the write proceeds with a visible warning unless the workspace sets `failOpen: false`. */
{
  readonly status: 'unavailable';
  readonly detail: string;
};
interface CoordinationRecordInput extends CoordinationCheckInput {
  /** The size and digest of what was written. */
  readonly token: VersionToken;
}
type CoordinationRecord = {
  readonly status: 'recorded';
} | {
  readonly status: 'unavailable';
  readonly detail: string;
};
interface CoordinationPort {
  /** Before the write: may this session write here? */
  check(input: CoordinationCheckInput): Promise<CoordinationCheck>;
  /** After the write landed: record the edit. A failure never undoes the write; the sequence retries once and then warns. */
  record(input: CoordinationRecordInput): Promise<CoordinationRecord>;
}
/** The explicit adapter for a build with no board: every question is answered "unavailable", never "allowed". */
declare function unavailableBoard(reason?: string): CoordinationPort;
//#endregion
//#region src/mutation/refusal.d.ts
interface MutationRefusal {
  readonly code: Code;
  readonly outcome: GuardedOutcome;
  /** The cause alone. */
  readonly detail: string;
  /** The text a model reads. */
  readonly message: string;
}
/** A refusal or notice for a registered code; an unregistered code throws (the registry is the one vocabulary). */
declare function refusalOf(code: string, detail: string): MutationRefusal;
/** A notice that the call was applied with a warning: same shape as a refusal; its `outcome.outcomeClass` is `applied-with-warning`. */
type MutationNotice = MutationRefusal;
/** Thrown by a guarded tool for a refusal or a failed-unchanged write: the message is the C1 text and `refusal` is the structured result. */
declare class MutationRefusedError extends Error {
  readonly refusal: MutationRefusal;
  constructor(refusal: MutationRefusal);
}
//#endregion
//#region src/mutation/sequence.d.ts
type MutationOperation = 'write' | 'edit';
/** The slice of the readiness guard this sequence uses (`ReadinessGuard` satisfies it). `Grant` is the guard's own opaque grant. */
interface ReadinessPort<Grant> {
  assess(input: {
    readonly toolCallId: string;
    readonly toolName: MutationOperation;
    readonly filePath: unknown;
    readonly cwd: string;
    readonly identity: unknown;
    readonly home: boolean;
    readonly signal?: AbortSignal | undefined;
    readonly parentToolCallId?: string | null | undefined;
  }): Promise<{
    readonly granted: true;
    readonly grant: Grant;
  } | {
    readonly granted: false;
    readonly code: string;
    readonly detail: string;
  }>;
  recheck(grant: Grant, options?: {
    readonly signal?: AbortSignal | undefined;
  }): Promise<{
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: string;
    readonly detail: string;
  }>;
  revoke(grant: Grant): void;
}
interface MutationPorts<Grant = unknown> {
  readonly readiness: ReadinessPort<Grant>;
  readonly coordination: CoordinationPort;
  /** Report what a path is now (the host's `inspectTarget`). */
  readonly inspect: (spelling: string) => Promise<Resolution$1>;
  /** D12: an unavailable board lets the write proceed with a warning (default true); `false` refuses with AWARENESS_UNAVAILABLE. Readiness and freshness never fail open. */
  readonly failOpen?: boolean;
}
interface MutationRequest {
  readonly operation: MutationOperation;
  readonly toolCallId: string;
  /** The absolute, lexical path of the FINAL arguments, resolved the way the tool factory resolves it. */
  readonly spelling: string;
  /** The path as given, for readiness. */
  readonly filePath: unknown;
  readonly cwd: string;
  readonly identity: unknown;
  readonly home: boolean;
  /** The calling session's observations. */
  readonly observations: SessionObservations;
  readonly signal?: AbortSignal | undefined;
  readonly parentToolCallId?: string | null | undefined;
}
/** What the host's commit reports after the rename or exclusive link. */
interface CommittedFile {
  readonly canonicalPath: string;
  readonly dev: string;
  readonly ino: string;
  /** Digest, size and mtime of the bytes written. */
  readonly token: VersionToken;
  /** The identity this commit replaced; defaults to the identity the check saw. */
  readonly replaced?: {
    readonly dev: string;
    readonly ino: string;
  } | null | undefined;
}
interface MutationCompletion {
  /** Applied-with-warning notices, in the order T1_OBSERVATION_DROPPED then COORDINATION_UNAVAILABLE; empty on a clean success. */
  readonly warnings: readonly MutationNotice[];
}
interface MutationAuthorization {
  readonly operation: MutationOperation;
  readonly mode: MutationMode;
  readonly spelling: string;
  /** The resolved file (never a link); for a create, the real path of its parent plus the name. */
  readonly canonicalPath: string;
  /** The token the session observed; null for a create. */
  readonly observed: VersionToken | null;
  /** The file identity the check saw (replaced by the commit); null for a create. */
  readonly replaced: {
    readonly dev: string;
    readonly ino: string;
  } | null;
  /** Whether the board answered the pre-write check. */
  readonly coordination: 'allowed' | 'unavailable';
  /** Under the lock: the canonical mapping, the readiness recheck and the observation token, in that order. Null means all three still hold. */
  reverify(options?: {
    readonly signal?: AbortSignal | undefined;
  }): Promise<MutationRefusal | null>;
  /** After the commit: update the observation, record with the board (one retry), revoke the grant. Never throws for a bookkeeping failure. */
  complete(committed: CommittedFile): Promise<MutationCompletion>;
  /** No commit happened: revoke the grant. Idempotent. */
  abandon(): void;
}
type MutationBegin = {
  readonly ok: true;
  readonly authorization: MutationAuthorization;
} | {
  readonly ok: false;
  readonly refusal: MutationRefusal;
};
interface MutationGuard {
  begin(request: MutationRequest): Promise<MutationBegin>;
}
declare function createMutationGuard<Grant>(ports: MutationPorts<Grant>): MutationGuard;
//#endregion
//#region ../aetheria-presets/src/types.d.ts
/** All three hosts stay in the schema. M02 hosts only `agent`; the others are refused at activation. */
declare const HOSTS: readonly ["agent", "backend", "client"];
type Host = (typeof HOSTS)[number];
declare const CONFIG_TYPES: readonly ["string", "number", "integer", "boolean", "string-list"];
type ConfigType = (typeof CONFIG_TYPES)[number];
/** One reportable problem. `subject` names the module/composition/manifest part; `field` the key. */
interface Fault {
  code: string;
  subject: string;
  field?: string;
  message: string;
}
interface ConfigField {
  type: ConfigType;
  required: boolean;
  /** A secret field's value never enters a digest or printed output. */
  secret: boolean;
}
interface ModuleConfig {
  fields: Record<string, ConfigField>;
  /** As authored. Types are checked against `fields` when the module is selected. */
  values: Record<string, unknown>;
}
interface InlineContract {
  consumer: string;
  success: string;
  failure: string;
  uncertainty: string;
  /** A state id some selected module lists in `owns`. */
  stateOwner: string;
}
interface PackagePin {
  package: string;
  /** An exact version; ranges are refused. */
  version: string;
}
interface Compat {
  /** Exact package pins by label, e.g. `pi`. */
  packages: Record<string, PackagePin>;
  /** Expected build stamps of artifacts by artifact id. */
  artifacts: Record<string, {
    stamp: string;
  }>;
}
interface ModuleDescriptor {
  id: string;
  host: Host;
  entry: string;
  requires: {
    modules: string[];
    services: string[];
  };
  provides: {
    tools: string[];
    services: string[];
    views: string[];
  };
  owns: string[];
  replaces: string[];
  config: ModuleConfig;
  compat: Compat;
  required: boolean;
  mutatesToolInput: boolean;
  /** Exactly one of `contract` and `contractRef` is set. */
  contract?: InlineContract;
  contractRef?: string;
}
interface Identity {
  name: string;
  description: string;
  order: number;
}
//#endregion
//#region ../aetheria-runtime/src/facts.d.ts
/**
 * What the world says, supplied by the host or the CLI edge. The validator reads no file and runs
 * no code to learn any of it. A key left out (`undefined`) is a fact not supplied, and is refused
 * by name when the composition needs it; `null` means "looked and found nothing".
 */
interface Facts {
  /** The composition being activated. */
  composition: string;
  /** The host doing the validating. M02 supplies `agent` only. */
  host: Host;
  /** Build-time allowlist of module entries. */
  allowlist?: readonly string[];
  /** Names of the built-in tools of the host (e.g. Pi's `read`, `write`). */
  builtinTools?: readonly string[];
  /** Package name -> its installed manifest's version, read from the installed package. */
  installed?: Readonly<Record<string, {
    version: string;
  } | null>>;
  /** Artifact id -> the stamp the build actually produced. */
  artifactStamps?: Readonly<Record<string, string>>;
  /** Objective id (`M04`) -> the receiving design's repository path and its `##` headings, or null if absent. */
  designs?: Readonly<Record<string, {
    path: string;
    headings: readonly string[];
  } | null>>;
}
//#endregion
//#region ../aetheria-runtime/src/validate.d.ts
interface ResolvedPin {
  label: string;
  package: string;
  pinned: string;
  installed: string;
  /** `manifest` or `module:<id>` */
  declaredBy: string;
}
interface EffectiveComposition {
  id: string;
  /** Root first. */
  chain: string[];
  identity: Identity;
  host: Host;
  /** Selected modules in selection order, which is also the extension order. */
  modules: ModuleDescriptor[];
  /** Dependency order: every module after what it requires. */
  activationOrder: string[];
  pins: ResolvedPin[];
  stamps: {
    artifact: string;
    stamp: string;
  }[];
}
type Validation = {
  outcome: 'valid';
  effective: EffectiveComposition;
} | {
  outcome: 'refused';
  faults: Fault[];
};
declare function compareFaults(a: Fault, b: Fault): number;
/**
 * Validate a raw manifest for `facts.composition`. Never throws on malformed input, imports and
 * starts nothing. Returns the effective composition, or every fault in a deterministic order.
 */
declare function validate(raw: unknown, facts: Facts): Validation;
//#endregion
//#region ../aetheria-runtime/src/digest.d.ts
declare const DIGEST_VERSION = 1;
interface DigestReport {
  version: number;
  algorithm: 'sha256';
  /** `sha256:<hex>` */
  value: string;
  /** Per-module digests, to find which module differs between two hosts. */
  modules: {
    id: string;
    host: string;
    digest: string;
  }[];
  installed: Record<string, string>;
  stamps: Record<string, string>;
  extensionOrder: string[];
  excluded: {
    module: string;
    field: string;
    reason: 'secret' | 'machine-path';
  }[];
}
declare function computeDigest(effective: EffectiveComposition): DigestReport;
//#endregion
//#region ../aetheria-runtime/src/evaluate.d.ts
type Evaluation = {
  outcome: 'valid';
  effective: EffectiveComposition;
  digest: DigestReport;
} | {
  outcome: 'refused';
  faults: Fault[];
};
/** Validate, then resolve the digest. A refused composition has no digest. */
declare function evaluate(raw: unknown, facts: Facts): Evaluation;
//#endregion
//#region ../aetheria-runtime/src/canonical.d.ts
declare function canonicalJson(value: unknown): string;
//#endregion
//#region ../aetheria-runtime/src/disposition.d.ts
/** A hand-over of live work to another owner. It names the receiver and the receiver's confirmation. */
interface DrainTransfer {
  item: string;
  to: string;
  confirmation: string;
}
/** What one module's drain reports. All four lists are required, so an empty list is a statement. */
interface Drain {
  released: string[];
  stopped: string[];
  transferred: DrainTransfer[];
  stillLive: string[];
}
interface Entry {
  module: string;
  item: string;
}
interface TransferEntry extends Entry {
  to: string;
  confirmation: string;
}
/** The XC-7 disposal report across the host. `ok` is true only when nothing is still live and every drain was observed. */
interface DisposalReport {
  /** The reason given by the call that did the work. */
  reason: string;
  ok: boolean;
  /** Modules drained, in release order (reverse of start order). */
  order: string[];
  released: Entry[];
  stopped: Entry[];
  transferred: TransferEntry[];
  stillLive: Entry[];
  /** Drains that threw: the module's disposition is not known. */
  failed: {
    module: string;
    message: string;
  }[];
  /** Drains that returned something this contract cannot read (not four lists, an unconfirmed transfer). */
  unobserved: {
    module: string;
    why: string;
  }[];
}
/** What became of one module's drain. */
type DrainOutcome = {
  kind: 'drained';
  drain: Drain;
} | {
  kind: 'failed';
  message: string;
} | {
  kind: 'unobserved';
  why: string;
};
/** Read a drain's return value. Anything that is not exactly the contract is unobserved, never success. */
declare function readDrain(value: unknown): DrainOutcome;
/** True when a drain was observed and left nothing live. */
declare const isClean: (outcome: DrainOutcome) => boolean;
/** Collect module outcomes, given in release order, into the host's report. */
declare function buildReport(reason: string, outcomes: readonly {
  module: string;
  outcome: DrainOutcome;
}[]): DisposalReport;
//#endregion
//#region ../aetheria-runtime/src/lifecycle.d.ts
/** What a module supplies: how to start, and its drain behavior (what it owns and how it lets go). */
interface Activation {
  /** Make the module's effects. May reject; a rejected start is drained like a completed one. */
  start(context: {
    id: string;
  }): Promise<void> | void;
  /** Release, stop or transfer everything this module owns, however far its start got. Called at most once. */
  drain(reason: string): Promise<unknown> | unknown;
}
type ModuleState = 'registered' | 'starting' | 'running' | 'failed' | 'skipped' | 'disposed';
/** The typed registration of a module (XC-4). */
interface ModuleHandle {
  readonly id: string;
  readonly state: ModuleState;
}
interface ModuleStatus {
  id: string;
  required: boolean;
  state: ModuleState;
  /** Why a module is `failed` or `skipped`. */
  failure?: string;
}
type StartResult = {
  outcome: 'started';
  activationOrder: string[];
  modules: ModuleStatus[];
  digest: Extract<Evaluation, {
    outcome: 'valid';
  }>['digest'];
} |
/** Refused before any module was called. */
{
  outcome: 'refused';
  faults: Fault[];
} |
/** A required module failed after effects; everything started was rolled back and `disposal` says what happened. */
{
  outcome: 'failed';
  cause: {
    module: string;
    message: string;
  };
  modules: ModuleStatus[];
  disposal: DisposalReport;
} |
/** `dispose` was called during start; everything started was disposed before this was returned. */
{
  outcome: 'stopped';
  reason: string;
  modules: ModuleStatus[];
  disposal: DisposalReport;
};
type LifecycleErrorCode = 'duplicate-id' | 'host-mismatch' | 'host-closed' | 'bad-activation' | 'reason-required';
declare class LifecycleError extends Error {
  readonly code: LifecycleErrorCode;
  constructor(code: LifecycleErrorCode, message: string);
}
type Phase = 'open' | 'starting' | 'started' | 'disposed';
declare class LifecycleHost {
  #private;
  readonly kind: Host;
  constructor(kind: Host);
  register(descriptor: ModuleDescriptor, activation: Activation): ModuleHandle;
  status(): {
    phase: Phase;
    modules: ModuleStatus[];
  };
  start(raw: unknown, facts: Facts): Promise<StartResult>;
  /** Release everything in reverse start order. The first call does the work; later calls return its report. */
  dispose(reason: string): Promise<DisposalReport>;
}
declare const createHost: (options: {
  host: Host;
}) => LifecycleHost;
declare const register: (host: LifecycleHost, descriptor: ModuleDescriptor, activation: Activation) => ModuleHandle;
declare const start: (host: LifecycleHost, raw: unknown, facts: Facts) => Promise<StartResult>;
declare const dispose: (host: LifecycleHost, reason: string) => Promise<DisposalReport>;
declare const hostStatus: (host: LifecycleHost) => ReturnType<LifecycleHost["status"]>;
//#endregion
//#region src/backend/index.d.ts
/** What a Backend may do with the identity store: look a session's record up. It cannot stage, activate, retire, discard or sweep. */
interface IdentityReader {
  read(sessionId: string): StoreRead;
}
/**
 * The read-only view of the sole writer's store under `stateRoot`. Nothing is created or changed by reading: absent folders read as
 * absent, and a corrupt or misfiled record is reported, never repaired. The writer's mutating methods are not reachable from the value
 * this returns, so a Backend cannot become a second XC-1 writer.
 */
declare function createIdentityReader(options: {
  readonly stateRoot: string;
}): IdentityReader;
//#endregion
export { AbsentObservation, AbsentTarget, type Activation, type Authority, type AuthoritySource, CHILD_FORBIDDEN, CODE_REGISTRY, COVERAGE, COVERAGE_FIELDS, type CallerIdentity, type Chain, type ChainConfig, type ChainOptions, CleanSuccess, Code, CodeEntry, type CollectInput, type CollectedChain, type CommittedFile, type CoordinationCheck, type CoordinationCheckInput, type CoordinationPort, type CoordinationRecord, type CoordinationRecordInput, CoverageRow, DEFAULT_LIMITS, DEFAULT_MAX_BYTES, DEFAULT_MAX_LINES, DEFAULT_MAX_LINE_LENGTH, DEFAULT_SETTINGS_PATHS, DIGEST_VERSION, DanglingLink, type DeclaredExtensionSet, type DeliveredFrames, type DigestReport, type DisposalReport, type Drain, type DrainOutcome, type DrainTransfer, DropTarget, type EffectiveComposition, type Entry, type Evaluation, ExistingFile, type ExtensionObservation, type Facts, type Frame, type FrameFile, type FsInfo, GENERIC_DELEGATION, GLOBAL_DIR, GuaranteeId, type Guarded, GuardedOutcome, CODES as IDENTITY_CODES, type IdentityPorts, IdentityReader, type IdentityRecord, KERNEL_VERSION, type Kind, LifecycleError, type LifecycleErrorCode, LifecycleHost, LinkLoop, type ModuleHandle, type ModuleState, type ModuleStatus, type MutationAuthorization, type MutationBegin, type MutationCompletion, type MutationGuard, type MutationMode, type MutationNotice, type MutationOperation, type MutationPorts, type MutationRefusal, MutationRefusedError, type MutationRequest, NotAFile, ObservationRegistry, OutcomeClass, type PathRuleInput, type ProjectFacts, ReadObservation, type ReadinessCode, ReadinessError, type ReadinessFs, type ReadinessPort, type RecordResult, RefusalCode, Resolution, type ResolvedPin, type RoleDefinition, type RoleOrigin, SHELL_STATEMENT, STORE_FORMAT_VERSION, type SessionObservations, type SettingsPaths, type StartResult, type StoreRead, TextWindow, TextWindowOptions, type TransferEntry, Truncation, type UnavailableReason, UnstableReadError, type Validation, Verdict, VersionToken, WriteRecord, authorize, buildReport, canonicalJson, chainConfig, cleanSuccess, codeEntry, codeMentions, collectChain, compareFaults, computeDigest, coverageProblems, coverageRow, coverageSentence, createHost, createIdentityReader, createMutationGuard, createObservationRegistry, createSessionObservations, dispose, docCodeProblems, docCoverageProblems, endOfFileFooter, evaluate, extensionSetProblem, formatSize, formatTextWindow, frameId, hostStatus, identityOf, isClean, launchedExtensions, lineCutNote, missingFrames, outcomeFor, projectRootFor, readDrain, refusalOf, register, removalFrame, renderOutcome, renderVerdict, requiredFrames, runAuthorized, start, unavailableBoard, unregisteredCodeMentions, validate, validateProject, validateRecord };