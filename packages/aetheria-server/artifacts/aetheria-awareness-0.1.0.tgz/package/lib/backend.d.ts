import { Dirent } from "node:fs";
//#region ../aetheria-resources/src/identity/schema.d.ts
declare const KERNEL_VERSION = "0.1.0";
/** Why a record or an identity cannot be used. `AUTH_RETIRE_REFUSED` belongs to the store API and is not here. */
declare const CODES: readonly string[];
type Kind = 'main' | 'child';
type AuthoritySource = 'main' | 'role' | 'spawn-explicit';
type RoleOrigin = 'checkout' | 'home';
/** The complete persisted fact set. Rule digests, depth, project and authority are never in it. */
interface IdentityRecord {
  readonly sessionId: string;
  readonly kind: Kind;
  readonly rootSessionId: string;
  readonly parentChain: readonly string[];
  readonly role: string | null;
  readonly roleOrigin: RoleOrigin | null;
  readonly roleDigest: string | null;
  readonly authoritySource: AuthoritySource;
  readonly explicitAllow?: readonly string[];
}
type RecordResult = {
  readonly ok: true;
  readonly record: IdentityRecord;
} | {
  readonly ok: false;
  readonly code: 'AUTH_IDENTITY_INVALID';
  readonly problems: readonly string[];
};
/**
 * Validate a stored record against the three valid combinations. `depth` may be supplied only as a check: it must equal
 * `parentChain.length` and is dropped from the result (it is derived at every start). Any other unknown field is invalid.
 */
declare function validateRecord(input: unknown): RecordResult;
interface SettingsPaths {
  readonly vault: string;
  readonly cycles: string;
  readonly docs: string;
}
interface ProjectFacts {
  readonly root: string;
  readonly place: 'home' | 'foreign';
  readonly settingsPaths: SettingsPaths;
}
/** The ported settings defaults (DSH `settings.mjs`): relative, slash-ended folders. */
declare const DEFAULT_SETTINGS_PATHS: SettingsPaths;
/** Check what a project resolver returned; the identity never carries an unchecked project. */
declare function validateProject(input: unknown): {
  ok: true;
  project: ProjectFacts;
} | {
  ok: false;
  problems: string[];
};
//#endregion
//#region ../aetheria-resources/src/kernel/role-schema.d.ts
/** Generic delegation tools a child's own layer adds; a role may not declare them (declared and matched identity would differ). */
declare const GENERIC_DELEGATION: ReadonlySet<string>;
interface Route {
  readonly provider: string;
  readonly model: string;
  readonly effort: string;
}
interface RoleBinding {
  readonly tool: string;
  readonly routes: Route[];
  readonly tools: string[];
  readonly maxDepth: number;
  readonly background: 'one-shot' | 'continuable';
  readonly skills: string[];
}
//#endregion
//#region ../aetheria-resources/src/identity/resolve.d.ts
/**
 * Capabilities no child ever holds: the workflow tool and the goal tools (design C5, D13; names contingent on M07). They are registered in no child's
 * list, and a child that reaches one anyway is refused with `AUTH_TOOL_NOT_ALLOWED`, whatever its allow-list says.
 */
declare const CHILD_FORBIDDEN: ReadonlySet<string>;
type StoreRead = {
  status: 'absent';
} | {
  status: 'pending';
} | {
  status: 'active';
  record: unknown;
} | {
  status: 'retired';
  reason?: string;
} | {
  status: 'corrupt';
  problem: string;
};
interface RoleDefinition {
  readonly name: string;
  readonly projectLayer: boolean;
  readonly allow: readonly string[];
  readonly maxDepth: number;
  readonly background: string;
  readonly origin: 'checkout' | 'home';
  readonly digest: string | null;
}
interface IdentityPorts {
  read(sessionId: string): StoreRead;
  readonly roles: {
    lookup(role: string): RoleDefinition | null;
    roleOfTool(tool: string): RoleDefinition | null;
  };
  project(workingFolder: string): unknown;
  /** The composition's full callable tool set; a main session's authority. */
  readonly callable: readonly string[];
  /**
   * M05's derivation of a spawn-explicit child's authority (Plan step 11). Injected, never built in: absent, a spawn-explicit identity is unavailable. The resolver reads the parent's
   * CURRENT authority itself, asks this port, and then caps the answer, so the port can narrow but never widen (see `identityOf`).
   */
  readonly explicit?: ExplicitAuthorityPort;
}
/** What M05's port is given: the child's own stored record and its parent's current, resolver-issued authority. */
interface ExplicitAuthorityInput {
  readonly record: IdentityRecord;
  readonly parent: Authority;
}
type ExplicitDerivation = {
  readonly ok: true;
  readonly callable: readonly string[];
  readonly maxDepth: number;
  readonly background: string;
} | {
  readonly ok: false;
  readonly detail?: unknown;
};
interface ExplicitAuthorityPort {
  derive(input: ExplicitAuthorityInput): ExplicitDerivation;
}
interface Authority {
  readonly callable: readonly string[];
  readonly maxDepth: number;
  readonly background: string;
  readonly projectLayerAllowed: boolean;
}
interface CallerIdentity extends IdentityRecord {
  readonly depth: number;
  readonly project: ProjectFacts;
  readonly issuedBy: string;
  readonly authority: Authority;
}
type UnavailableReason = 'missing-record' | 'invalid-record' | 'retired' | 'role-removed' | 'authority-unavailable';
type Resolution = {
  readonly ok: true;
  readonly identity: CallerIdentity;
} | {
  readonly ok: false;
  readonly reason: UnavailableReason;
  readonly code: string;
  readonly detail: unknown;
  readonly record?: IdentityRecord;
};
/** Resolve a session's caller identity from its stored record, recomputing depth, project, issuedBy and authority. */
declare function identityOf(ports: IdentityPorts, sessionId: string, workingFolder: string): Resolution;
type Verdict = {
  readonly allowed: true;
} | {
  readonly allowed: false;
  readonly code: string;
  readonly reason: string;
};
/**
 * May this resolved identity run this tool? The verdict depends only on the resolution, the tool name and the catalog: `input`
 * is accepted so every caller passes the same arguments, and is never read, so frozen, mutated or hostile input cannot change it.
 * Read and messaging callers decide which tools to ask about; this predicate never turns unknown authority into main.
 *
 * Depth: starting a role is gated by the TARGET role's `maxDepth` (the child would sit at `depth + 1`, so the caller's depth must be
 * below it; DSH roles.test.mjs:559, :695). A generic delegation tool, reachable only at depth 0, is gated by the caller's own
 * authority `maxDepth`.
 */
declare function authorize(ports: Pick<IdentityPorts, 'roles'>, resolution: Resolution | undefined, toolName: string, _input?: unknown): Verdict;
type Guarded<T> = {
  readonly ran: true;
  readonly value: T;
} | {
  readonly ran: false;
  readonly verdict: Verdict & {
    readonly allowed: false;
  };
};
/**
 * Run an effect only if the predicate allows the tool. The one wrapper an Aetheria-owned executor calls inside its `execute`: a refusal returns the
 * verdict and the effect is never called, so nothing changes. The effect receives the input it was given, unchanged by this function.
 */
declare function runAuthorized<T>(ports: Pick<IdentityPorts, 'roles'>, resolution: Resolution | undefined, toolName: string, input: unknown, effect: (input: unknown) => T): Guarded<T>;
//#endregion
//#region ../aetheria-resources/src/identity/store.d.ts
declare const STORE_FORMAT_VERSION = 1;
//#endregion
//#region ../aetheria-resources/src/kernel/fs.d.ts
interface FsInfo$1 {
  readonly type: 'file' | 'directory' | 'symlink' | 'other';
  readonly size?: number | undefined;
  readonly version?: string | undefined;
}
interface FsPort {
  /** Metadata of the path itself (links not followed); undefined when absent. */
  lstat(path: string): Promise<FsInfo$1 | undefined>;
  /** The real path of `path`; a link whose target is missing resolves to itself. */
  resolve(path: string): Promise<string>;
  processPath(target: string): string;
  /** Metadata of the target; undefined when absent. */
  stat(target: string, signal?: AbortSignal): Promise<FsInfo$1 | undefined>;
  /** At most `maxBytes`; rejects with code FS_TOO_LARGE when the file is longer. */
  readBytes(target: string, signal: AbortSignal | undefined, maxBytes: number): Promise<Uint8Array>;
  /** The names in a folder; `type` is the entry's kind with links followed (a dangling link is `other`), when the port knows it. */
  listDir(target: string, signal?: AbortSignal): Promise<ReadonlyArray<{
    readonly name: string;
    readonly type?: FsInfo$1['type'] | undefined;
  }>>;
}
interface SyncFs {
  readdirSync(path: string, options: {
    withFileTypes: true;
  }): Dirent[];
  statSync(path: string): {
    isDirectory(): boolean;
    isFile(): boolean;
  };
  readFileSync(path: string, encoding?: 'utf8'): string | Uint8Array;
}
/** The asynchronous port over Node's `fs`: `lstat` answers undefined for an absent path, a target is its real path. */
declare const nodeFs: FsPort;
//#endregion
//#region ../aetheria-resources/src/identity/project.d.ts
type DerivedProject = {
  readonly ok: true;
  readonly project: ProjectFacts;
  readonly warnings: readonly string[];
} | {
  readonly ok: false;
  readonly problems: readonly string[];
  readonly warnings: readonly string[];
};
declare function deriveProject(fs: FsPort, cwd: string, checkout: string): Promise<DerivedProject>;
//#endregion
//#region src/contracts/coverage.d.ts
type GuaranteeId = 'A6' | 'T1' | 'H5' | 'H4';
interface CoverageRow {
  readonly id: GuaranteeId;
  readonly name: string;
  readonly enforcedAt: string;
  readonly fails: string;
  readonly covers: string;
  readonly doesNotCover: string;
}
declare const COVERAGE_FIELDS: readonly ["enforcedAt", "fails", "covers", "doesNotCover"];
declare const COVERAGE: readonly CoverageRow[];
declare const SHELL_STATEMENT = "Shell writes are visibility only, not guarded: the tracker's git status snapshots show changed paths and prevent nothing.";
declare const coverageRow: (id: string) => CoverageRow;
declare const coverageSentence: (id: string) => string;
//#endregion
//#region src/contracts/checks.d.ts
declare const coverageProblems: (rows: readonly CoverageRow[]) => string[];
declare const docCoverageProblems: (doc: string) => string[];
declare const docCodeProblems: (doc: string) => string[];
declare const codeMentions: (source: string) => string[];
declare const unregisteredCodeMentions: (source: string) => string[];
//#endregion
//#region src/contracts/codes.d.ts
type OutcomeClass = 'refused-unchanged' | 'failed-unchanged' | 'applied-with-warning';
interface CodeEntry<C extends string = string> {
  readonly code: C;
  readonly guarantee: GuaranteeId;
  readonly outcomeClass: OutcomeClass;
  readonly meaning: string;
  readonly source: string;
}
declare const CODE_REGISTRY: readonly [CodeEntry<"READINESS_NOT_LOADED">, CodeEntry<"READINESS_CHANGED">, CodeEntry<"READINESS_RETARGETED">, CodeEntry<"READINESS_UNSUPPORTED_SCOPE">, CodeEntry<"READINESS_ANCESTOR_LIMIT">, CodeEntry<"READINESS_UNREADABLE">, CodeEntry<"READINESS_TOO_LARGE">, CodeEntry<"READINESS_UNSTABLE">, CodeEntry<"T1_NOT_OBSERVED">, CodeEntry<"T1_STALE">, CodeEntry<"T1_EXISTS">, CodeEntry<"T1_NOT_FOUND">, CodeEntry<"T1_RETARGETED">, CodeEntry<"T1_DANGLING_LINK">, CodeEntry<"T1_WRITE_BUSY">, CodeEntry<"T1_IS_DIRECTORY">, CodeEntry<"T1_LINK_LOOP">, CodeEntry<"T1_OBSERVATION_DROPPED">, CodeEntry<"WRITE_FAILED">, CodeEntry<"AWARENESS_HELD">, CodeEntry<"AWARENESS_LEFTOVER">, CodeEntry<"AWARENESS_ASSIGNED">, CodeEntry<"AWARENESS_UNAVAILABLE">, CodeEntry<"AWARENESS_OVERLAP">, CodeEntry<"AWARENESS_INVALID">, CodeEntry<"AWARENESS_STALE">, CodeEntry<"AWARENESS_UNVERIFIED">, CodeEntry<"AWARENESS_NO_SESSION">, CodeEntry<"AWARENESS_NO_AGENT">, CodeEntry<"AWARENESS_NOT_MAIN">, CodeEntry<"COORDINATION_UNAVAILABLE">];
type Code = (typeof CODE_REGISTRY)[number]['code'];
declare const codeEntry: (code: string) => CodeEntry<Code>;
//#endregion
//#region src/contracts/outcome.d.ts
interface GuardedOutcome {
  readonly code: Code;
  readonly outcomeClass: OutcomeClass;
  readonly coverage: string;
}
interface CleanSuccess {
  readonly clean: true;
}
declare const cleanSuccess: () => CleanSuccess;
declare const outcomeFor: (code: string) => GuardedOutcome;
declare const renderOutcome: (outcome: GuardedOutcome, detail?: string) => string;
//#endregion
//#region src/observation/types.d.ts
/** The version token (D6): the content digest decides; size and modification time are reported, and size is a quick pre-filter that can only refuse. */
interface VersionToken {
  readonly digest: string;
  readonly size: number;
  readonly mtimeMs: number;
}
/** What the host reports about one spelling of a target at one moment. */
type Resolution$1 = ExistingFile | AbsentTarget | DanglingLink | LinkLoop | NotAFile;
interface ExistingFile {
  readonly kind: 'file';
  /** The absolute, lexical spelling the caller used (symlinks and case untouched). */
  readonly spelling: string;
  /** The real path of the file: every link followed. */
  readonly canonicalPath: string;
  /** File identity (D6): device and inode as decimal strings (64-bit safe). */
  readonly dev: string;
  readonly ino: string;
  readonly size: number;
  readonly mtimeMs: number;
  /** Streams the content digest of the file as inspected. No size cap. Rejects with `UnstableReadError` when the file changed while it was read. */
  readonly digest: () => Promise<string>;
}
interface AbsentTarget {
  readonly kind: 'absent';
  readonly spelling: string;
  /** Real path of the deepest existing ancestor plus the remaining names: the identity of an absent file. */
  readonly canonicalPath: string;
}
interface DanglingLink {
  readonly kind: 'dangling-link';
  readonly spelling: string;
}
interface LinkLoop {
  readonly kind: 'link-loop';
  readonly spelling: string;
}
/** A directory, or another file that is not a regular file (a pipe, a device): read, write and edit act on regular files only. */
interface NotAFile {
  readonly kind: 'directory';
  readonly spelling: string;
  readonly canonicalPath: string;
  readonly notRegular?: true;
}
/** What a successful read tells the session. `token` is the digest/size/mtime of the bytes the read RETURNED. */
interface ReadObservation {
  readonly spelling: string;
  readonly canonicalPath: string;
  readonly dev: string;
  readonly ino: string;
  readonly token: VersionToken;
}
interface AbsentObservation {
  readonly spelling: string;
  readonly canonicalPath: string;
}
/** A session's own successful write: the new file's identity and token, and the identity it replaced (its entry is dropped). */
interface WriteRecord extends ReadObservation {
  readonly replaced?: {
    readonly dev: string;
    readonly ino: string;
  };
}
interface DropTarget {
  readonly spelling?: string;
  readonly canonicalPath?: string;
}
type RefusalCode = 'T1_NOT_OBSERVED' | 'T1_STALE' | 'T1_EXISTS' | 'T1_NOT_FOUND' | 'T1_RETARGETED' | 'T1_DANGLING_LINK' | 'T1_LINK_LOOP' | 'T1_IS_DIRECTORY';
type Verdict$1 = {
  readonly ok: true;
  readonly mode: 'replace' | 'create';
  readonly observed: VersionToken | null;
} | {
  readonly ok: false;
  readonly code: Extract<Code, RefusalCode>;
  readonly detail: string;
  readonly outcome: GuardedOutcome;
};
/** Thrown by a digest or stable read when the bytes and the file's metadata could belong to different versions. */
declare class UnstableReadError extends Error {
  readonly code = "UNSTABLE_READ";
  constructor(message: string);
}
//#endregion
//#region src/observation/session.d.ts
interface SessionObservations {
  /** Grant after a guarded `read` succeeded with the bytes it returned. Only `read` calls this; an edit's own internal reads never do. */
  observe(read: ReadObservation): void;
  /** Record that the session saw the target absent, so a later creation is refused T1_EXISTS. */
  observeAbsent(target: AbsentObservation): void;
  checkForWrite(resolution: Resolution$1): Promise<Verdict$1>;
  checkForEdit(resolution: Resolution$1): Promise<Verdict$1>;
  /** The session's own successful write: replace the entry with the new file's identity and token. */
  recordAfterWrite(write: WriteRecord): void;
  /** Forget a target (observation-update failed, D17): the next check is T1_NOT_OBSERVED until an explicit read. */
  drop(target: DropTarget): void;
  clear(): void;
  /** Counts only, for diagnostics and tests: never content, paths or digests. */
  snapshot(): {
    files: number;
    spellings: number;
    absent: number;
  };
}
declare function createSessionObservations(): SessionObservations;
/** The text a model reads for a refused verdict (the code, the cause, "native write/edit only", the guarantee's limit); null for an allowed one. */
declare const renderVerdict: (verdict: Verdict$1) => string | null;
//#endregion
//#region src/observation/registry.d.ts
interface ObservationRegistry {
  /** The session's state, created empty on first use. The same id always gives the same object until `dispose`. */
  forSession(sessionId: string): SessionObservations;
  /** Clear and forget one session (its disposal). */
  dispose(sessionId: string): void;
  /** Clear every session (host disposal). */
  clearAll(): void;
}
declare function createObservationRegistry(): ObservationRegistry;
//#endregion
//#region src/read/window.d.ts
declare const DEFAULT_MAX_LINES = 2000;
declare const DEFAULT_MAX_BYTES: number;
/** Today's configured value (preset `readMaxLineLength: 10000`), carried as a parameter the user may change. */
declare const DEFAULT_MAX_LINE_LENGTH = 10000;
interface Truncation {
  readonly content: string;
  readonly truncated: boolean;
  readonly truncatedBy: 'lines' | 'bytes' | null;
  readonly totalLines: number;
  readonly totalBytes: number;
  readonly outputLines: number;
  readonly outputBytes: number;
  readonly lastLinePartial: boolean;
  readonly firstLineExceedsLimit: boolean;
  readonly maxLines: number;
  readonly maxBytes: number;
}
interface TextWindowOptions {
  /** 1-indexed first line. Absent, 0 and negative values start at line 1 (as Pi does). */
  readonly offset?: number;
  readonly limit?: number;
  readonly maxLineLength?: number;
  readonly maxLines?: number;
  readonly maxBytes?: number;
  /** The path as the model gave it; it only appears in the "line exceeds the byte limit" hint. */
  readonly path?: string;
}
interface TextWindow {
  /** What the tool returns as text. */
  readonly text: string;
  /** True when the start line was past the end of the file: `text` is then only the footer. */
  readonly pastEnd: boolean;
  /** Lines in the file, counted as Pi counts them (a final newline does not add one). */
  readonly totalLines: number;
  /** Present when the byte or line cap applied (Pi's `details.truncation`). */
  readonly truncation?: Truncation;
}
declare const endOfFileFooter: (totalLines: number) => string;
declare const lineCutNote: (maxLineLength: number) => string;
declare const formatSize: (bytes: number) => string;
declare function formatTextWindow(input: string | Uint8Array, options?: TextWindowOptions): TextWindow;
//#endregion
//#region src/readiness/types.d.ts
interface FsInfo {
  readonly type: 'file' | 'directory' | 'symlink' | 'other';
  readonly size?: number | undefined;
  readonly version?: string | undefined;
}
interface ReadinessFs {
  /** Metadata of the path itself (links not followed); undefined when absent. */
  lstat(path: string): Promise<FsInfo | undefined>;
  /** The real path of `path`; a link whose target is missing resolves to itself. */
  resolve(path: string): Promise<string>;
  processPath(target: string): string;
  /** Metadata of the target; undefined when absent. */
  stat(target: string, signal?: AbortSignal): Promise<FsInfo | undefined>;
  /** At most `maxBytes`; rejects with code FS_TOO_LARGE when the file is longer. */
  readBytes(target: string, signal: AbortSignal | undefined, maxBytes: number): Promise<Uint8Array>;
  listDir(target: string, signal?: AbortSignal): Promise<ReadonlyArray<{
    readonly name: string;
    readonly type?: FsInfo['type'] | undefined;
  }>>;
}
type ReadinessCode = Extract<Code, 'READINESS_NOT_LOADED' | 'READINESS_CHANGED' | 'READINESS_RETARGETED' | 'READINESS_UNSUPPORTED_SCOPE' | 'READINESS_ANCESTOR_LIMIT' | 'READINESS_UNREADABLE' | 'READINESS_TOO_LARGE' | 'READINESS_UNSTABLE'>;
/** A readiness failure that must leave the target unchanged. `code` is a registered READINESS_* code. */
declare class ReadinessError extends Error {
  readonly code: ReadinessCode;
  constructor(message: string, code: ReadinessCode);
}
interface ChainConfig {
  readonly sha256Hex: (text: string) => string;
  /** Instruction file names looked for in every directory of the chain, in order, then the local ones. Exact names only. */
  readonly candidates: readonly string[];
  readonly markers: readonly string[];
  readonly maxSourceBytes: number;
  readonly maxContextBytes: number;
  readonly maxAncestors: number;
  /** An absolute file read once per chain as the 'user-global' frame; none by default. */
  readonly globalFile: string | undefined;
  readonly globalLabel: string | undefined;
}
/** One path rule that M03's `ruleSources(identity, {targetPath})` says governs the target, with the means to read ITS text (never a same-path read). */
interface PathRuleInput {
  /** The absolute directory the rule governs. */
  readonly dir: string;
  /** What the model sees. */
  readonly label: string;
  /** The digest M03's query returned for the rule. */
  readonly digest: string;
  /** M03's loader: the rule's text and its digest, or the reason it cannot be read. */
  readonly load: (signal?: AbortSignal) => Promise<{
    readonly body: string;
    readonly digest: string;
  } | {
    readonly problem: string;
  }>;
}
interface FrameFile {
  readonly path: string;
  readonly version: string;
}
/** One directory's complete guidance as the model sees it. `digest` is `sha256:<hex>` of exactly `text`; `id` is the projection block id. */
interface Frame {
  readonly dir: string;
  readonly id: string;
  readonly text: string;
  readonly digest: string;
  readonly files: readonly FrameFile[];
}
interface Chain {
  readonly target: string;
  /** The hash the chain was built with (removal frames use it). */
  readonly sha256Hex: (text: string) => string;
  readonly frames: readonly Frame[];
  /** Every directory the target is governed through, global first. */
  readonly directories: readonly string[];
  /** Absent candidates by directory (paths relative to the session's project root). */
  readonly absent: ReadonlyMap<string, readonly string[]>;
  /** Path rules that contributed, with the digest they were read at. */
  readonly ruleDigests: readonly {
    readonly label: string;
    readonly digest: string;
  }[];
}
/** The digest last delivered for each directory (or 'user-global'). A required frame equal to it needs no new delivery. */
type DeliveredFrames = ReadonlyMap<string, string>;
//#endregion
//#region src/readiness/chain.d.ts
declare const GLOBAL_DIR = "user-global";
declare const DEFAULT_LIMITS: Readonly<{
  maxSourceBytes: 65536;
  maxContextBytes: 65536;
  maxAncestors: 128;
}>;
interface ChainOptions {
  readonly sha256Hex: (text: string) => string;
  readonly candidates?: readonly string[];
  readonly localCandidates?: readonly string[];
  readonly markers?: readonly string[];
  readonly maxSourceBytes?: number;
  readonly maxContextBytes?: number;
  readonly maxAncestors?: number;
  readonly globalFile?: string | undefined;
  readonly globalLabel?: string | undefined;
}
/** The chain settings: names, markers, the DSH limits, an optional global file. Candidate names are plain file names, never paths. */
declare function chainConfig(options: ChainOptions): ChainConfig;
/** The project root for a directory: the nearest ancestor holding a marker (ported from M03's place.ts, which ported DSH's). */
declare function projectRootFor(fs: ReadinessFs, dir: string, cwd: string, config: ChainConfig): Promise<string>;
/** The block id of the frame for a directory: stable per directory so a later frame supersedes an earlier one. */
declare const frameId: (dir: string, sha256Hex: (text: string) => string) => string;
/** A directory whose instructions were shown earlier and now has none. */
declare function removalFrame(dir: string, sha256Hex: (text: string) => string): Frame;
interface CollectInput {
  readonly filePath: unknown;
  readonly cwd: string;
  readonly config: ChainConfig;
  readonly signal?: AbortSignal | undefined;
  /** The path rules M03 says govern the target, each with its own loader. */
  readonly pathRules?: readonly PathRuleInput[] | undefined;
  /**
   * The trust gate. When true, project files (instruction candidates in the chain's directories and `.agents/rules/*.md` of each project root)
   * are DETECTED and listed in `withheld` but never read or framed. The global file is not a project file and is still read.
   */
  readonly withholdProject?: boolean | undefined;
}
interface CollectedChain extends Chain {
  /** Project files present but not read because the trust gate withheld them. */
  readonly withheld: readonly string[];
}
/**
 * Collect the governing chain for one mutation target. Returns the ordered frames — one per directory with at least one present candidate —
 * each with a digest over its rendered text.
 */
declare function collectChain(fs: ReadinessFs, input: CollectInput): Promise<CollectedChain>;
/**
 * The frames that must be the latest delivered, per directory, for a target: every present frame, and a removal frame for each directory in the
 * chain that now has no instructions but whose earlier frame this engine delivered.
 */
declare function requiredFrames(chain: Chain, delivered: DeliveredFrames): Frame[];
/** Required frames whose digest is not the one last delivered for their directory. */
declare function missingFrames(chain: Chain, delivered: DeliveredFrames): Frame[];
//#endregion
//#region src/readiness/extension-set.d.ts
interface DeclaredExtensionSet {
  /** Aetheria's bundle: the first `--extension`. */
  readonly bundlePath: string;
  /** T3's injected extension: the second and last `--extension`; it must also be what T3 recorded in T3_PI_MCP_EXTENSION_PATH. */
  readonly t3ExtensionPath: string;
  /** T3's fixed file name for its injected extension (apps/t3code/packages/provider-pi/src/server/mcpExtensionSource.ts). */
  readonly t3ExtensionFilename: string;
  /** The isolated Pi home (PI_CODING_AGENT_DIR). Its `extensions` folder must hold nothing. */
  readonly piHome: string;
}
/** What the Pi process was launched with: its argument vector and environment. */
interface ExtensionObservation {
  readonly args: readonly string[];
  readonly env: Readonly<Record<string, string | undefined>>;
}
/** The `--extension` / `-e` values in launch order, in all four spellings Pi accepts. */
declare function launchedExtensions(args: readonly string[]): string[];
/**
 * Why this launch is not the declared extension set, or null when it is. The launch must carry `--no-extensions` (the enforcement; see the header).
 * With `options.fs`, also requires the isolated Pi home's `extensions` folder and the working folder's `.pi/extensions` to hold nothing, and the
 * home's `settings.json` and the working folder's `.pi/settings.json` to declare no `extensions` or `packages` (defense in depth, a snapshot).
 */
declare function extensionSetProblem(observed: ExtensionObservation | undefined, declared: DeclaredExtensionSet, options?: {
  readonly fs?: ReadinessFs | undefined;
  readonly cwd?: string | undefined;
}): Promise<string | null>;
//#endregion
//#region src/mutation/coordination.d.ts
type MutationMode = 'create' | 'replace';
interface CoordinationCheckInput {
  readonly operation: 'write' | 'edit';
  readonly toolCallId: string;
  readonly spelling: string;
  readonly canonicalPath: string;
  readonly mode: MutationMode;
  readonly identity: unknown;
  readonly signal?: AbortSignal | undefined;
}
type CoordinationCheck = {
  readonly status: 'allowed';
} |
/** The board refuses (a holder, a leftover, an assignment): `code` is one of the `AWARENESS_*` codes. */
{
  readonly status: 'refused';
  readonly code: Code;
  readonly detail: string;
} |
/** The board cannot be read: the write proceeds with a visible warning unless the workspace sets `failOpen: false`. */
{
  readonly status: 'unavailable';
  readonly detail: string;
};
interface CoordinationRecordInput extends CoordinationCheckInput {
  /** The size and digest of what was written. */
  readonly token: VersionToken;
}
type CoordinationRecord = {
  readonly status: 'recorded';
} | {
  readonly status: 'unavailable';
  readonly detail: string;
};
interface CoordinationPort {
  /** Before the write: may this session write here? */
  check(input: CoordinationCheckInput): Promise<CoordinationCheck>;
  /** After the write landed: record the edit. A failure never undoes the write; the sequence retries once and then warns. */
  record(input: CoordinationRecordInput): Promise<CoordinationRecord>;
}
/** The explicit adapter for a build with no board: every question is answered "unavailable", never "allowed". */
declare function unavailableBoard(reason?: string): CoordinationPort;
//#endregion
//#region src/mutation/refusal.d.ts
interface MutationRefusal {
  readonly code: Code;
  readonly outcome: GuardedOutcome;
  /** The cause alone. */
  readonly detail: string;
  /** The text a model reads. */
  readonly message: string;
}
/** A refusal or notice for a registered code; an unregistered code throws (the registry is the one vocabulary). */
declare function refusalOf(code: string, detail: string): MutationRefusal;
/** A notice that the call was applied with a warning: same shape as a refusal; its `outcome.outcomeClass` is `applied-with-warning`. */
type MutationNotice = MutationRefusal;
/** Thrown by a guarded tool for a refusal or a failed-unchanged write: the message is the C1 text and `refusal` is the structured result. */
declare class MutationRefusedError extends Error {
  readonly refusal: MutationRefusal;
  constructor(refusal: MutationRefusal);
}
//#endregion
//#region src/mutation/sequence.d.ts
type MutationOperation = 'write' | 'edit';
/** The slice of the readiness guard this sequence uses (`ReadinessGuard` satisfies it). `Grant` is the guard's own opaque grant. */
interface ReadinessPort<Grant> {
  assess(input: {
    readonly toolCallId: string;
    readonly toolName: MutationOperation;
    readonly filePath: unknown;
    readonly cwd: string;
    readonly identity: unknown;
    readonly home: boolean;
    readonly signal?: AbortSignal | undefined;
    readonly parentToolCallId?: string | null | undefined;
  }): Promise<{
    readonly granted: true;
    readonly grant: Grant;
  } | {
    readonly granted: false;
    readonly code: string;
    readonly detail: string;
  }>;
  recheck(grant: Grant, options?: {
    readonly signal?: AbortSignal | undefined;
  }): Promise<{
    readonly ok: true;
  } | {
    readonly ok: false;
    readonly code: string;
    readonly detail: string;
  }>;
  revoke(grant: Grant): void;
}
interface MutationPorts<Grant = unknown> {
  readonly readiness: ReadinessPort<Grant>;
  readonly coordination: CoordinationPort;
  /** Report what a path is now (the host's `inspectTarget`). */
  readonly inspect: (spelling: string) => Promise<Resolution$1>;
  /** D12: an unavailable board lets the write proceed with a warning (default true); `false` refuses with AWARENESS_UNAVAILABLE. Readiness and freshness never fail open. */
  readonly failOpen?: boolean;
}
interface MutationRequest {
  readonly operation: MutationOperation;
  readonly toolCallId: string;
  /** The absolute, lexical path of the FINAL arguments, resolved the way the tool factory resolves it. */
  readonly spelling: string;
  /** The path as given, for readiness. */
  readonly filePath: unknown;
  readonly cwd: string;
  readonly identity: unknown;
  readonly home: boolean;
  /** The calling session's observations. */
  readonly observations: SessionObservations;
  readonly signal?: AbortSignal | undefined;
  readonly parentToolCallId?: string | null | undefined;
}
/** What the host's commit reports after the rename or exclusive link. */
interface CommittedFile {
  readonly canonicalPath: string;
  readonly dev: string;
  readonly ino: string;
  /** Digest, size and mtime of the bytes written. */
  readonly token: VersionToken;
  /** The identity this commit replaced; defaults to the identity the check saw. */
  readonly replaced?: {
    readonly dev: string;
    readonly ino: string;
  } | null | undefined;
}
interface MutationCompletion {
  /** Applied-with-warning notices, in the order T1_OBSERVATION_DROPPED then COORDINATION_UNAVAILABLE; empty on a clean success. */
  readonly warnings: readonly MutationNotice[];
}
interface MutationAuthorization {
  readonly operation: MutationOperation;
  readonly mode: MutationMode;
  readonly spelling: string;
  /** The resolved file (never a link); for a create, the real path of its parent plus the name. */
  readonly canonicalPath: string;
  /** The token the session observed; null for a create. */
  readonly observed: VersionToken | null;
  /** The file identity the check saw (replaced by the commit); null for a create. */
  readonly replaced: {
    readonly dev: string;
    readonly ino: string;
  } | null;
  /** Whether the board answered the pre-write check. */
  readonly coordination: 'allowed' | 'unavailable';
  /** Under the lock: the canonical mapping, the readiness recheck and the observation token, in that order. Null means all three still hold. */
  reverify(options?: {
    readonly signal?: AbortSignal | undefined;
  }): Promise<MutationRefusal | null>;
  /** After the commit: update the observation, record with the board (one retry), revoke the grant. Never throws for a bookkeeping failure. */
  complete(committed: CommittedFile): Promise<MutationCompletion>;
  /** No commit happened: revoke the grant. Idempotent. */
  abandon(): void;
}
type MutationBegin = {
  readonly ok: true;
  readonly authorization: MutationAuthorization;
} | {
  readonly ok: false;
  readonly refusal: MutationRefusal;
};
interface MutationGuard {
  begin(request: MutationRequest): Promise<MutationBegin>;
}
declare function createMutationGuard<Grant>(ports: MutationPorts<Grant>): MutationGuard;
//#endregion
//#region src/shell/porcelain.d.ts
/**
 * The paths of a `git status --porcelain=v1 -z` listing, both sides of a rename or copy.
 * @param text - the NUL-separated listing.
 * @returns the paths as git printed them (relative to the git top-level), in listing order.
 */
declare function parsePorcelain(text: string): string[];
//#endregion
//#region src/shell/snapshot.d.ts
/** How long `git status` may take (ported: tracker.mjs 25). A call that takes longer is a failed snapshot. */
declare const GIT_STATUS_TIMEOUT_MS = 10000;
/** Shown beside every path a shell call newly changed. The call was observed, never guarded. */
declare const SHELL_CHANGED_LABEL = "changed via shell (not guarded)";
/** Shown when a snapshot could not be taken: whether the shell changed anything is not known. */
declare const SHELL_UNKNOWN_LABEL = "shell change unknown";
/** The Git listing of a workspace at one moment, or why there is none. */
type ShellSnapshot = {
  readonly kind: 'git';
  readonly top: string;
  readonly paths: ReadonlySet<string>;
} |
/** The workspace is not in a Git repository (or git is absent): there is nothing to compare. */
{
  readonly kind: 'outside-git';
} |
/** Git is present but did not answer (timeout, failure): the listing is unknown, which is not an empty listing. */
{
  readonly kind: 'failed';
  readonly reason: string;
};
/** What one observed shell call left behind, as far as a Git listing can tell. */
type ShellObservation = {
  readonly kind: 'changed';
  readonly label: typeof SHELL_CHANGED_LABEL;
  readonly paths: readonly string[];
} | {
  readonly kind: 'unchanged';
} |
/** The workspace is outside Git: the change, if any, appears nowhere (the coverage text says so). */
{
  readonly kind: 'outside-git';
} | {
  readonly kind: 'unknown';
  readonly label: typeof SHELL_UNKNOWN_LABEL;
  readonly reason: string;
};
declare function unknownObservation(reason: string): ShellObservation;
declare function changedObservation(paths: readonly string[]): ShellObservation;
/**
 * Compare the snapshot before a call with the one after it. The result's paths are those newly listed, sorted, not yet narrowed to the
 * workspace (the observer does that through its canonical port).
 */
declare function diffSnapshots(before: ShellSnapshot, after: ShellSnapshot): ShellObservation;
/** The lines a summary prints for an observation: one per changed path with the label, or the unknown label; nothing otherwise. */
declare function shellObservationLines(observation: ShellObservation): string[];
//#endregion
//#region src/shell/observer.d.ts
/** One shell call: its id (XC-12 pairs `begin` with `end` by it) and the canonical workspace it runs in. */
interface ShellCall {
  readonly callId: string;
  readonly workspace: string;
}
/** The XC-12-shaped surface. Both methods resolve; neither throws or rejects. */
interface ShellObserver {
  /** Take the pre snapshot. Await it before spawning the process. */
  begin(call: ShellCall): Promise<void>;
  /** Take the post snapshot and compare. Call it after the process group is reaped, whatever the shell's result. */
  end(call: ShellCall): Promise<ShellObservation>;
}
/** What the observer is supplied. */
interface ShellObserverPorts {
  /** The Git listing of the workspace now. May reject: that becomes "shell change unknown". */
  snapshot(workspace: string): Promise<ShellSnapshot>;
  /** The canonical form of a listed absolute path inside the workspace, or undefined when it is outside (then it is dropped). May reject. */
  canonical(path: string, workspace: string): Promise<string | undefined>;
  /** Told of each finished observation (the consumer: the board's summary). Its failure changes nothing. */
  record?(call: ShellCall, observation: ShellObservation): void | Promise<void>;
  /** Told of each failure inside the observer. Its failure changes nothing. */
  warn?(message: string): void;
}
declare function createShellObserver(ports: ShellObserverPorts): ShellObserver;
//#endregion
//#region src/shell/fixture.d.ts
/**
 * Run one shell call between an observer's `begin` and `end`.
 * @param run - spawns the process and resolves after its process group is reaped; its result is returned untouched.
 * @returns the shell's result and the observation (unknown when the observer failed).
 * @throws only what `run` throws, unchanged, after `end` has been attempted.
 */
declare function runObserved<T>(observer: ShellObserver, call: ShellCall, run: () => Promise<T>): Promise<{
  readonly result: T;
  readonly observation: ShellObservation;
}>;
//#endregion
//#region src/board/types.d.ts
type ClaimKind = 'file' | 'folder';
type SessionState = 'open' | 'closed';
type MarkerReason = 'closed' | 'crashed';
type DecisionKind = 'overlap' | 'leftover' | 'dependency';
interface ProcessRecord {
  pid: number;
  startedAt: number;
  presencePath: string;
}
/** Left on a holder's session when another session took a path from it, so the holder re-reads before it writes. */
interface Notice {
  path: string;
  by: string;
  state: string;
  at: number;
}
/**
 * What a session's shell commands were seen to change (M09 step 17; `board.record-shell`). Visibility only: it never governs a path, takes a
 * claim or counts as an edit, and carries no version token. `unknown` is true once a shell ran whose changes could not be observed (or the
 * list outgrew its bound). An optional field of a version-1 session, so a board without it is unchanged.
 */
interface ShellRecord {
  /** Canonical absolute paths, sorted and unique. */
  changed: string[];
  unknown: boolean;
}
interface SessionRecord {
  processId: string;
  label: string;
  goal: string;
  lastActivityAt: number;
  mainRunning: boolean;
  state: SessionState;
  closedAt?: number;
  edits: string[];
  depends: string[];
  notices?: Notice[];
  shell?: ShellRecord;
}
interface ClaimRecord {
  path: string;
  kind: ClaimKind;
  sessionId: string;
  assignee?: string;
  idea: string;
  sharedWith: string[];
  createdAt: number;
  generation: number;
}
interface InterfaceRecord {
  name: string;
  sessionId: string;
  signature: string;
  notes?: string;
  version: number;
  updatedAt: number;
}
interface MarkerRecord {
  path: string;
  sessionId: string;
  reason: MarkerReason;
  since: number;
}
interface DecisionRecord {
  id: string;
  kind: DecisionKind;
  subject: string;
  answer: string;
  notes?: string;
  askCallId: string;
  question: string;
  userAnswer: string;
  sessionId: string;
  at: number;
}
interface Board {
  version: 1;
  revision: number;
  processes: Record<string, ProcessRecord>;
  sessions: Record<string, SessionRecord>;
  claims: Record<string, ClaimRecord>;
  interfaces: Record<string, InterfaceRecord>;
  markers: Record<string, MarkerRecord>;
  decisions: DecisionRecord[];
}
/** What a claim covers: a file claim covers exactly its path; a folder claim its path and everything below by whole segments. */
interface Range {
  readonly path: string;
  readonly kind: ClaimKind;
}
//#endregion
//#region src/board/validate.d.ts
/** The only board `version` this package reads or writes. */
declare const BOARD_VERSION = 1;
/** A new empty version-1 board. */
declare function emptyBoard(): Board;
/** The canonical form of a set: duplicate-free and in code-unit order. */
declare const sortedUnique: (list: readonly string[]) => string[];
/**
 * Check a value against the version-1 board contract. Returns the problems found, empty when the board is valid. A version other than 1
 * is a problem, so another version is never read as this one.
 */
declare function validateBoard(value: unknown): string[];
/** Put every set-valued field of a working copy in its canonical form, in place, tolerating a malformed board. */
declare function normalizeBoard(board: unknown): void;
type ParsedBoard = {
  readonly ok: true;
  readonly board: Board;
} | {
  readonly ok: false;
  readonly kind: 'invalid' | 'newer';
  readonly problems: readonly string[];
};
/**
 * Read board text. `invalid` covers text that is not JSON and a board that breaks the contract; `newer` is a board whose `version` is an
 * integer above 1, which a later program wrote and this one must not touch. Nothing is repaired or defaulted.
 */
declare function parseBoardText(text: string): ParsedBoard;
/** The one byte form of a board: two-space JSON and a final newline. An invalid board has no serialization. */
declare function serializeBoard(board: Board): string;
//#endregion
//#region src/board/paths.d.ts
/** What path resolution needs from a file system. `realpath` rejects with an error carrying a Node-style `code`. */
interface PathFs {
  isDirectory(path: string): Promise<boolean>;
  realpath(path: string): Promise<string>;
  /** The enclosing git working tree of `cwd`, when the host can tell; undefined or '' when not. A rejection means "not known" and is ignored. */
  gitTopLevel?(cwd: string): Promise<string | undefined>;
}
/**
 * The workspace of a session: the git top-level of its cwd, else the cwd itself, then its real path. Returns undefined when there is no cwd
 * or it is not an absolute path to a directory that resolves (then the session has no board).
 */
declare function resolveWorkspace(fs: PathFs, cwd: unknown): Promise<string | undefined>;
/**
 * The canonical path of a write target: resolved against `cwd`, then the real path of its nearest existing ancestor joined with the
 * segments that do not exist yet, with no trailing separator. Returns undefined when it is outside the workspace (never governed) or cannot
 * be formed from the target, cwd and workspace. A filesystem error other than a missing or non-directory ancestor is thrown.
 */
declare function canonicalTarget(fs: PathFs, target: unknown, cwd: unknown, workspace: unknown): Promise<string | undefined>;
/** Whether a claim covers a canonical path. `src/foo` never covers `src/foobar`. */
declare function covers(claim: Range, path: string): boolean;
/** Two claims overlap when either covers the other's path. */
declare function overlaps(a: Range, b: Range): boolean;
//#endregion
//#region src/board/governing.d.ts
/** Notices kept per session, newest last. */
declare const MAX_NOTICES = 10;
/** The most passes one takeover makes. Each real pass removes at least one record, so a finite board ends sooner; the bound is a guard. */
declare const MAX_TAKEOVER_PASSES = 64;
/** A holder's state when asked: `own` marks the requester's own leftovers, `unknown` a holder the board or the liveness cannot place. */
type HolderState = 'active' | 'idle' | 'closed' | 'crashed' | 'unknown' | 'own';
/** Whether a state frees what the session holds: anything but `active`. */
declare const isFree: (state: string) => boolean;
interface ClaimEntry {
  readonly claimId: string;
  readonly claim: ClaimRecord;
}
/** What governs a path: the first match of marker, claim, edits; undefined when nothing does. */
type Governing = {
  readonly kind: 'marker';
  readonly marker: MarkerRecord;
} | {
  readonly kind: 'claim';
  readonly own: readonly ClaimEntry[];
  readonly foreign: readonly ClaimEntry[];
  readonly shared: readonly ClaimEntry[];
} | {
  readonly kind: 'edits';
  readonly sessions: readonly {
    readonly id: string;
    readonly session: Board['sessions'][string];
  }[];
} | undefined;
/**
 * What governs a canonical path on a board, for a writer whose root session is `rootId`. Pure; the board is not changed.
 * `claim` carries the claims at the most specific level, split by holder; `edits` the other open sessions that edited the path, most
 * recently active first.
 */
declare function governing(board: Pick<Board, 'markers' | 'claims' | 'sessions'>, path: string, rootId: string): Governing;
/** A record another session holds, in the form a takeover removes it. `state` is filled in when the holders are asked. */
interface Holder {
  type: 'marker' | 'claim' | 'edits';
  sessionId: string;
  path: string;
  claimId?: string;
  reason?: string;
  paths?: string[];
  state?: HolderState;
}
/** The other sessions' records a governing verdict rests on, in takeover form; empty when there is nothing to take. */
declare function takeable(gov: Governing, path: string): Holder[];
/**
 * Leave a notice on a holder's session record that a path was taken from it, in a board working copy. A session that is not on the board,
 * and the taker itself, get none; a repeat for the same path and taker replaces the earlier notice.
 */
declare function notify(board: Board, ownerId: string, notice: Notice): void;
interface Taken {
  readonly type: Holder['type'];
  readonly sessionId: string;
  readonly path: string;
  readonly state: HolderState | undefined;
}
/**
 * Take a requested range from non-active holders, in a board working copy. The caller has checked that every holder is free. Markers in the
 * range go; claims the range covers go, while a wider claim stays (the taker's own narrower claim then governs); covered edits leave the
 * holders' edits. Each taken-from holder is notified. Returns what was taken.
 */
declare function takeRange(board: Board, requested: Range, holders: readonly Holder[], by: {
  readonly by: string;
  readonly at: number;
}): Taken[];
/** What a takeover needs from its host: each session's state, the clock and a fresh claim id. */
interface TakeoverPorts {
  stateOf(sessionId: string): Promise<HolderState>;
  now(): number;
  newId(): string;
}
interface TakeoverResult {
  /** Passes made (at most {@link MAX_TAKEOVER_PASSES}). */
  readonly passes: number;
  /** True when the bound ended the loop with work still pending: the board kept producing holders. */
  readonly exhausted: boolean;
  /** How many records were taken in total. */
  readonly taken: number;
  /** The sessions whose active state stopped the takeover, from the last pass; empty when nothing blocked it. */
  readonly blockedBy: readonly string[];
}
/**
 * Take a path from its non-active holders, in a board working copy, record by record in governing order until the writer's verdict rests
 * on nothing another session holds, or an active holder stops it (then nothing more is taken). A wider folder claim stays its owner's: the
 * writer takes just this file with its own narrower claim. At most {@link MAX_TAKEOVER_PASSES} passes.
 */
declare function takeOverPath(board: Board, path: string, rootId: string, ports: TakeoverPorts): Promise<TakeoverResult>;
//#endregion
//#region src/board/decisions.d.ts
/** Answered calls kept per root session. */
declare const MAX_CALLS_PER_ROOT = 50;
interface FlagOptions {
  /** `refusal` (default) is told to the main agent as text; `dependency` is asked from the session's `depends`. */
  readonly kind?: 'refusal' | 'dependency';
  /** What the main agent is told. */
  readonly text?: string;
}
interface AnsweredCall {
  readonly callId: string;
  /** The question as put to the user (JSON text of the call's arguments). */
  readonly question: string;
  /** The user's answer text. */
  readonly userAnswer: string;
}
type Verification = {
  readonly ok: true;
  readonly evidence: {
    readonly callId: string;
    readonly question: string;
    readonly userAnswer: string;
    readonly at: number;
  };
} | {
  readonly ok: false;
  readonly reason: string;
};
interface DecisionEvidence {
  /** Record that a decision is owed on a subject (a path or an interface key); a later flag replaces an earlier one. */
  flag(rootId: string, subject: string, options?: FlagOptions): void;
  /** A decision on the subject was recorded: it is no longer owed. */
  resolve(rootId: string, subject: string): void;
  /** When the latest flag for the subject was raised, in the Backend clock's milliseconds; undefined when no decision is owed on it. */
  flagTime(rootId: string, subject: string): number | undefined;
  /** The texts of the root's open refusal flags, oldest first. Dependency flags are asked from `depends`, not here. */
  openFlags(rootId: string): string[];
  /** The summary's stalled-dependency question was raised for an interface key. The first flag stands: a repeat is not a newer question. */
  flagDependency(rootId: string, key: string): void;
  /** Whether a question call proves the user was asked about a subject. */
  verify(rootId: string, evidence: {
    readonly subject: string;
    readonly askCallId: unknown;
  }): Verification;
  /** The capability the summary takes for its main-only questions. */
  readonly questions: {
    openFlags(rootId: string): string[];
    flagDependency(rootId: string, key: string): void;
    version(rootId: string): number;
  };
  /** A question call started: its sequence fixes "made after the refusal". The first sighting stands. */
  noteQuestionStarted(callId: string): void;
  /** A question call returned an answer. A call already recorded, either way, is not recorded again. */
  recordAnswer(rootId: string, call: AnsweredCall): void;
  /** A question call returned an error or is still pending: it is never an answer. */
  recordNotAnswer(rootId: string, call: {
    readonly callId: string;
    readonly why: 'error' | 'pending';
  }): void;
}
declare function createDecisionEvidence({ now }?: {
  readonly now?: () => number;
}): DecisionEvidence;
//#endregion
//#region src/board/storage.d.ts
type RefusedReason = 'invalid' | 'newer' | 'unreadable';
type StoredBoard = {
  readonly status: 'absent';
} | {
  readonly status: 'present';
  readonly board: Board;
  readonly text: string;
} | {
  readonly status: 'refused';
  readonly reason: RefusedReason;
  readonly detail: string;
  readonly problems: readonly string[];
};
/** The bytes a replacement persisted. */
interface BoardConfirmation {
  readonly revision: number;
  readonly text: string;
}
interface BoardStorage {
  read(): Promise<StoredBoard>;
  replace(board: Board): Promise<BoardConfirmation>;
}
/** A replacement that did not happen. `invalid`: the board breaks the contract; `unwritable`: the store could not take it (old board intact). */
declare class BoardStorageError extends Error {
  readonly reason: 'invalid' | 'unwritable';
  readonly detail: string;
  constructor(reason: 'invalid' | 'unwritable', detail: string, options?: {
    cause?: unknown;
  });
}
//#endregion
//#region src/board/memory-storage.d.ts
interface MemoryBoardStorage extends BoardStorage {
  /** The exact text held now; undefined when the storage is empty. */
  readonly text: string | undefined;
  /** Put arbitrary text there, as damage or a newer program would. */
  plant(text: string): void;
  /** Make the next `replace` fail with `unwritable`; the held text is left as it was. */
  failNextReplace(cause: unknown): void;
}
declare function createMemoryBoardStorage({ text }?: {
  readonly text?: string | undefined;
}): MemoryBoardStorage;
//#endregion
//#region src/board/service.d.ts
interface Unavailable {
  readonly ok: false;
  readonly kind: 'unavailable';
  readonly reason: RefusedReason | 'unwritable';
  readonly detail: string;
  readonly problems: readonly string[];
}
type ReadOutcome = {
  readonly ok: true;
  readonly board: Board;
  readonly absent: boolean;
} | Unavailable;
type UpdateOutcome<T> = {
  readonly ok: true;
  readonly board: Board;
  readonly result: T;
  readonly confirmation: BoardConfirmation;
} | Unavailable | {
  readonly ok: false;
  readonly kind: 'contract';
  readonly problems: readonly string[];
} | {
  readonly ok: false;
  readonly kind: 'closed';
};
interface BoardService {
  /** The stored board now (a copy), or the empty board when none is stored. */
  read(): Promise<ReadOutcome>;
  /**
   * Change the board. Updates run one at a time, in the order they were requested. `change` receives a working copy and may change it in
   * place; it may be async and its return value comes back as `result`. An error it throws is rethrown unchanged, with nothing written.
   */
  update<T>(change: (board: Board) => T | Promise<T>): Promise<UpdateOutcome<T>>;
  /** Stop accepting updates, wait for the ones already requested, and settle. Idempotent. */
  drain(): Promise<void>;
  /** Updates requested and not yet settled. */
  readonly pending: number;
  readonly closed: boolean;
}
declare function createBoardService({ storage }: {
  readonly storage: BoardStorage;
}): BoardService;
//#endregion
//#region src/board/config.d.ts
declare const DEFAULT_IDLE_MS = 900000;
declare const DEFAULT_SUMMARY_MAX_BYTES = 2048;
declare const MIN_SUMMARY_MAX_BYTES = 512;
interface AwarenessConfig {
  readonly enabled: boolean;
  /** How long a settled holder stays active after its last evidence; beyond it the holder is idle. */
  readonly idleMs: number;
  readonly summaryMaxBytes: number;
  /** On an unreadable board: true lets a guarded write proceed with a visible warning; false refuses it (D12). */
  readonly failOpen: boolean;
}
declare const EVIDENCE_DEFAULTS: Readonly<AwarenessConfig>;
type ConfigResult = {
  readonly ok: true;
  readonly config: AwarenessConfig;
} | {
  readonly ok: false;
  readonly field: string;
  readonly message: string;
};
/** Validate the row's options; omitted or `undefined` fields take the defaults. The first invalid field is named. */
declare function parseAwarenessConfig(input?: unknown): ConfigResult;
//#endregion
//#region src/board/liveness.d.ts
type ObservationKind = 'running' | 'settled' | 'stopped' | 'crash' | 'restart' | 'unknown';
/** What the policy reads of a step-14 liveness observation (the fork's `LivenessObservation` is a superset). */
interface HolderObservation {
  readonly kind: ObservationKind;
  /** The service clock, epoch ms, when the state was set. */
  readonly observedAt: number;
}
interface HolderStateInput {
  readonly observation: HolderObservation | undefined;
  /** The holder's session record on the board; undefined when the board has none. */
  readonly session: Pick<SessionRecord, 'state' | 'lastActivityAt'> | undefined;
  readonly now: number;
  /** The idle evidence parameter (config.ts), in milliseconds. */
  readonly idleMs: number;
}
/** A holder's state from its observation and its board record. Pure. */
declare function holderStateFrom({ observation, session, now, idleMs }: HolderStateInput): HolderState;
/** What the state reader needs from its host. `observationOf` may throw or reject; the caller decides what that means (the guard: unavailable). */
interface HolderStatePorts {
  observationOf(sessionId: string): HolderObservation | undefined | Promise<HolderObservation | undefined>;
  now(): number;
  readonly idleMs: number;
}
/**
 * A state reader over one board: `stateOf(sessionId)` for the takeover, reading the session record from the board AT CALL TIME (a takeover
 * works on a copy it changes). A session the board does not have is read from its observation alone.
 */
declare function holderStates(board: Pick<Board, 'sessions'>, ports: HolderStatePorts): (sessionId: string) => Promise<HolderState>;
//#endregion
//#region src/board/verdict.d.ts
/** How many holders a refusal names. */
declare const MAX_HOLDERS_NAMED = 3;
/** How long a holder must be quiet before its ground is free, in words. */
declare const quietFor: (idleMs: number) => string;
/** What a main agent does about an active holder: coordinate with it, not the user. */
declare const coordinateAdvice: (idleMs: number) => string;
/** The last resort when coordination cannot work: the user decides. Empty when the host offers no `resolve`. */
declare const lastResort: (decision: "leftover" | "overlap", resolveAvailable?: boolean) => string;
type GuardRefusalCode = Extract<Code, 'AWARENESS_HELD' | 'AWARENESS_LEFTOVER' | 'AWARENESS_ASSIGNED'>;
interface GuardRefusal {
  readonly status: 'refused';
  readonly code: GuardRefusalCode;
  /** The text for the refused agent. */
  readonly detail: string;
  /** The short text the host records as the writer's open refusal flag (the decision registry, step 20). */
  readonly flag: string;
  /** Every session id whose hold the refusal rests on, most relevant first (empty for an assignment). */
  readonly holders: readonly string[];
}
type GuardVerdict = {
  readonly status: 'allowed';
} | GuardRefusal;
interface WriterContext {
  readonly path: string;
  /** The writing agent's own id (an XC-1 session id): compared with a claim's `assignee`. */
  readonly writerId: string;
  /** Whether the writer is the main agent of its root session. */
  readonly isMain: boolean;
}
interface VerdictOptions {
  readonly idleMs: number;
  readonly stateOf: (sessionId: string) => Promise<string>;
  /** False when the host offers no `resolve` action, so the advice does not point at it. Default true. */
  readonly resolveAvailable?: boolean;
}
/**
 * The verdict for a governing record, after any free holders were taken over: allowed, or the refusal for what still holds the path.
 * Call this on the board the takeover produced; a holder that is not active here is still named with its state.
 */
declare function verdictFor(board: Board, gov: Governing, ctx: WriterContext, options: VerdictOptions): Promise<GuardVerdict>;
/** What a guard check needs from its host: liveness observations, the clock, fresh ids, the idle parameter. */
interface GuardPorts extends HolderStatePorts {
  newId(): string;
  readonly resolveAvailable?: boolean;
}
interface GuardInput {
  readonly service: BoardService;
  /** The canonical path being written. */
  readonly path: string;
  /** The writer's root session id (the board's key for the writer). */
  readonly rootId: string;
  readonly writerId: string;
  readonly isMain: boolean;
}
type GuardOutcome = {
  readonly status: 'allowed'; /** Records taken from non-active holders in this check. */
  readonly takenOver: number;
} | GuardRefusal |
/** The check could not be answered: the host applies `failOpen`. Never read this as "free". */
{
  readonly status: 'unavailable';
  readonly reason: 'board' | 'liveness';
  readonly detail: string;
};
/**
 * May the writer write this path? Reads the board fresh, takes over what only non-active holders hold in ONE board update (an active
 * holder stops it and nothing is taken), then gives the verdict on the resulting board. Writes nothing when there is nothing to take.
 */
declare function guardPath(input: GuardInput, ports: GuardPorts): Promise<GuardOutcome>;
//#endregion
//#region src/board/session.d.ts
/**
 * What a changed-files lookup answered for a workspace.
 *  - `known`: Git listed these absolute paths as changed (untracked files one by one); a path not in the set is clean.
 *  - `outside-git`: the workspace is not in a Git repository (or Git is absent); every tracked edit stays.
 *  - `unknown`: Git could not be read. That is NOT an empty listing: nothing may be called clean from it.
 */
type ChangedFiles = {
  readonly status: 'known';
  readonly paths: ReadonlySet<string>;
} | {
  readonly status: 'outside-git';
} | {
  readonly status: 'unknown';
  readonly detail: string;
};
/** The injected git/changed-files capability. It may throw or reject: that is `unknown`, the same as `{ status: 'unknown' }`. */
interface ChangedFilesPort {
  changedFiles(workspace: string): Promise<ChangedFiles>;
}
interface CloseResult {
  /** False when the session was unknown or already closed and was left alone. */
  readonly closed: boolean;
  /** The edits that now carry a marker (kept in the session's `edits`). */
  readonly markers: readonly string[];
  /** The edits dropped because they are no longer changed. */
  readonly dropped: readonly string[];
}
/**
 * Close a session on a board working copy: the one close policy. `changed` is the set of still-changed absolute paths, or `undefined`
 * to keep every edit (outside Git). The caller must not pass an empty set for "Git failed" - that is the unknown case, handled by not
 * calling this function. `reason` is `closed` (disposed or clean exit) or `crashed`.
 */
declare function closeSession(board: Board, sessionId: string, reason: 'closed' | 'crashed', { changed, now }: {
  readonly changed: ReadonlySet<string> | undefined;
  readonly now: number;
}): CloseResult;
/**
 * Record edit paths on a root session. An open session just gains the edits. A closed session is not reopened: each edit is kept and
 * protected by a `closed` marker (never overwriting one), so a late write is guarded rather than lost. An unknown session is left alone.
 */
declare function noteEdits(board: Board, rootId: string, edits: readonly string[], now: number): void;
interface OpenInput {
  /** `resume`: the session's own earlier work is being picked up; anything else leaves its markers. */
  readonly source: 'resume' | 'startup';
  readonly now: number;
  readonly label: string;
  /** The Backend process the session now belongs to (a string the host chooses; liveness does not read it). */
  readonly processId: string;
}
interface OpenResult {
  /** The session's own `closed` markers released on resume, sorted. */
  readonly released: readonly string[];
  /** The one advisory for the resumed agent, when markers were released. */
  readonly advisory: string | undefined;
}
/** Open (create or reopen) a session as running. On `resume` its own `closed` markers go and its edits stay; foreign markers always stay. */
declare function openSession(board: Board, sessionId: string, { source, now, label, processId }: OpenInput): OpenResult;
/** The advisory told to a resumed agent about the unfinished work it left. */
declare function resumeAdvisory(paths: readonly string[]): string;
//#endregion
//#region src/board/reconcile.d.ts
/**
 * What the host knows of a session in THIS Backend run. `live`: positive evidence it is running now. `stopped`/`crashed`: observed
 * to have ended. `unknown`: no usable evidence. `unbound`: no thread was ever bound to it (a stray).
 */
type SessionEvidence = 'live' | 'stopped' | 'crashed' | 'unknown' | 'unbound';
/** The evidence a liveness observation gives: running and settled are live, stopped and crash themselves, anything else unknown. */
declare function evidenceFromObservation(observation: HolderObservation | undefined): SessionEvidence;
type SessionDisposition = {
  readonly sessionId: string;
  readonly outcome: 'resumed';
} | {
  readonly sessionId: string;
  readonly outcome: 'closed';
  readonly reason: 'closed' | 'crashed';
  /** Edits that now carry a marker. */
  readonly markers: readonly string[];
  /** Edits dropped because Git showed them no longer changed. */
  readonly dropped: readonly string[];
  /** What the markers were judged by: Git's listing, no Git (every edit kept), or nothing (no edits). */
  readonly basis: 'git' | 'outside-git' | 'no-edits';
  readonly livenessUnknown: boolean;
  readonly stray: boolean;
} | {
  readonly sessionId: string;
  readonly outcome: 'deferred';
  readonly detail: string;
};
type ReconcileResult = {
  readonly status: 'reconciled';
  readonly sessions: readonly SessionDisposition[];
} |
/** The board or the evidence could not be read or written; nothing was changed. */
{
  readonly status: 'unavailable';
  readonly detail: string;
};
interface ReconcileInput {
  readonly service: BoardService;
  /** The canonical workspace the board belongs to, for the changed-files lookup. */
  readonly workspace: string;
  readonly changedFiles: ChangedFilesPort;
  evidenceOf(sessionId: string): SessionEvidence | undefined | Promise<SessionEvidence | undefined>;
  now(): number;
}
declare function reconcileBoard(input: ReconcileInput): Promise<ReconcileResult>;
//#endregion
//#region src/board/summary.d.ts
/** How many of a peer's edited files the summary names before `+N more`. */
declare const MAX_EDITS_SHOWN = 10;
/** What the main agent is asked from outside the board: open refusal flags, stalled dependencies. */
interface Questions {
  openFlags(rootId: string): string[];
  flagDependency(rootId: string, key: string): void;
  /** Moves on refusal flags and their resolution; absent counts as 0. */
  version?(rootId: string): number;
}
interface ViewMemoryEntry {
  revision: number | undefined;
  versions: Map<string, number>;
  body: string | undefined;
  flagVersion: number;
  noticesAfter: number;
}
/** What each calling session last received, kept for the Backend process. Cold resume or restart empties it: everything is shown again. */
type ViewMemory = Map<string, ViewMemoryEntry>;
declare const createViewMemory: () => ViewMemory;
interface PeerView {
  readonly id: string;
  readonly session: SessionRecord;
  readonly claims: readonly (ClaimRecord & {
    readonly assigneeLabel: string | undefined;
  })[];
  readonly interfaces: readonly (InterfaceRecord & {
    readonly changed: boolean;
  })[];
}
interface View {
  readonly notices: readonly (Notice & {
    readonly byLabel: string;
  })[];
  readonly active: readonly PeerView[];
  readonly idle: readonly {
    readonly id: string;
    readonly session: SessionRecord;
  }[];
  readonly markers: readonly (MarkerRecord & {
    readonly ownerLabel: string;
  })[];
  readonly questions: readonly string[];
}
interface ViewOptions {
  readonly rootId: string;
  readonly isMain: boolean;
  readonly stateOf: (sessionId: string) => Promise<HolderState>;
  readonly seen?: ReadonlyMap<string, number>;
  readonly questions?: Questions;
  readonly noticesAfter?: number;
}
/** What one root session should see of the others. Pure over the board and the supplied states. */
declare function deriveView(board: Board, { rootId, isMain, stateOf, seen, questions, noticesAfter }: ViewOptions): Promise<View>;
/** Whether a view holds anything to say. */
declare const hasContent: (view: View) => boolean;
interface Entry$1 {
  readonly text: string;
  /** An interface line carries its key, so what a cap delivers can be told from what it cut. */
  readonly key?: string;
}
/** The view as entries, header first: notices, active sessions, idle sessions, markers on the agent's own ground, questions. */
declare function renderEntries(view: View, { workspace, revision, maxEdits }: {
  readonly workspace: string;
  readonly revision: number;
  readonly maxEdits?: number;
}): Entry$1[];
/** The view as lines: the entries' text. */
declare const renderLines: (view: View, options: Parameters<typeof renderEntries>[1]) => string[];
/** Join entries within a UTF-8 byte cap (at least 512). Whole entries drop from the end, never the header; a footer counts them. */
declare function capEntries(entries: readonly Entry$1[], maxBytes: number): {
  readonly text: string;
  readonly kept: readonly Entry$1[];
};
interface SummaryInput {
  readonly service: BoardService;
  readonly workspace: string;
  /** The memory key: the calling session's own id (a main agent and its child each have their own copy). */
  readonly callerId: string;
  /** The root session whose board record the view is for. */
  readonly rootId: string;
  readonly isMain: boolean;
}
interface SummaryPorts extends HolderStatePorts {
  readonly questions?: Questions;
  readonly memory: ViewMemory;
  readonly summaryMaxBytes?: number;
}
type SummaryOutcome = {
  readonly status: 'done'; /** The text to deliver, or null when there is nothing new to say. */
  readonly text: string | null;
  readonly revision: number;
  readonly bytes: number;
} | {
  readonly status: 'unavailable';
  readonly reason: 'board' | 'liveness';
  readonly detail: string;
};
/** The summary this caller has not yet received, within the byte cap; the memory advances only for what the text delivers. */
declare function summarize(input: SummaryInput, ports: SummaryPorts): Promise<SummaryOutcome>;
//#endregion
//#region src/board/actions.d.ts
declare const ACTIONS: readonly ["status", "goal", "claim", "assign", "release", "interface", "withdraw", "depend", "resolve"];
type AwarenessActionName = (typeof ACTIONS)[number];
/** What each action requires. */
declare const REQUIRED: Readonly<Record<AwarenessActionName, readonly string[]>>;
/** The answers each decision accepts. */
declare const ANSWERS: Readonly<Record<string, readonly string[]>>;
/** Every argument an action call may carry; any other key is invalid, so a caller id can never be smuggled in. */
declare const ACTION_FIELDS: readonly ["action", "path", "kind", "idea", "claimId", "agentId", "name", "signature", "notes", "text", "interface", "decision", "answer", "askCallId"];
type ChildState = 'running' | 'idle' | 'closed' | 'unknown';
/** XC-10's answer (M05): is this session an owned subagent of the root, and in which state. */
interface ChildStatus {
  readonly owned: boolean;
  readonly state: ChildState;
}
/** Who is acting, from the Backend's identity resolution: ids are XC-1 session ids. */
interface ActionCaller {
  readonly sessionId: string;
  readonly kind: 'main' | 'child';
  readonly rootId: string;
  readonly workspace: string;
  /** The thread's working folder (a fact of the Backend's thread index), against which relative paths resolve. */
  readonly cwd: string;
}
/** XC-8's question: the root session, the `ask_user_question` call id the caller cites and, when known, the session that asked. */
interface QuestionEvidenceArgs {
  readonly rootSessionId: string;
  readonly askCallId: string;
  readonly askerSessionId?: string;
}
/** XC-8's answer (M06 `questionEvidence`): `answered` is true only for a question answered by a verified human origin. */
interface QuestionEvidence {
  readonly state: string;
  readonly answered: boolean;
  readonly startedAt: string;
  readonly answeredAt?: string;
  readonly answers?: readonly unknown[];
  readonly originId?: string;
  readonly interactionId: string;
  /** The call id matched several sessions and no asker was given: every other field is one candidate's and must not be used. */
  readonly ambiguous?: boolean;
}
/** A reply is a value or a canonical code: `INTERACTION_NOT_FOUND` is a missing question; any other code is the evidence being unavailable. */
type QuestionEvidenceReply = {
  readonly ok: true;
  readonly value: QuestionEvidence;
} | {
  readonly ok: false;
  readonly code: string;
  readonly detail?: string;
};
interface ActionPorts extends HolderStatePorts {
  readonly service: BoardService;
  readonly decisions: DecisionEvidence;
  readonly memory: ViewMemory;
  readonly pathFs: PathFs;
  newId(): string;
  /** Absent in production until M05 supplies XC-10. */
  readonly childStatus?: ((rootId: string, childId: string) => ChildStatus | Promise<ChildStatus>) | undefined;
  /**
   * The durable verified-human evidence of XC-8, in process. Absent: `resolve` answers unavailable and no advice points at it. Present: it IS the
   * real provider (M06's interaction service); a test double shows only the shapes it returns.
   */
  readonly questionEvidence?: ((args: QuestionEvidenceArgs) => Promise<QuestionEvidenceReply>) | undefined;
}
/** What an action could not be answered for; the host (the fork) maps each to its wire code. */
type UnavailableReason$1 = 'board' | 'liveness' | 'child-status' | 'decision-evidence';
type ActionOutcome = {
  readonly status: 'done';
  readonly result: Record<string, unknown>;
} | {
  readonly status: 'unavailable';
  readonly reason: UnavailableReason$1;
  readonly detail: string;
};
declare function awarenessAction(caller: ActionCaller, raw: Readonly<Record<string, unknown>>, ports: ActionPorts): Promise<ActionOutcome>;
//#endregion
//#region src/board/writes.d.ts
interface WritePorts extends GuardPorts {
  readonly service: BoardService;
  readonly decisions: DecisionEvidence;
  readonly pathFs: PathFs;
}
type CheckWriteOutcome = {
  readonly status: 'allowed'; /** False: the path is outside the workspace and nothing was read. */
  readonly governed: boolean;
  readonly takenOver: number;
} | {
  readonly status: 'refused';
  readonly code: GuardRefusalCode;
  readonly detail: string;
} | {
  readonly status: 'unavailable';
  readonly reason: 'board' | 'liveness';
  readonly detail: string;
};
/** May this caller write this path? A fresh board read and, if only non-active holders hold it, one takeover update. */
declare function checkWrite(caller: ActionCaller, input: {
  readonly path: string;
}, ports: WritePorts): Promise<CheckWriteOutcome>;
/** The call ids whose edit was recorded, newest kept (bounded): a retry of the same call is a duplicate, not a second edit. */
interface RecordedCalls {
  has(key: string): boolean;
  add(key: string): void;
}
declare const MAX_RECORDED_CALLS = 1024;
declare function createRecordedCalls(max?: number): RecordedCalls;
interface RecordPorts {
  readonly service: BoardService;
  readonly pathFs: PathFs;
  readonly recorded: RecordedCalls;
  now(): number;
}
type RecordEditOutcome = {
  readonly status: 'recorded';
  readonly governed: boolean;
  readonly duplicate: boolean;
} | {
  readonly status: 'unavailable';
  readonly reason: 'board';
  readonly detail: string;
};
/** Note a landed edit on the caller's root session. The call id is remembered only once the board took the edit. */
declare function recordEdit(caller: ActionCaller, input: {
  readonly path: string;
  readonly callId: string;
}, ports: RecordPorts): Promise<RecordEditOutcome>;
//#endregion
//#region src/board/shell.d.ts
/** The most paths one record carries (the Agent's sink cuts to the same bound). */
declare const MAX_SHELL_PATHS_PER_RECORD = 100;
/** The most shell-changed paths a session keeps; past it the first sorted paths stay and the record says the rest is unknown. */
declare const MAX_SHELL_RECORD_PATHS = 500;
interface ShellRecordPorts {
  readonly service: BoardService;
  readonly pathFs: PathFs;
  now(): number;
}
type RecordShellOutcome = {
  readonly status: 'recorded'; /** How many paths the request carried. */
  readonly count: number;
} | {
  readonly status: 'refused';
  readonly code: 'AWARENESS_INVALID';
  readonly detail: string;
} | {
  readonly status: 'unavailable';
  readonly reason: 'board';
  readonly detail: string;
};
/** Note what a shell command was seen to change (or that it could not be seen) on the caller's root session. Nothing is stored when the input is refused. */
declare function recordShell(caller: ActionCaller, input: unknown, ports: ShellRecordPorts): Promise<RecordShellOutcome>;
/** The labels a refusal adds to a holder it names: the path changed via shell, and an unknown shell record. Empty when the session has neither. */
declare function shellNote(session: Pick<SessionRecord, 'shell'> | undefined, path: string): string;
//#endregion
//#region src/host/board/file-storage.d.ts
/** The board file of a workspace beneath an explicit state root. */
declare function boardFileFor(stateRoot: string, workspace: string): string;
interface FileBoardOptions {
  /** The explicit Aetheria state root; an absolute path. */
  readonly stateRoot: string;
  /** The canonical workspace this board belongs to; an absolute path. */
  readonly workspace: string;
  /** A fault-injection seam: called with the temporary file's path after it is written and flushed, before the rename. A throw leaves the old board. */
  readonly beforeRename?: (tempPath: string) => void | Promise<void>;
}
interface FileBoardStorage extends BoardStorage {
  readonly file: string;
  /** Remove the temporary files an interrupted replacement left beside the board. Returns their names. Call only while no replacement runs. */
  recoverInterrupted(): Promise<string[]>;
}
declare function createFileBoardStorage(options: FileBoardOptions): FileBoardStorage;
//#endregion
//#region src/host/board/node-path-fs.d.ts
declare function nodePathFs({ gitTopLevel }?: {
  readonly gitTopLevel?: (cwd: string) => Promise<string | undefined>;
}): PathFs;
//#endregion
//#region ../aetheria-resources/src/kernel/imports.d.ts
interface HomeOptions {
  readonly env?: Record<string, string | undefined> | undefined;
  readonly homedir?: (() => string) | undefined;
  readonly warn?: ((text: string) => void) | undefined;
}
//#endregion
//#region ../aetheria-resources/src/kernel/role-catalog.d.ts
interface Role extends RoleBinding {
  readonly name: string;
  readonly path: string;
  readonly layer?: 'project';
  readonly persona: string;
  readonly origin?: 'checkout' | 'home';
}
interface RoleCatalogOptions extends HomeOptions {
  readonly fs?: SyncFs | undefined;
  /** `false` reads the checkout alone. */
  readonly home?: boolean | undefined;
}
//#endregion
//#region ../aetheria-resources/src/roles/definitions.d.ts
interface RoleAuthorityDefinition extends RoleDefinition {
  /** The role's tool name: the name an identity record carries as `role`. */
  readonly tool: string;
  /** The catalog label of the file the role came from. */
  readonly path: string;
  /** Ordered routes, first the default. Data for M05/M09; no selection, fallback or run is decided here. */
  readonly routes: readonly Route[];
  readonly skills: readonly string[];
}
/** The role lookups the identity resolver and the predicate need. Both find a role by its tool name; neither infers one. */
interface RolePort {
  lookup(role: string): RoleAuthorityDefinition | null;
  roleOfTool(tool: string): RoleAuthorityDefinition | null;
  readonly definitions: readonly RoleAuthorityDefinition[];
  /** Roles left out, and why, plus the catalog's own problems. */
  readonly problems: readonly string[];
}
/**
 * Build the role port from loaded roles. A home role that holds `audit_evidence` is left out with a problem, so it is a removed role
 * for any session that names it: only the checkout's roles hold the audit capability, however the roles were obtained.
 */
declare function roleDefinitions(roles: readonly Role[], problems?: readonly string[]): RolePort;
/**
 * The current roles of a checkout (and, unless `home: false`, the home sets), read now. A checkout failure throws; a home role that
 * fails is a problem. Call it at each session start and resume: the result is never a cache to hold across a role edit.
 */
declare function currentRoles(repo: string, options?: RoleCatalogOptions): RolePort;
//#endregion
//#region ../aetheria-presets/src/types.d.ts
/** All three hosts stay in the schema. M02 hosts only `agent`; the others are refused at activation. */
declare const HOSTS: readonly ["agent", "backend", "client"];
type Host = (typeof HOSTS)[number];
declare const CONFIG_TYPES: readonly ["string", "number", "integer", "boolean", "string-list"];
type ConfigType = (typeof CONFIG_TYPES)[number];
/** One reportable problem. `subject` names the module/composition/manifest part; `field` the key. */
interface Fault {
  code: string;
  subject: string;
  field?: string;
  message: string;
}
interface ConfigField {
  type: ConfigType;
  required: boolean;
  /** A secret field's value never enters a digest or printed output. */
  secret: boolean;
}
interface ModuleConfig {
  fields: Record<string, ConfigField>;
  /** As authored. Types are checked against `fields` when the module is selected. */
  values: Record<string, unknown>;
}
interface InlineContract {
  consumer: string;
  success: string;
  failure: string;
  uncertainty: string;
  /** A state id some selected module lists in `owns`. */
  stateOwner: string;
}
interface PackagePin {
  package: string;
  /** An exact version; ranges are refused. */
  version: string;
}
interface Compat {
  /** Exact package pins by label, e.g. `pi`. */
  packages: Record<string, PackagePin>;
  /** Expected build stamps of artifacts by artifact id. */
  artifacts: Record<string, {
    stamp: string;
  }>;
}
interface ModuleDescriptor {
  id: string;
  host: Host;
  entry: string;
  requires: {
    modules: string[];
    services: string[];
  };
  provides: {
    tools: string[];
    services: string[];
    views: string[];
  };
  owns: string[];
  replaces: string[];
  config: ModuleConfig;
  compat: Compat;
  required: boolean;
  mutatesToolInput: boolean;
  /** Exactly one of `contract` and `contractRef` is set. */
  contract?: InlineContract;
  contractRef?: string;
}
interface Identity {
  name: string;
  description: string;
  order: number;
}
//#endregion
//#region ../aetheria-runtime/src/facts.d.ts
/**
 * What the world says, supplied by the host or the CLI edge. The validator reads no file and runs
 * no code to learn any of it. A key left out (`undefined`) is a fact not supplied, and is refused
 * by name when the composition needs it; `null` means "looked and found nothing".
 */
interface Facts {
  /** The composition being activated. */
  composition: string;
  /** The host doing the validating. M02 supplies `agent` only. */
  host: Host;
  /** Build-time allowlist of module entries. */
  allowlist?: readonly string[];
  /** Names of the built-in tools of the host (e.g. Pi's `read`, `write`). */
  builtinTools?: readonly string[];
  /** Package name -> its installed manifest's version, read from the installed package. */
  installed?: Readonly<Record<string, {
    version: string;
  } | null>>;
  /** Artifact id -> the stamp the build actually produced. */
  artifactStamps?: Readonly<Record<string, string>>;
  /** Objective id (`M04`) -> the receiving design's repository path and its `##` headings, or null if absent. */
  designs?: Readonly<Record<string, {
    path: string;
    headings: readonly string[];
  } | null>>;
}
//#endregion
//#region ../aetheria-runtime/src/validate.d.ts
interface ResolvedPin {
  label: string;
  package: string;
  pinned: string;
  installed: string;
  /** `manifest` or `module:<id>` */
  declaredBy: string;
}
interface EffectiveComposition {
  id: string;
  /** Root first. */
  chain: string[];
  identity: Identity;
  host: Host;
  /** Selected modules in selection order, which is also the extension order. */
  modules: ModuleDescriptor[];
  /** Dependency order: every module after what it requires. */
  activationOrder: string[];
  pins: ResolvedPin[];
  stamps: {
    artifact: string;
    stamp: string;
  }[];
}
type Validation = {
  outcome: 'valid';
  effective: EffectiveComposition;
} | {
  outcome: 'refused';
  faults: Fault[];
};
declare function compareFaults(a: Fault, b: Fault): number;
/**
 * Validate a raw manifest for `facts.composition`. Never throws on malformed input, imports and
 * starts nothing. Returns the effective composition, or every fault in a deterministic order.
 */
declare function validate(raw: unknown, facts: Facts): Validation;
//#endregion
//#region ../aetheria-runtime/src/digest.d.ts
declare const DIGEST_VERSION = 1;
interface DigestReport {
  version: number;
  algorithm: 'sha256';
  /** `sha256:<hex>` */
  value: string;
  /** Per-module digests, to find which module differs between two hosts. */
  modules: {
    id: string;
    host: string;
    digest: string;
  }[];
  installed: Record<string, string>;
  stamps: Record<string, string>;
  extensionOrder: string[];
  excluded: {
    module: string;
    field: string;
    reason: 'secret' | 'machine-path';
  }[];
}
declare function computeDigest(effective: EffectiveComposition): DigestReport;
//#endregion
//#region ../aetheria-runtime/src/evaluate.d.ts
type Evaluation = {
  outcome: 'valid';
  effective: EffectiveComposition;
  digest: DigestReport;
} | {
  outcome: 'refused';
  faults: Fault[];
};
/** Validate, then resolve the digest. A refused composition has no digest. */
declare function evaluate(raw: unknown, facts: Facts): Evaluation;
//#endregion
//#region ../aetheria-runtime/src/canonical.d.ts
declare function canonicalJson(value: unknown): string;
//#endregion
//#region ../aetheria-runtime/src/disposition.d.ts
/** A hand-over of live work to another owner. It names the receiver and the receiver's confirmation. */
interface DrainTransfer {
  item: string;
  to: string;
  confirmation: string;
}
/** What one module's drain reports. All four lists are required, so an empty list is a statement. */
interface Drain {
  released: string[];
  stopped: string[];
  transferred: DrainTransfer[];
  stillLive: string[];
}
interface Entry {
  module: string;
  item: string;
}
interface TransferEntry extends Entry {
  to: string;
  confirmation: string;
}
/** The XC-7 disposal report across the host. `ok` is true only when nothing is still live and every drain was observed. */
interface DisposalReport {
  /** The reason given by the call that did the work. */
  reason: string;
  ok: boolean;
  /** Modules drained, in release order (reverse of start order). */
  order: string[];
  released: Entry[];
  stopped: Entry[];
  transferred: TransferEntry[];
  stillLive: Entry[];
  /** Drains that threw: the module's disposition is not known. */
  failed: {
    module: string;
    message: string;
  }[];
  /** Drains that returned something this contract cannot read (not four lists, an unconfirmed transfer). */
  unobserved: {
    module: string;
    why: string;
  }[];
}
/** What became of one module's drain. */
type DrainOutcome = {
  kind: 'drained';
  drain: Drain;
} | {
  kind: 'failed';
  message: string;
} | {
  kind: 'unobserved';
  why: string;
};
/** Read a drain's return value. Anything that is not exactly the contract is unobserved, never success. */
declare function readDrain(value: unknown): DrainOutcome;
/** True when a drain was observed and left nothing live. */
declare const isClean: (outcome: DrainOutcome) => boolean;
/** Collect module outcomes, given in release order, into the host's report. */
declare function buildReport(reason: string, outcomes: readonly {
  module: string;
  outcome: DrainOutcome;
}[]): DisposalReport;
//#endregion
//#region ../aetheria-runtime/src/lifecycle.d.ts
/** What a module supplies: how to start, and its drain behavior (what it owns and how it lets go). */
interface Activation {
  /** Make the module's effects. May reject; a rejected start is drained like a completed one. */
  start(context: {
    id: string;
  }): Promise<void> | void;
  /** Release, stop or transfer everything this module owns, however far its start got. Called at most once. */
  drain(reason: string): Promise<unknown> | unknown;
}
type ModuleState = 'registered' | 'starting' | 'running' | 'failed' | 'skipped' | 'disposed';
/** The typed registration of a module (XC-4). */
interface ModuleHandle {
  readonly id: string;
  readonly state: ModuleState;
}
interface ModuleStatus {
  id: string;
  required: boolean;
  state: ModuleState;
  /** Why a module is `failed` or `skipped`. */
  failure?: string;
}
type StartResult = {
  outcome: 'started';
  activationOrder: string[];
  modules: ModuleStatus[];
  digest: Extract<Evaluation, {
    outcome: 'valid';
  }>['digest'];
} |
/** Refused before any module was called. */
{
  outcome: 'refused';
  faults: Fault[];
} |
/** A required module failed after effects; everything started was rolled back and `disposal` says what happened. */
{
  outcome: 'failed';
  cause: {
    module: string;
    message: string;
  };
  modules: ModuleStatus[];
  disposal: DisposalReport;
} |
/** `dispose` was called during start; everything started was disposed before this was returned. */
{
  outcome: 'stopped';
  reason: string;
  modules: ModuleStatus[];
  disposal: DisposalReport;
};
type LifecycleErrorCode = 'duplicate-id' | 'host-mismatch' | 'host-closed' | 'bad-activation' | 'reason-required';
declare class LifecycleError extends Error {
  readonly code: LifecycleErrorCode;
  constructor(code: LifecycleErrorCode, message: string);
}
type Phase = 'open' | 'starting' | 'started' | 'disposed';
declare class LifecycleHost {
  #private;
  readonly kind: Host;
  constructor(kind: Host);
  register(descriptor: ModuleDescriptor, activation: Activation): ModuleHandle;
  status(): {
    phase: Phase;
    modules: ModuleStatus[];
  };
  start(raw: unknown, facts: Facts): Promise<StartResult>;
  /** Release everything in reverse start order. The first call does the work; later calls return its report. */
  dispose(reason: string): Promise<DisposalReport>;
}
declare const createHost: (options: {
  host: Host;
}) => LifecycleHost;
declare const register: (host: LifecycleHost, descriptor: ModuleDescriptor, activation: Activation) => ModuleHandle;
declare const start: (host: LifecycleHost, raw: unknown, facts: Facts) => Promise<StartResult>;
declare const dispose: (host: LifecycleHost, reason: string) => Promise<DisposalReport>;
declare const hostStatus: (host: LifecycleHost) => ReturnType<LifecycleHost["status"]>;
//#endregion
//#region src/backend/index.d.ts
/** What a Backend may do with the identity store: look a session's record up. It cannot stage, activate, retire, discard or sweep. */
interface IdentityReader {
  read(sessionId: string): StoreRead;
}
/**
 * The read-only view of the sole writer's store under `stateRoot`. Nothing is created or changed by reading: absent folders read as
 * absent, and a corrupt or misfiled record is reported, never repaired. The writer's mutating methods are not reachable from the value
 * this returns, so a Backend cannot become a second XC-1 writer.
 */
declare function createIdentityReader(options: {
  readonly stateRoot: string;
}): IdentityReader;
//#endregion
export { ACTIONS, ACTION_FIELDS, ANSWERS, AbsentObservation, AbsentTarget, type ActionCaller, type ActionOutcome, type ActionPorts, type Activation, type AnsweredCall, type Authority, type AuthoritySource, type AwarenessActionName, type AwarenessConfig, BOARD_VERSION, type Board, type BoardConfirmation, type BoardService, type BoardStorage, BoardStorageError, CHILD_FORBIDDEN, CODE_REGISTRY, COVERAGE, COVERAGE_FIELDS, type CallerIdentity, type Chain, type ChainConfig, type ChainOptions, type ChangedFiles, type ChangedFilesPort, type CheckWriteOutcome, type ChildState, type ChildStatus, type ClaimEntry, type ClaimKind, type ClaimRecord, CleanSuccess, type CloseResult, Code, CodeEntry, type CollectInput, type CollectedChain, type CommittedFile, type ConfigResult, type CoordinationCheck, type CoordinationCheckInput, type CoordinationPort, type CoordinationRecord, type CoordinationRecordInput, CoverageRow, DEFAULT_IDLE_MS, DEFAULT_LIMITS, DEFAULT_MAX_BYTES, DEFAULT_MAX_LINES, DEFAULT_MAX_LINE_LENGTH, DEFAULT_SETTINGS_PATHS, DEFAULT_SUMMARY_MAX_BYTES, DIGEST_VERSION, DanglingLink, type DecisionEvidence, type DecisionKind, type DecisionRecord, type DeclaredExtensionSet, type DeliveredFrames, type DerivedProject, type DigestReport, type DisposalReport, type Drain, type DrainOutcome, type DrainTransfer, DropTarget, EVIDENCE_DEFAULTS, type EffectiveComposition, type Entry, type Evaluation, ExistingFile, type ExtensionObservation, type Facts, type FileBoardOptions, type FileBoardStorage, type FlagOptions, type Frame, type FrameFile, type FsInfo, type FsPort, GENERIC_DELEGATION, GIT_STATUS_TIMEOUT_MS, GLOBAL_DIR, type Governing, GuaranteeId, type GuardInput, type GuardOutcome, type GuardPorts, type GuardRefusal, type GuardRefusalCode, type GuardVerdict, type Guarded, GuardedOutcome, type Holder, type HolderObservation, type HolderState, type HolderStateInput, type HolderStatePorts, CODES as IDENTITY_CODES, type IdentityPorts, IdentityReader, type IdentityRecord, type InterfaceRecord, KERNEL_VERSION, type Kind, LifecycleError, type LifecycleErrorCode, LifecycleHost, LinkLoop, MAX_CALLS_PER_ROOT, MAX_EDITS_SHOWN, MAX_HOLDERS_NAMED, MAX_NOTICES, MAX_RECORDED_CALLS, MAX_SHELL_PATHS_PER_RECORD, MAX_SHELL_RECORD_PATHS, MAX_TAKEOVER_PASSES, MIN_SUMMARY_MAX_BYTES, type MarkerReason, type MarkerRecord, type MemoryBoardStorage, type ModuleHandle, type ModuleState, type ModuleStatus, type MutationAuthorization, type MutationBegin, type MutationCompletion, type MutationGuard, type MutationMode, type MutationNotice, type MutationOperation, type MutationPorts, type MutationRefusal, MutationRefusedError, type MutationRequest, NotAFile, type Notice, type ObservationKind, ObservationRegistry, type OpenInput, type OpenResult, OutcomeClass, type ParsedBoard, type PathFs, type PathRuleInput, type PeerView, type ProcessRecord, type ProjectFacts, type QuestionEvidence, type QuestionEvidenceArgs, type QuestionEvidenceReply, type Questions, REQUIRED, type Range, ReadObservation, type ReadOutcome, type ReadinessCode, ReadinessError, type ReadinessFs, type ReadinessPort, type ReconcileInput, type ReconcileResult, type RecordEditOutcome, type RecordPorts, type RecordResult, type RecordShellOutcome, type RecordedCalls, RefusalCode, type RefusedReason, Resolution, type ResolvedPin, type RoleAuthorityDefinition, type RoleDefinition, type RoleOrigin, type RolePort, SHELL_CHANGED_LABEL, SHELL_STATEMENT, SHELL_UNKNOWN_LABEL, STORE_FORMAT_VERSION, type SessionDisposition, type SessionEvidence, type SessionObservations, type SessionRecord, type SessionState, type SettingsPaths, type ShellCall, type ShellObservation, type ShellObserver, type ShellObserverPorts, type ShellRecord, type ShellRecordPorts, type ShellSnapshot, type StartResult, type StoreRead, type StoredBoard, type SummaryInput, type SummaryOutcome, type SummaryPorts, type Taken, type TakeoverPorts, type TakeoverResult, TextWindow, TextWindowOptions, type TransferEntry, Truncation, type Unavailable, type UnavailableReason, UnstableReadError, type UpdateOutcome, type Validation, Verdict, type VerdictOptions, type Verification, VersionToken, type View, type ViewMemory, type ViewMemoryEntry, type ViewOptions, type WritePorts, WriteRecord, type WriterContext, authorize, awarenessAction, boardFileFor, buildReport, canonicalJson, canonicalTarget, capEntries, chainConfig, changedObservation, checkWrite, cleanSuccess, closeSession, codeEntry, codeMentions, collectChain, compareFaults, computeDigest, coordinateAdvice, coverageProblems, coverageRow, coverageSentence, covers, createBoardService, createDecisionEvidence, createFileBoardStorage, createHost, createIdentityReader, createMemoryBoardStorage, createMutationGuard, createObservationRegistry, createRecordedCalls, createSessionObservations, createShellObserver, createViewMemory, currentRoles, deriveProject, deriveView, diffSnapshots, dispose, docCodeProblems, docCoverageProblems, emptyBoard, endOfFileFooter, evaluate, evidenceFromObservation, extensionSetProblem, formatSize, formatTextWindow, frameId, governing, guardPath, hasContent, holderStateFrom, holderStates, hostStatus, identityOf, isClean, isFree, lastResort, launchedExtensions, lineCutNote, missingFrames, nodeFs, nodePathFs, normalizeBoard, noteEdits, notify, openSession, outcomeFor, overlaps, parseAwarenessConfig, parseBoardText, parsePorcelain, projectRootFor, quietFor, readDrain, reconcileBoard, recordEdit, recordShell, refusalOf, register, removalFrame, renderEntries, renderLines, renderOutcome, renderVerdict, requiredFrames, resolveWorkspace, resumeAdvisory, roleDefinitions, runAuthorized, runObserved, serializeBoard, shellNote, shellObservationLines, sortedUnique, start, summarize, takeOverPath, takeRange, takeable, unavailableBoard, unknownObservation, unregisteredCodeMentions, validate, validateBoard, validateProject, validateRecord, verdictFor };