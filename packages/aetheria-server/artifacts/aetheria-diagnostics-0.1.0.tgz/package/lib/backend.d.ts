//#region src/event.d.ts
declare const EVENT_KINDS: readonly ["tool", "operation", "route", "error", "cancel", "refusal", "lifecycle", "health"];
type EventKind = (typeof EVENT_KINDS)[number];
declare const CANCEL_ORIGINS: readonly ["user-stop", "disconnect", "parent", "timeout", "shutdown"];
type CancelOrigin = (typeof CANCEL_ORIGINS)[number];
/** The only byte counts an event may carry; each is a count or `unknown`, never a body. */
declare const SIZE_FIELDS: readonly ["argumentBytes", "resultBytes", "errorBytes"];
type SizeField = (typeof SIZE_FIELDS)[number];
/** Every field an event may have, in the order the builder writes them. Anything else is refused. */
declare const EVENT_FIELDS: readonly ["eventId", "time", "host", "sessionId", "rootId", "callerRef", "kind", "name", "outcome", "route", "cancelOrigin", "sizes", "durationMs", "digest", "correlationId"];
type EventField = (typeof EVENT_FIELDS)[number];
interface Route {
  readonly provider: string;
  readonly model: string;
  readonly effort: string;
}
interface DiagnosticEvent {
  readonly eventId: string;
  /** UTC, `YYYY-MM-DDTHH:mm:ss.sssZ`. */
  readonly time: string;
  readonly host: string;
  readonly sessionId: string;
  readonly rootId?: string;
  readonly callerRef?: string;
  readonly kind: EventKind;
  /** A tool or operation name; absent when the event is about none. */
  readonly name?: string;
  /** An outcome in the vocabulary: an owner's existing code, `ok`, or one of the recorder's own words. */
  readonly outcome: string;
  readonly route?: Route;
  readonly cancelOrigin?: CancelOrigin;
  readonly sizes?: Readonly<Partial<Record<SizeField, number | 'unknown'>>>;
  /** Measured milliseconds, or `unknown`: never blank, never an invented zero. */
  readonly durationMs: number | 'unknown';
  /** The composition digest, `sha256:<hex>`. */
  readonly digest?: string;
  readonly correlationId?: string;
}
interface Problem {
  readonly field: string;
  /** A reason class only: a problem never repeats the offending value, which may be the very secret being kept out. */
  readonly reason: 'unknown-field' | 'missing' | 'invalid' | 'not-in-vocabulary' | 'not-allowed-here' | 'not-an-object';
}
type BuildResult = {
  readonly ok: true;
  readonly event: DiagnosticEvent;
} | {
  readonly ok: false;
  readonly problems: readonly Problem[];
};
/** Where a family's codes can be read from the owner's source; the drift test (tests/drift.test.mjs) reads it. Plain data, no behavior here. */
interface VocabularySource {
  readonly kind: string;
  readonly [key: string]: string | number | boolean | readonly string[] | undefined;
}
interface VocabularyFamily {
  readonly id: string;
  readonly owner: string;
  readonly note?: string;
  readonly sources: readonly VocabularySource[];
  readonly codes: readonly string[];
}
/** An outcome matched on the text of a result because its owner offers no code (T3's decline): never a native code. */
interface TextRule {
  readonly id: string;
  readonly owner: string;
  readonly outcome: string;
  readonly messagePattern: string;
  readonly source: VocabularySource;
}
interface VocabularyData {
  readonly version: number;
  /** Words the recorder itself owns (M12), distinct from every owner's native codes. */
  readonly recorderOutcomes: readonly string[];
  readonly families: readonly VocabularyFamily[];
  readonly textRules: readonly TextRule[];
}
interface Vocabulary {
  readonly data: VocabularyData;
  /** Every outcome word a recorder may emit: the recorder's own words and every owner's code. */
  has(outcome: string): boolean;
  /** The owner's native codes only (no recorder word, no text-rule outcome), sorted. */
  nativeCodes(): readonly string[];
  /** The rule whose pattern matches this whole text, or null. Reads the text, returns only the rule. */
  matchText(text: string): TextRule | null;
}
declare const CODE_PATTERN: RegExp;
type VocabularyResult = {
  readonly ok: true;
  readonly vocabulary: Vocabulary;
} | {
  readonly ok: false;
  readonly problems: readonly string[];
};
/** A text rule's pattern as a matcher: `<tool>` stands for one short name; everything else is literal; the whole single-line text must match. */
declare function textRuleMatcher(messagePattern: string): RegExp;
declare function createVocabulary(data: VocabularyData): VocabularyResult;
/** Read the vocabulary file's text (the restricted YAML subset below) into a validated vocabulary. Fails closed on anything outside the subset. */
declare function parseVocabulary(text: string): VocabularyResult;
/** A tool, operation or route-part value is an identifier only when it matches its shape AND the redactor would leave it alone. */
declare const isSafeName: (v: unknown) => v is string;
/**
 * Build one event from a plain input object. Deterministic and pure: the output depends only on the input and the vocabulary; the input is only read.
 * Refuses (and the caller must not append) an unknown field, a missing required field, a value outside its shape, an outcome outside the vocabulary,
 * a `cancelOrigin` on a non-cancel event and a cancel with none.
 */
declare function buildEvent(input: unknown, vocabulary: Vocabulary): BuildResult;
//#endregion
//#region src/redactor.d.ts
/**
 * Replace bearer tokens, JWTs, `sk-` keys, credential headers and assignments, pairing tokens and any run of 32 or more base64, base64url
 * or hex characters with `[redacted]`. A bare short string with no context cannot be recognised: that is the limit of a pattern redactor,
 * and the reason the event record carries no free text at all.
 */
declare function redact(message: unknown): string;
/** Redacted first, then flattened to one line, then cut to `maxChars`. */
declare function excerpt(message: unknown, maxChars: number): string;
/** True when the redactor leaves the text unchanged: nothing in it looks like a credential. */
declare const isRedactionStable: (text: string) => boolean;
//#endregion
//#region src/port.d.ts
type AppendReceipt = {
  readonly status: 'stored';
  readonly eventId: string; /** Position in the store, increasing with every stored event. */
  readonly seq: number;
} | {
  readonly status: 'failed'; /** An upper-case code, never a message. */
  readonly code: string;
};
type SinkResult = {
  readonly ok: true;
} | {
  readonly ok: false;
  readonly code: string;
};
interface DiagnosticsSink {
  append(event: DiagnosticEvent): Promise<AppendReceipt>;
  flush(): Promise<SinkResult>;
  release(): Promise<SinkResult>;
}
type ReadResult = {
  readonly ok: true;
  readonly events: readonly DiagnosticEvent[];
} | {
  readonly ok: false;
  readonly code: string;
};
type OpenResult = {
  readonly ok: true;
  readonly sink: DiagnosticsSink;
} | {
  readonly ok: false;
  readonly code: string;
};
/** The store an adapter owns: one writer, and a read of the stored state in order. */
interface DiagnosticsStore {
  openWriter(): Promise<OpenResult>;
  read(): Promise<ReadResult>;
}
declare const WRITER_EXISTS = "DIAGNOSTICS_WRITER_EXISTS";
declare const SINK_RELEASED = "DIAGNOSTICS_SINK_RELEASED";
/** An in-memory store. Stored events are frozen copies, so a later change to the caller's object cannot change what was stored. */
declare function createMemoryStore(): DiagnosticsStore;
//#endregion
//#region src/recorder.d.ts
/** What a snapshot-reading observer is handed (M02's `Observer`): read-only, any shape, nothing trusted. */
type ObservedSnapshot = Readonly<Record<string, unknown>>;
type RecorderObserver = (snapshot: ObservedSnapshot) => undefined;
interface SessionContext {
  readonly sessionId: string;
  readonly rootId?: string;
  readonly callerRef?: string;
  /** The composition digest of the lifecycle, `sha256:<hex>`. */
  readonly digest?: string;
}
/** What a caller says about one event; identity, time and host are the recorder's. Any other key refuses the event. */
interface EventDraft {
  readonly kind: EventKind;
  readonly name?: string;
  readonly outcome: string;
  readonly route?: Route;
  readonly cancelOrigin?: CancelOrigin;
  readonly sizes?: Readonly<Partial<Record<SizeField, number | 'unknown'>>>;
  readonly durationMs?: number | 'unknown';
  readonly correlationId?: string;
}
interface Producer {
  /** Pass as one of `ExtensionOptions.observers`. */
  readonly observer: RecorderObserver;
  record(draft: EventDraft): void;
  /** An error as an outcome only: its `code` if the vocabulary has it, the decline text if a rule matches, else `error`. The error object and its message are not kept. */
  error(error: unknown, about?: {
    readonly name?: string;
    readonly correlationId?: string;
  }): void;
  cancel(origin: CancelOrigin, about?: {
    readonly name?: string;
    readonly correlationId?: string;
  }): void;
  refusal(code: string, about?: {
    readonly name?: string;
    readonly correlationId?: string;
  }): void;
  route(route: Route, outcome: string, about?: {
    readonly name?: string;
    readonly correlationId?: string;
    readonly durationMs?: number;
  }): void;
}
type HealthReason = 'append-failed' | 'append-uncertain' | 'observer-errors' | 'internal-error' | 'release-failed';
interface Health {
  /** `unavailable` whenever the recorder cannot vouch that what it saw was stored: never "ok because nothing arrived". */
  readonly state: 'ok' | 'unavailable' | 'released';
  readonly reasons: readonly HealthReason[];
  readonly counts: {
    readonly stored: number;
    readonly appendFailed: number;
    readonly appendUncertain: number;
    /** Events the builder refused (an unknown field, a bad shape, an outcome outside the vocabulary). Nothing of them was appended. */
    readonly rejected: number;
    /** Events whose session could not be attributed. Nothing of them was appended. */
    readonly unattributed: number;
    /** Snapshots of a type this recorder does not map. Counted, not stored. */
    readonly unrecognized: number;
    readonly droppedAfterRelease: number;
    readonly internalErrors: number;
    readonly pending: number;
  };
  /** Observer exceptions the host swallowed since this recorder was created, or `unknown` when no counter was supplied. */
  readonly observerErrors: number | 'unknown';
  readonly lastFailure: {
    readonly code: string;
    readonly time: string;
  } | null;
  readonly lastSeq: number | null;
}
interface FlushReport {
  /** Everything the recorder accepted reached the store and the sink flushed; false otherwise. */
  readonly ok: boolean;
  readonly sinkFlushed: boolean;
  readonly stored: number;
  readonly appendFailed: number;
  readonly appendUncertain: number;
}
interface ReleaseReport {
  /** XC-7: the recorder is released only when its events were flushed and the sink released. */
  readonly ok: boolean;
  readonly flush: FlushReport;
  readonly sinkReleased: boolean;
}
interface Recorder {
  producer(context: SessionContext | (() => SessionContext | null)): Producer;
  health(): Health;
  flush(): Promise<FlushReport>;
  /** Stop accepting events, flush, release the sink. Idempotent: every call returns the same report. */
  release(): Promise<ReleaseReport>;
}
interface RecorderOptions {
  readonly host: string;
  readonly vocabulary: Vocabulary;
  /** The one writer of this host's store, opened by the assembly. The recorder never opens or replaces it. */
  readonly sink: DiagnosticsSink;
  /** Epoch milliseconds. Default `Date.now`. */
  readonly clock?: () => number;
  /** A unique event id. Default: a random UUID. */
  readonly newId?: () => string;
  /** The names of the tools this host registered. When given, any other name is recorded as `unregistered`, so a model-chosen name never reaches the log. */
  readonly knownNames?: () => Iterable<string>;
  /** `status.rejected.observerErrors` of M02's adapter. */
  readonly observerErrors?: () => number;
  /** Start calls remembered for a duration; the oldest is forgotten past this. Default 1024. */
  readonly maxOpenCalls?: number;
}
declare function createRecorder(options: RecorderOptions): Recorder;
//#endregion
export { type AppendReceipt, type BuildResult, CANCEL_ORIGINS, CODE_PATTERN, type CancelOrigin, type DiagnosticEvent, type DiagnosticsSink, type DiagnosticsStore, EVENT_FIELDS, EVENT_KINDS, type EventDraft, type EventField, type EventKind, type FlushReport, type Health, type HealthReason, type ObservedSnapshot, type OpenResult, type Problem, type Producer, type ReadResult, type Recorder, type RecorderObserver, type RecorderOptions, type ReleaseReport, type Route, SINK_RELEASED, SIZE_FIELDS, type SessionContext, type SinkResult, type SizeField, type TextRule, type Vocabulary, type VocabularyData, type VocabularyFamily, type VocabularyResult, type VocabularySource, WRITER_EXISTS, buildEvent, createMemoryStore, createRecorder, createVocabulary, excerpt, isRedactionStable, isSafeName, parseVocabulary, redact, textRuleMatcher };